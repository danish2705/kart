"""In-memory task storage. Deliberately simple (no DB) -- this app exists
as a demo target for the Dev Agent to extend per ADO work items, not as
production infrastructure."""
from app.models import Task, TaskCreate, TaskUpdate


class TaskNotFoundError(Exception):
    def __init__(self, task_id: int):
        super().__init__(f"Task {task_id} not found")
        self.task_id = task_id


class TaskStore:
    def __init__(self) -> None:
        self._tasks: dict[int, Task] = {}
        self._next_id = 1

    def list_tasks(self) -> list[Task]:
        return list(self._tasks.values())

    def create_task(self, data: TaskCreate) -> Task:
        task = Task(id=self._next_id, title=data.title, description=data.description, done=False)
        self._tasks[task.id] = task
        self._next_id += 1
        return task

    def get_task(self, task_id: int) -> Task:
        task = self._tasks.get(task_id)
        if task is None:
            raise TaskNotFoundError(task_id)
        return task

    def update_task(self, task_id: int, data: TaskUpdate) -> Task:
        task = self.get_task(task_id)
        updated = task.model_copy(
            update={k: v for k, v in data.model_dump(exclude_unset=True).items() if v is not None}
        )
        self._tasks[task_id] = updated
        return updated

    def delete_task(self, task_id: int) -> None:
        if task_id not in self._tasks:
            raise TaskNotFoundError(task_id)
        del self._tasks[task_id]
