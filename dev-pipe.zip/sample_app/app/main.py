"""Task Tracker -- a small FastAPI app that exists as a demo target for
the Dev Agent to extend per ADO work items, and for the QE Agent to
generate/execute tests against. Not production infrastructure."""
from fastapi import FastAPI, HTTPException

from app.models import Task, TaskCreate, TaskUpdate
from app.storage import TaskNotFoundError, TaskStore

app = FastAPI(title="Task Tracker", version="0.1.0")
store = TaskStore()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/tasks", response_model=list[Task])
def list_tasks() -> list[Task]:
    return store.list_tasks()


@app.post("/tasks", response_model=Task, status_code=201)
def create_task(data: TaskCreate) -> Task:
    return store.create_task(data)


@app.get("/tasks/{task_id}", response_model=Task)
def get_task(task_id: int) -> Task:
    try:
        return store.get_task(task_id)
    except TaskNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.patch("/tasks/{task_id}", response_model=Task)
def update_task(task_id: int, data: TaskUpdate) -> Task:
    try:
        return store.update_task(task_id, data)
    except TaskNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.delete("/tasks/{task_id}", status_code=204)
def delete_task(task_id: int) -> None:
    try:
        store.delete_task(task_id)
    except TaskNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
