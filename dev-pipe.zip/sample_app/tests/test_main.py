import pytest
from fastapi.testclient import TestClient

from app.main import app, store


@pytest.fixture(autouse=True)
def reset_store():
    store._tasks.clear()
    store._next_id = 1
    yield


@pytest.fixture
def client():
    return TestClient(app)


def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}


def test_list_tasks_empty(client):
    resp = client.get("/tasks")
    assert resp.status_code == 200
    assert resp.json() == []


def test_create_and_get_task(client):
    resp = client.post("/tasks", json={"title": "Write docs", "description": "for the API"})
    assert resp.status_code == 201
    body = resp.json()
    assert body["title"] == "Write docs"
    assert body["done"] is False

    resp2 = client.get(f"/tasks/{body['id']}")
    assert resp2.status_code == 200
    assert resp2.json() == body


def test_create_task_requires_title(client):
    resp = client.post("/tasks", json={"title": ""})
    assert resp.status_code == 422


def test_get_missing_task_returns_404(client):
    resp = client.get("/tasks/999")
    assert resp.status_code == 404


def test_update_task(client):
    created = client.post("/tasks", json={"title": "Task A"}).json()
    resp = client.patch(f"/tasks/{created['id']}", json={"done": True})
    assert resp.status_code == 200
    assert resp.json()["done"] is True
    assert resp.json()["title"] == "Task A"


def test_update_missing_task_returns_404(client):
    resp = client.patch("/tasks/999", json={"done": True})
    assert resp.status_code == 404


def test_delete_task(client):
    created = client.post("/tasks", json={"title": "Temp"}).json()
    resp = client.delete(f"/tasks/{created['id']}")
    assert resp.status_code == 204
    assert client.get(f"/tasks/{created['id']}").status_code == 404


def test_delete_missing_task_returns_404(client):
    resp = client.delete("/tasks/999")
    assert resp.status_code == 404


def test_list_tasks_returns_created_items(client):
    client.post("/tasks", json={"title": "A"})
    client.post("/tasks", json={"title": "B"})
    resp = client.get("/tasks")
    assert len(resp.json()) == 2
