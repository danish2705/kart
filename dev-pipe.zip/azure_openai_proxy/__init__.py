"""Anthropic Messages API <-> Azure OpenAI Chat Completions API bridge.

Self-contained (only third-party dependency: `requests`) so this package
can be copied into any other repo unmodified. Two ways to use it:

Embedded, from Python:

    from azure_openai_proxy import start_proxy, stop_proxy

    server, thread, port = start_proxy(
        endpoint="https://YOUR-RESOURCE.openai.azure.com/openai/v1",
        api_key="...", deployment="o4-mini",
    )
    os.environ["ANTHROPIC_BASE_URL"] = f"http://127.0.0.1:{port}"
    os.environ["ANTHROPIC_AUTH_TOKEN"] = "unused-but-must-be-non-empty"
    ...
    stop_proxy(server, thread)

Standalone, from the command line:

    python -m azure_openai_proxy \\
        --endpoint https://YOUR-RESOURCE.openai.azure.com/openai/v1 \\
        --api-key $AZURE_OPENAI_API_KEY --deployment o4-mini --port 8787

then point any Anthropic-Messages-API client (ANTHROPIC_BASE_URL=http://127.0.0.1:8787)
at it.
"""
from azure_openai_proxy.server import DEFAULT_API_VERSION, start_proxy, stop_proxy
from azure_openai_proxy.translate import (
    anthropic_error,
    anthropic_messages_to_openai,
    anthropic_request_to_openai,
    anthropic_tool_choice_to_openai,
    anthropic_tools_to_openai,
    is_reasoning_model,
    openai_response_to_anthropic,
    sse_events_for_message,
)

__all__ = [
    "DEFAULT_API_VERSION",
    "start_proxy",
    "stop_proxy",
    "anthropic_error",
    "anthropic_messages_to_openai",
    "anthropic_request_to_openai",
    "anthropic_tool_choice_to_openai",
    "anthropic_tools_to_openai",
    "is_reasoning_model",
    "openai_response_to_anthropic",
    "sse_events_for_message",
]
