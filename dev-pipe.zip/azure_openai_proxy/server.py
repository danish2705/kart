"""A tiny local HTTP server that speaks the Anthropic Messages API on one
side and Azure OpenAI's Chat Completions API on the other, so any tool
built against `ANTHROPIC_BASE_URL` (Claude Code, the Claude Agent SDK, ...)
can be pointed at an Azure OpenAI deployment instead of Anthropic's own API.

Standard-library HTTP server + `requests` only -- no framework dependency,
so this package can be dropped into any other repo unmodified (just copy
the `azure_openai_proxy/` directory and `pip install requests`, optionally
`truststore` too -- see below).

Azure OpenAI's API is not wire-compatible with Anthropic's (different auth
header, URL shape, and request/response/tool-call schema); this is what
actually bridges the two, as opposed to just rerouting the base URL and
hoping (which fails outright -- see README).
"""
from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import requests

try:
    # On a network with TLS-inspecting middleboxes (common on corporate
    # networks), the outbound call to Azure below fails SSL verification
    # because the inspecting proxy's self-signed root CA isn't in
    # `requests`' bundled certifi list -- even though it's already trusted
    # by the OS (and therefore the browser) directly. `truststore` makes
    # Python's ssl module (and therefore `requests`, via urllib3) verify
    # against the OS trust store instead, picking up that CA the same way
    # a browser would, with no security downgrade. Optional: falls back to
    # certifi's default verification if it isn't installed.
    import truststore

    truststore.inject_into_ssl()
except ImportError:
    pass

from azure_openai_proxy.translate import (
    anthropic_error,
    anthropic_request_to_openai,
    openai_response_to_anthropic,
    sse_events_for_message,
)

DEFAULT_API_VERSION = "2024-12-01-preview"


def azure_chat_completions_url(endpoint: str, deployment: str, api_version: str) -> str:
    """Azure has two current API shapes: the newer OpenAI-client-compatible
    `.../openai/v1` surface (model addressed by name, no api-version query
    param) and the classic `.../openai/deployments/{id}/...` surface
    (model addressed by deployment path, api-version required)."""
    endpoint = endpoint.rstrip("/")
    if endpoint.endswith("/openai/v1"):
        return f"{endpoint}/chat/completions"
    return f"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"


def azure_headers(endpoint: str, api_key: str) -> dict:
    if endpoint.rstrip("/").endswith("/openai/v1"):
        return {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    return {"api-key": api_key, "Content-Type": "application/json"}


def _make_handler(endpoint: str, api_key: str, deployment: str, api_version: str) -> type[BaseHTTPRequestHandler]:
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args) -> None:  # noqa: A002 - stdlib signature
            pass  # quiet by default; the caller's own agent loop is the log of record

        def do_GET(self) -> None:  # health check / reachability probes
            self._send_json(200, {"status": "ok", "proxy": "azure-openai-anthropic-bridge"})

        def do_POST(self) -> None:
            length = int(self.headers.get("Content-Length", 0))
            try:
                body = json.loads(self.rfile.read(length) or b"{}")
            except json.JSONDecodeError as exc:
                self._send_json(400, anthropic_error(f"invalid JSON body: {exc}", "invalid_request_error"))
                return

            model = body.get("model") or deployment
            try:
                openai_body = anthropic_request_to_openai({**body, "model": model})
                resp = requests.post(
                    azure_chat_completions_url(endpoint, deployment, api_version),
                    headers=azure_headers(endpoint, api_key),
                    json=openai_body, timeout=180,
                )
                resp.raise_for_status()
                message = openai_response_to_anthropic(resp.json(), model)
            except requests.HTTPError as exc:
                detail = exc.response.text[:2000] if exc.response is not None else str(exc)
                self._send_json(502, anthropic_error(f"Azure OpenAI request failed: {detail}"))
                return
            except Exception as exc:  # noqa: BLE001 - must still answer with a well-formed Anthropic error
                self._send_json(502, anthropic_error(f"proxy error: {exc}"))
                return

            if body.get("stream"):
                self._send_sse(sse_events_for_message(message))
            else:
                self._send_json(200, message)

        def _send_json(self, status: int, payload: dict) -> None:
            data = json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _send_sse(self, body: str) -> None:
            data = body.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    return Handler


def start_proxy(
    endpoint: str, api_key: str, deployment: str,
    api_version: str = DEFAULT_API_VERSION, host: str = "127.0.0.1", port: int = 0,
) -> tuple[ThreadingHTTPServer, threading.Thread, int]:
    """Starts the proxy in a background thread and returns
    (server, thread, actual_port) -- port=0 (the default) picks a free
    ephemeral port, read back from server.server_address[1]."""
    handler = _make_handler(endpoint, api_key, deployment, api_version)
    server = ThreadingHTTPServer((host, port), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, thread, server.server_address[1]


def stop_proxy(server: ThreadingHTTPServer, thread: threading.Thread) -> None:
    server.shutdown()
    server.server_close()
    thread.join(timeout=5)
