"""Standalone entry point: `python -m azure_openai_proxy --endpoint ... --api-key ... --deployment ...`

Runs the proxy in the foreground on a fixed port (default 8787) until
Ctrl+C. Useful outside this repo -- point any Anthropic-Messages-API
client's ANTHROPIC_BASE_URL at http://127.0.0.1:<port> and it talks to
your Azure OpenAI deployment instead.
"""
from __future__ import annotations

import argparse
import sys

from azure_openai_proxy.server import DEFAULT_API_VERSION, start_proxy, stop_proxy


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--endpoint", required=True, help="Azure OpenAI endpoint, e.g. https://RESOURCE.openai.azure.com/openai/v1")
    parser.add_argument("--api-key", required=True)
    parser.add_argument("--deployment", required=True, help="Azure OpenAI deployment name (used as the model when the client doesn't specify one)")
    parser.add_argument("--api-version", default=DEFAULT_API_VERSION, help="Only used against the classic (non-/openai/v1) Azure endpoint shape")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8787)
    args = parser.parse_args(argv)

    server, thread, port = start_proxy(
        endpoint=args.endpoint, api_key=args.api_key, deployment=args.deployment,
        api_version=args.api_version, host=args.host, port=args.port,
    )
    print(f"azure-openai-proxy listening on http://{args.host}:{port} -> {args.endpoint} ({args.deployment})")
    print("Set ANTHROPIC_BASE_URL to the URL above. Ctrl+C to stop.")
    try:
        thread.join()
    except KeyboardInterrupt:
        pass
    finally:
        stop_proxy(server, thread)
    return 0


if __name__ == "__main__":
    sys.exit(main())
