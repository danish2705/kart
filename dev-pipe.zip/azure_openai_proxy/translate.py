"""Pure translation functions between Anthropic's Messages API wire format
(what Claude Code / the Claude Agent SDK's bundled `claude` CLI speaks) and
Azure OpenAI's Chat Completions API wire format.

Kept free of any HTTP/server concerns so every branch is unit-testable
without a live Azure endpoint -- see tests/test_translate.py.
"""
from __future__ import annotations

import json
import uuid

# Reasoning models (o1/o3/o4/gpt-5 families) reject `temperature`/`top_p`
# and want `max_completion_tokens` instead of `max_tokens`.
REASONING_MODEL_PREFIXES = ("o1", "o3", "o4", "gpt-5")


def is_reasoning_model(model: str) -> bool:
    return model.lower().startswith(REASONING_MODEL_PREFIXES)


def _system_text(system: str | list[dict] | None) -> str:
    if not system:
        return ""
    if isinstance(system, str):
        return system
    return "\n".join(block.get("text", "") for block in system if isinstance(block, dict))


def anthropic_messages_to_openai(system: str | list[dict] | None, messages: list[dict]) -> list[dict]:
    """Anthropic's message/content-block list -> OpenAI chat messages.

    The two protocols' agent-loop turns don't line up 1:1: Anthropic embeds
    a tool call as a `tool_use` content block inside an assistant message
    and its result as a `tool_result` block inside the *next* user message,
    while OpenAI wants the call in `assistant.tool_calls` and the result as
    its own `role: "tool"` message. This performs that expansion.
    """
    openai_messages: list[dict] = []
    system_text = _system_text(system)
    if system_text:
        openai_messages.append({"role": "system", "content": system_text})

    for msg in messages:
        role = msg["role"]
        content = msg["content"]
        if isinstance(content, str):
            openai_messages.append({"role": role, "content": content})
            continue

        if role == "assistant":
            text_parts = [b["text"] for b in content if b.get("type") == "text"]
            tool_calls = [
                {
                    "id": b["id"],
                    "type": "function",
                    "function": {"name": b["name"], "arguments": json.dumps(b.get("input", {}))},
                }
                for b in content if b.get("type") == "tool_use"
            ]
            entry: dict = {"role": "assistant", "content": "\n".join(text_parts) or None}
            if tool_calls:
                entry["tool_calls"] = tool_calls
            openai_messages.append(entry)
        else:
            text_parts = []
            for b in content:
                if b.get("type") == "text":
                    text_parts.append(b["text"])
                elif b.get("type") == "tool_result":
                    tool_content = b.get("content", "")
                    if isinstance(tool_content, list):
                        tool_content = "\n".join(
                            p.get("text", "") for p in tool_content if isinstance(p, dict)
                        )
                    openai_messages.append({
                        "role": "tool", "tool_call_id": b["tool_use_id"], "content": str(tool_content),
                    })
            if text_parts:
                openai_messages.append({"role": "user", "content": "\n".join(text_parts)})
    return openai_messages


def anthropic_tools_to_openai(tools: list[dict] | None) -> list[dict] | None:
    if not tools:
        return None
    return [
        {
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t.get("description", ""),
                "parameters": t.get("input_schema", {"type": "object", "properties": {}}),
            },
        }
        for t in tools
    ]


def anthropic_tool_choice_to_openai(tool_choice: dict | None) -> str | dict | None:
    if not tool_choice:
        return None
    kind = tool_choice.get("type")
    if kind == "any":
        return "required"
    if kind == "tool":
        return {"type": "function", "function": {"name": tool_choice["name"]}}
    return "auto"


def anthropic_request_to_openai(body: dict) -> dict:
    """Full Anthropic `/v1/messages` request body -> Azure OpenAI Chat
    Completions request body."""
    model = body["model"]
    openai_body: dict = {
        "model": model,
        "messages": anthropic_messages_to_openai(body.get("system"), body["messages"]),
    }
    tools = anthropic_tools_to_openai(body.get("tools"))
    if tools:
        openai_body["tools"] = tools
        choice = anthropic_tool_choice_to_openai(body.get("tool_choice"))
        if choice:
            openai_body["tool_choice"] = choice

    max_tokens = body.get("max_tokens", 4096)
    if is_reasoning_model(model):
        openai_body["max_completion_tokens"] = max_tokens
    else:
        openai_body["max_tokens"] = max_tokens
        if "temperature" in body:
            openai_body["temperature"] = body["temperature"]
    return openai_body


_FINISH_TO_STOP_REASON = {
    "stop": "end_turn",
    "length": "max_tokens",
    "tool_calls": "tool_use",
    "content_filter": "end_turn",
}


def openai_response_to_anthropic(resp_json: dict, model: str) -> dict:
    """Azure OpenAI Chat Completions response -> Anthropic Messages API
    response (non-streaming shape)."""
    choice = resp_json["choices"][0]
    msg = choice.get("message", {})
    content_blocks = []
    if msg.get("content"):
        content_blocks.append({"type": "text", "text": msg["content"]})
    for tc in msg.get("tool_calls") or []:
        try:
            args = json.loads(tc["function"].get("arguments") or "{}")
        except json.JSONDecodeError:
            args = {}
        content_blocks.append({
            "type": "tool_use", "id": tc["id"], "name": tc["function"]["name"], "input": args,
        })
    if not content_blocks:
        content_blocks.append({"type": "text", "text": ""})

    usage = resp_json.get("usage", {})
    return {
        "id": resp_json.get("id", f"msg_{uuid.uuid4().hex}"),
        "type": "message",
        "role": "assistant",
        "model": model,
        "content": content_blocks,
        "stop_reason": _FINISH_TO_STOP_REASON.get(choice.get("finish_reason"), "end_turn"),
        "stop_sequence": None,
        "usage": {
            "input_tokens": usage.get("prompt_tokens", 0),
            "output_tokens": usage.get("completion_tokens", 0),
        },
    }


def anthropic_error(message: str, error_type: str = "api_error") -> dict:
    return {"type": "error", "error": {"type": error_type, "message": message}}


def sse_events_for_message(message: dict) -> str:
    """Anthropic message -> the SSE event stream Anthropic's real streaming
    API would have produced for it.

    Emits each content block as a single start/delta/stop triple rather
    than real token-by-token increments -- a client that assembles blocks
    from these events (as the Claude Agent SDK does) ends up with the
    identical final message either way, and Azure's own response already
    arrived as one complete, non-streamed block."""
    lines: list[str] = []

    def emit(event: str, data: dict) -> None:
        lines.append(f"event: {event}")
        lines.append(f"data: {json.dumps(data)}")
        lines.append("")

    start_message = {k: v for k, v in message.items() if k != "content"}
    start_message["content"] = []
    start_message["usage"] = {"input_tokens": message["usage"]["input_tokens"], "output_tokens": 0}
    emit("message_start", {"type": "message_start", "message": start_message})

    for index, block in enumerate(message["content"]):
        if block["type"] == "text":
            emit("content_block_start", {
                "type": "content_block_start", "index": index,
                "content_block": {"type": "text", "text": ""},
            })
            emit("content_block_delta", {
                "type": "content_block_delta", "index": index,
                "delta": {"type": "text_delta", "text": block["text"]},
            })
        else:
            emit("content_block_start", {
                "type": "content_block_start", "index": index,
                "content_block": {"type": "tool_use", "id": block["id"], "name": block["name"], "input": {}},
            })
            emit("content_block_delta", {
                "type": "content_block_delta", "index": index,
                "delta": {"type": "input_json_delta", "partial_json": json.dumps(block["input"])},
            })
        emit("content_block_stop", {"type": "content_block_stop", "index": index})

    emit("message_delta", {
        "type": "message_delta",
        "delta": {"stop_reason": message["stop_reason"], "stop_sequence": None},
        "usage": {"output_tokens": message["usage"]["output_tokens"]},
    })
    emit("message_stop", {"type": "message_stop"})
    return "\n".join(lines) + "\n"
