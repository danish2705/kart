"""Sonar zero-issues pre-check gate. Runs `sonar-scanner` locally against
the working tree, then queries the Sonar Web API for the issues it found
on this analysis, and requires zero at Blocker/Critical/Major severity
before the Dev Agent is allowed to push -- catching issues before they
reach GitHub/CI (the Jul milestone from the diagram), not after.

Split into a scan step (shells out, needs the sonar-scanner CLI + a
reachable Sonar server -- not runnable in this dev session, see README)
and a pure evaluation step (`evaluate_issues`, unit-testable against a
fixture API response) so the gate logic itself is verified even without
a live Sonar instance.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import time
from dataclasses import dataclass, field

import requests

BLOCKING_SEVERITIES = {"BLOCKER", "CRITICAL", "MAJOR"}


@dataclass
class SonarIssue:
    key: str
    rule: str
    severity: str
    message: str
    component: str
    line: int | None = None


@dataclass
class SonarGateResult:
    passed: bool
    blocking_issues: list[SonarIssue] = field(default_factory=list)
    info_issues: list[SonarIssue] = field(default_factory=list)

    def summary(self) -> str:
        if self.passed:
            return "Sonar pre-check: PASS (zero Blocker/Critical/Major issues)"
        lines = [f"Sonar pre-check: FAIL ({len(self.blocking_issues)} blocking issue(s))"]
        for issue in self.blocking_issues:
            loc = f":{issue.line}" if issue.line else ""
            lines.append(f"  [{issue.severity}] {issue.component}{loc} -- {issue.message} ({issue.rule})")
        return "\n".join(lines)


def evaluate_issues(raw_issues: list[dict]) -> SonarGateResult:
    """Pure function: Sonar Web API /api/issues/search "issues" array ->
    gate result. Kept separate from the network calls so it's directly
    unit-testable with a fixture."""
    blocking: list[SonarIssue] = []
    info: list[SonarIssue] = []
    for item in raw_issues:
        issue = SonarIssue(
            key=item.get("key", ""),
            rule=item.get("rule", ""),
            severity=item.get("severity", ""),
            message=item.get("message", ""),
            component=item.get("component", ""),
            line=item.get("line"),
        )
        if issue.severity in BLOCKING_SEVERITIES:
            blocking.append(issue)
        else:
            info.append(issue)
    return SonarGateResult(passed=len(blocking) == 0, blocking_issues=blocking, info_issues=info)


def run_sonar_scanner(
    project_dir: str, project_key: str, host_url: str, token: str, organization: str | None = None,
) -> subprocess.CompletedProcess:
    """Shells out to sonar-scanner. Requires the CLI on PATH (installed by
    the CI workflow's setup step) and a reachable Sonar server. Resolved via
    shutil.which, which checks PATHEXT, so Windows' sonar-scanner.bat wrapper
    is found too -- CreateProcess itself (unlike a shell) never consults
    PATHEXT, only appending .exe.

    organization is mandatory on SonarCloud (as opposed to a self-hosted
    SonarQube), so it's only passed when given."""
    scanner = shutil.which("sonar-scanner") or "sonar-scanner"
    args = [
        scanner,
        f"-Dsonar.projectKey={project_key}",
        f"-Dsonar.host.url={host_url}",
        "-Dsonar.sourceEncoding=UTF-8",
        "-Dsonar.python.coverage.reportPaths=coverage.xml",
    ]
    if organization:
        args.append(f"-Dsonar.organization={organization}")
    # Token via env, not argv, so it never shows in process listings.
    return subprocess.run(args, cwd=project_dir, capture_output=True, text=True,
                          encoding="utf-8", errors="replace",
                          env={**os.environ, "SONAR_TOKEN": token})


def fetch_issues(host_url: str, token: str, project_key: str, statuses: str = "OPEN,CONFIRMED") -> list[dict]:
    """Queries the Sonar Web API for the current issues on project_key.
    A short poll/retry is used since the analysis report processes
    asynchronously after sonar-scanner exits."""
    for attempt in range(5):
        resp = requests.get(
            f"{host_url}/api/issues/search",
            params={"componentKeys": project_key, "statuses": statuses, "ps": 500},
            auth=(token, ""),
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        if not data.get("issues") and attempt < 4:
            time.sleep(3)
            continue
        return data.get("issues", [])
    return []


def run_sonar_precheck(
    project_dir: str, project_key: str, host_url: str, token: str, organization: str | None = None,
) -> SonarGateResult:
    scan = run_sonar_scanner(project_dir, project_key, host_url, token, organization)
    if scan.returncode != 0:
        return SonarGateResult(
            passed=False,
            blocking_issues=[SonarIssue(
                key="scan-failed", rule="", severity="BLOCKER",
                message=f"sonar-scanner exited {scan.returncode}: {scan.stderr[-2000:]}",
                component=project_dir,
            )],
        )
    issues = fetch_issues(host_url, token, project_key)
    return evaluate_issues(issues)
