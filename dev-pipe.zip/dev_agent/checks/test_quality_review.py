"""Test *quality* gate -- 95% coverage is gameable with assertion-free
tests, so this is a separate, deterministic structural check that runs
before the coverage number is trusted. It flags tests that execute code
without actually verifying behavior; the agent (guided by the
test-quality-review Skill) is expected to fix flagged tests before the
Dev Agent is allowed to proceed.

This is intentionally a fast heuristic pre-filter, not a full static
analysis -- it catches the common coverage-gaming patterns (no assert at
all, or only a vacuous `assert True`) without needing to parse test
semantics.
"""
from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path

_VACUOUS_ASSERT_VALUES = {"True", "1"}


@dataclass
class TrivialTestFinding:
    file: str
    test_name: str
    reason: str


def _is_vacuous_assert(node: ast.Assert) -> bool:
    try:
        return ast.unparse(node.test).strip() in _VACUOUS_ASSERT_VALUES
    except Exception:
        return False


def _review_function(func: ast.FunctionDef, filename: str) -> TrivialTestFinding | None:
    asserts = [n for n in ast.walk(func) if isinstance(n, ast.Assert)]
    pytest_raises_or_warns = any(
        isinstance(n, ast.With)
        and any(
            isinstance(item.context_expr, ast.Call)
            and isinstance(item.context_expr.func, ast.Attribute)
            and item.context_expr.func.attr in ("raises", "warns")
            for item in n.items
        )
        for n in ast.walk(func)
    )

    if not asserts and not pytest_raises_or_warns:
        return TrivialTestFinding(filename, func.name, "no assertion (and no pytest.raises/warns) -- executes code without verifying behavior")

    if asserts and all(_is_vacuous_assert(a) for a in asserts):
        return TrivialTestFinding(filename, func.name, "only vacuous assertions (assert True / assert 1)")

    return None


def review_test_file(path: Path) -> list[TrivialTestFinding]:
    """Parses one test file's AST and flags trivial (coverage-gaming) tests."""
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    findings = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"):
            finding = _review_function(node, str(path))
            if finding:
                findings.append(finding)
    return findings


def review_test_files(paths: list[Path]) -> list[TrivialTestFinding]:
    findings = []
    for path in paths:
        findings.extend(review_test_file(path))
    return findings


def gate_passed(findings: list[TrivialTestFinding]) -> bool:
    return len(findings) == 0
