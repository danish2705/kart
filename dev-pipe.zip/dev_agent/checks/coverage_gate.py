"""Coverage gate: runs pytest --cov and enforces the >=95% threshold
(raised from the diagram's 80% per explicit instruction). The Dev Agent
loops on this (implement -> run -> read the missing-lines report -> add
tests) until it passes or a bounded retry count is hit.
"""
from __future__ import annotations

import subprocess
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_THRESHOLD = 95.0


@dataclass
class FileCoverage:
    filename: str
    line_rate: float
    missing_lines: list[int] = field(default_factory=list)


@dataclass
class CoverageResult:
    passed: bool
    coverage_pct: float
    threshold: float
    files: list[FileCoverage]
    raw_stdout: str
    raw_stderr: str

    def summary(self) -> str:
        lines = [f"Coverage: {self.coverage_pct:.1f}% (threshold {self.threshold:.0f}%) -- "
                 f"{'PASS' if self.passed else 'FAIL'}"]
        for f in self.files:
            if f.missing_lines:
                lines.append(f"  {f.filename}: {f.line_rate*100:.1f}%, missing lines {f.missing_lines}")
        return "\n".join(lines)


def parse_coverage_xml(xml_path: Path) -> CoverageResult:
    """Parses a coverage.py-generated Cobertura-style coverage.xml (already
    validated against a real run in sample_app/) -- kept separate from
    run_coverage_gate() so it's unit-testable against a fixture file."""
    root = ET.parse(xml_path).getroot()
    overall_rate = float(root.attrib.get("line-rate", "0")) * 100

    files: list[FileCoverage] = []
    for cls in root.iter("class"):
        filename = cls.attrib.get("filename", "")
        line_rate = float(cls.attrib.get("line-rate", "0"))
        lines_el = cls.find("lines")
        missing = [
            int(line.attrib["number"])
            for line in (lines_el if lines_el is not None else [])
            if line.attrib.get("hits") == "0"
        ]
        files.append(FileCoverage(filename=filename, line_rate=line_rate, missing_lines=missing))

    return CoverageResult(
        passed=overall_rate >= DEFAULT_THRESHOLD,
        coverage_pct=overall_rate,
        threshold=DEFAULT_THRESHOLD,
        files=files,
        raw_stdout="",
        raw_stderr="",
    )


def run_coverage_gate(
    project_dir: Path, package: str = "app", threshold: float = DEFAULT_THRESHOLD, test_dir: str = "tests",
    python: str = "python",
) -> CoverageResult:
    """Runs pytest --cov in project_dir and evaluates the gate. project_dir
    is expected to contain `package/` and `test_dir/` (e.g. sample_app/).
    `python` = interpreter to run pytest with (e.g. the target repo's own virtualenv)."""
    xml_path = project_dir / "coverage.xml"
    proc = subprocess.run(
        [python, "-m", "pytest", test_dir, f"--cov={package}", "--cov-report=xml", "-q"],
        cwd=project_dir, capture_output=True, text=True,
    )
    if not xml_path.exists():
        return CoverageResult(
            passed=False, coverage_pct=0.0, threshold=threshold, files=[],
            raw_stdout=proc.stdout, raw_stderr=proc.stderr,
        )
    result = parse_coverage_xml(xml_path)
    result.threshold = threshold
    result.passed = result.coverage_pct >= threshold
    result.raw_stdout = proc.stdout
    result.raw_stderr = proc.stderr
    return result
