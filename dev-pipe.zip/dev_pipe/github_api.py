"""Small GitHub REST client used to discover target repos/branches and to open pull requests.

Read calls used for discovery (external mode):
  GET /orgs/{org}/repos (falls back to /users/{org}/repos), GET /repos/{o}/{r},
  GET /repos/{o}/{r}/branches, GET /repos/{o}/{r}/branches/{b},
  GET /repos/{o}/{r}/compare/{base}...{head}, GET /repos/{o}/{r}/pulls?state=open
  POST /graphql (read-only query: branch names + last commit dates, 100 per call)
Write call (Step 6, after approval): POST /repos/{o}/{r}/pulls

The token is only sent in the Authorization header and never logged.
"""
from __future__ import annotations

import os
from urllib.parse import quote

import requests


class GitHubError(RuntimeError):
    pass


class GitHub:
    def __init__(self, token: str, api: str | None = None, session: requests.Session | None = None):
        self.api = (api or os.environ.get("GITHUB_API_URL") or "https://api.github.com").rstrip("/")
        self.session = session or requests.Session()
        self.session.headers.update({"Accept": "application/vnd.github+json",
                                     "X-GitHub-Api-Version": "2022-11-28"})
        if token:
            self.session.headers["Authorization"] = f"Bearer {token}"

    # ---------- low level
    def _request(self, method: str, path: str, *, allow_404: bool = False, **kwargs):
        resp = self.session.request(method, f"{self.api}{path}", timeout=30, **kwargs)
        if allow_404 and resp.status_code == 404:
            return None
        if resp.status_code >= 400:
            raise GitHubError(f"GitHub {method} {path.split('?')[0]} -> HTTP {resp.status_code}: {resp.text[:300]}")
        return resp.json() if resp.content else {}

    def _paged(self, path: str, params: dict | None = None, limit: int = 100, allow_404: bool = False) -> list | None:
        items: list = []
        page = 1
        while len(items) < limit:
            batch = self._request("GET", path, allow_404=allow_404,
                                  params={**(params or {}), "per_page": 100, "page": page})
            if batch is None:
                return None
            items.extend(batch)
            if len(batch) < 100:
                break
            page += 1
        return items[:limit]

    # ---------- discovery
    def list_owner_repos(self, owner: str, limit: int = 100) -> list[dict]:
        """Repos of an org, or of a user account if `owner` is not an org."""
        repos = self._paged(f"/orgs/{quote(owner)}/repos", {"type": "all", "sort": "pushed"}, limit, allow_404=True)
        if repos is None:
            repos = self._paged(f"/users/{quote(owner)}/repos", {"type": "owner", "sort": "pushed"}, limit) or []
        return repos

    def get_repo(self, full_name: str) -> dict | None:
        return self._request("GET", f"/repos/{full_name}", allow_404=True)

    def list_branches(self, full_name: str, limit: int = 100) -> list[str]:
        return [b["name"] for b in (self._paged(f"/repos/{full_name}/branches", limit=limit) or [])]

    def branches_with_dates(self, full_name: str, limit: int = 100_000) -> list[dict]:
        """[{'name', 'sha', 'date'}] for every branch, via GraphQL: one call per 100 branches instead of one
        REST call per branch. Raises GitHubError on any problem (the caller then falls back to REST)."""
        owner, name = full_name.split("/", 1)
        url = (self.api[: -len("/api/v3")] + "/api/graphql") if self.api.endswith("/api/v3") else self.api + "/graphql"
        query = ("query($owner:String!,$name:String!,$after:String){repository(owner:$owner,name:$name){"
                 "refs(refPrefix:\"refs/heads/\",first:100,after:$after){pageInfo{hasNextPage endCursor}"
                 "nodes{name target{... on Commit{oid committedDate}}}}}}")
        out: list[dict] = []
        after = None
        while len(out) < limit:
            resp = self.session.post(url, json={"query": query, "variables": {"owner": owner, "name": name,
                                                                              "after": after}}, timeout=30)
            if resp.status_code >= 400:
                raise GitHubError(f"GitHub GraphQL branches of {full_name} -> HTTP {resp.status_code}: {resp.text[:200]}")
            body = resp.json() if resp.content else {}
            if body.get("errors") or not (body.get("data") or {}).get("repository"):
                raise GitHubError(f"GitHub GraphQL branches of {full_name}: {str(body.get('errors'))[:200]}")
            refs = body["data"]["repository"]["refs"]
            for n in refs.get("nodes") or []:
                target = n.get("target") or {}
                out.append({"name": n.get("name", ""), "sha": target.get("oid", ""),
                            "date": target.get("committedDate", "")})
            if not (refs.get("pageInfo") or {}).get("hasNextPage"):
                break
            after = refs["pageInfo"]["endCursor"]
        return out[:limit]

    def get_branch(self, full_name: str, branch: str) -> dict | None:
        """{'name', 'sha', 'date'} or None if the branch does not exist."""
        data = self._request("GET", f"/repos/{full_name}/branches/{quote(branch, safe='')}", allow_404=True)
        if not data:
            return None
        commit = data.get("commit") or {}
        inner = commit.get("commit") or {}
        date = (inner.get("committer") or {}).get("date") or (inner.get("author") or {}).get("date") or ""
        return {"name": data.get("name", branch), "sha": commit.get("sha", ""), "date": date}

    def compare(self, full_name: str, base: str, head: str) -> dict:
        """What `head` has that `base` does not: ahead_by, changed file paths, commit messages."""
        data = self._request("GET", f"/repos/{full_name}/compare/{quote(base, safe='')}...{quote(head, safe='')}",
                             allow_404=True) or {}
        return {
            "ahead_by": int(data.get("ahead_by", 0) or 0),
            "files": [f.get("filename", "") for f in data.get("files", []) or []],
            "messages": [((c.get("commit") or {}).get("message") or "") for c in data.get("commits", []) or []],
        }

    def open_pulls(self, full_name: str, limit: int = 100) -> list[dict]:
        pulls = self._paged(f"/repos/{full_name}/pulls", {"state": "open"}, limit) or []
        return [{"number": p.get("number"), "title": p.get("title") or "", "body": p.get("body") or "",
                 "head": (p.get("head") or {}).get("ref", ""), "base": (p.get("base") or {}).get("ref", "")}
                for p in pulls]

    # ---------- write
    def find_open_pull(self, full_name: str, head: str, base: str) -> dict | None:
        """The open PR from `head` into `base` (a re-run reuses it instead of failing on 'already exists')."""
        owner = full_name.split("/", 1)[0]
        pulls = self._request("GET", f"/repos/{full_name}/pulls",
                              params={"state": "open", "head": f"{owner}:{head}", "base": base}) or []
        if not pulls:
            return None
        p = pulls[0]
        return {"number": p["number"], "url": p["html_url"], "head": head, "base": base, "repo": full_name}

    def update_pull_request(self, full_name: str, number: int, title: str, body: str) -> None:
        self._request("PATCH", f"/repos/{full_name}/pulls/{number}", json={"title": title, "body": body})

    def create_pull_request(self, full_name: str, head: str, base: str, title: str, body: str) -> dict:
        existing = self.find_open_pull(full_name, head, base)
        if existing:
            self.update_pull_request(full_name, existing["number"], title, body)
            print(f"[github] PR #{existing['number']} already open for {head} -> {base}; updated it", flush=True)
            return {**existing, "reused": True}
        data = self._request("POST", f"/repos/{full_name}/pulls",
                             json={"title": title, "head": head, "base": base, "body": body})
        return {"number": data["number"], "url": data["html_url"], "head": head, "base": base, "repo": full_name}
