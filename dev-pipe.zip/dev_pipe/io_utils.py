"""Hand-off files between jobs (out/) and the run summary reviewers see before approving."""
from __future__ import annotations

import json
import os

from dev_pipe.config import OUT


def write_json(name: str, data) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[out] wrote out/{name}", flush=True)


def read_json(name: str, default=None):
    path = OUT / name
    if not path.exists():
        if default is not None:
            return default
        raise SystemExit(f"Missing input 'out/{name}'. Did the previous job finish and upload its artifact?")
    return json.loads(path.read_text(encoding="utf-8"))


def write_text(name: str, text: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / name).write_text(text, encoding="utf-8")
    print(f"[out] wrote out/{name}", flush=True)


def write_bytes(name: str, data: bytes) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / name).write_bytes(data)
    print(f"[out] wrote out/{name}", flush=True)


def read_text(name: str, default: str | None = None) -> str:
    path = OUT / name
    if not path.exists():
        if default is not None:
            return default
        raise SystemExit(f"Missing input 'out/{name}'. Did the previous job finish and upload its artifact?")
    return path.read_text(encoding="utf-8")


def append_log(line: str) -> None:
    """Running development summary, posted to ADO in Step 8 (ADO Update & Development Complete)."""
    OUT.mkdir(parents=True, exist_ok=True)
    with open(OUT / "summary.md", "a", encoding="utf-8") as f:
        f.write(line.rstrip() + "\n")


def set_output(name: str, value: str) -> None:
    """Expose a value to later jobs (GitHub step output). No-op when run locally."""
    path = os.environ.get("GITHUB_OUTPUT")
    if path:
        with open(path, "a", encoding="utf-8") as f:
            f.write(f"{name}={value}\n")


def summary(markdown: str) -> None:
    """Append to the GitHub run summary (visible on the run page) and print it."""
    from dev_pipe.steplog import write_summary
    write_summary(markdown)


def cell(value, limit: int = 120) -> str:
    """Make a value safe for a markdown table cell."""
    text = str(value if value is not None else "").replace("|", "\\|").replace("\n", " ").strip()
    return text if len(text) <= limit else text[: limit - 3] + "..."
