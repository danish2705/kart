"""Dev pipeline (GitHub Actions) for the 9-step Dev Agent flow.

Each module in dev_pipe/steps/ is one pipeline job. Jobs hand data to each
other through out/ (uploaded as run artifacts), never through the repo.

"""
