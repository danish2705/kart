"""LCOV coverage reports (JavaScript / TypeScript projects, e.g. Vitest or Jest with the `lcov` reporter).

Used for non-Python targets:
  - Step 4 reads the line coverage from the reports its own test run just wrote (report only, no gate).
  - Step 7 passes the report paths to the Sonar scanner (sonar.javascript.lcov.reportPaths).
"""
from __future__ import annotations

import os
from pathlib import Path

LCOV_NAME = "lcov.info"
_SKIP_DIRS = {"node_modules", ".git", ".scannerwork", "dist", "build"}
# File timestamps use a coarser kernel clock than time.time(), so a report written right after
# `newer_than` can carry an mtime a few milliseconds before it.
MTIME_SLACK_SECONDS = 2.0


def find_lcov_reports(root: Path, newer_than: float | None = None) -> list[Path]:
    """Every coverage/lcov.info or coverage/<project>/lcov.info under root (node_modules etc. skipped).
    newer_than: only reports written after this timestamp, so a stale report committed to the
    repo is never mistaken for this run's result."""
    root = Path(root)
    found: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS]
        # coverage/lcov.info (Vitest/Jest) or coverage/<project>/lcov.info (Angular CLI / Karma)
        if LCOV_NAME in filenames and "coverage" in Path(dirpath).relative_to(root).parts[-2:]:
            path = Path(dirpath) / LCOV_NAME
            if newer_than is None or path.stat().st_mtime >= newer_than - MTIME_SLACK_SECONDS:
                found.append(path)
    return sorted(found)


def line_coverage(reports: list[Path]) -> float | None:
    """Total line coverage % across the reports (sum of LH / sum of LF), or None if no lines."""
    found = hit = 0
    for report in reports:
        for line in Path(report).read_text(encoding="utf-8", errors="replace").splitlines():
            if line.startswith("LF:"):
                found += _int(line[3:])
            elif line.startswith("LH:"):
                hit += _int(line[3:])
    if found == 0:
        return None
    return round(100.0 * hit / found, 1)


def report_paths_arg(reports: list[Path], base: Path) -> str:
    """Comma-separated paths relative to `base` (the scanner's working directory)."""
    return ",".join(Path(os.path.relpath(r, base)).as_posix() for r in reports)


def _int(text: str) -> int:
    try:
        return int(text.strip())
    except ValueError:
        return 0
