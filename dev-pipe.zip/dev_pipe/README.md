# Dev Pipeline (`.github/workflows/dev-pipe.yml`)

Runs the Dev Agent flow in GitHub Actions. Job names are numbered 1-2 to 8 in run order.

| Job | Step (job name) | Human approval before it (GitHub Issue) | Module | Output (artifact) |
|---|---|---|---|---|
| `plan` | 1-2 User Story Analysis + Development Planning | - | `s1_2_story_analysis_planning` | `dev-stage-1`: story.json, plan.md, plan.json |
| `implement` | 3 Autonomous Development (story → In Progress, code change, build) | - (plan approval not connected) | `s4_autonomous_development` | `dev-stage-2`: changes.patch, changes.md |
| `test-gates` | 4 Build + Test + Coverage (unit tests, coverage, test quality, fix loop) | - | `s6_build_test_coverage` | `dev-stage-3`: changes.patch, gates.json |
| `sonar-precheck` | 5 Sonar Pre-check before the PR (every stack; agent fix loop, build + tests re-run after each fix) | - | `s6b_sonar_precheck` | `dev-stage-3b`: changes.patch, gates.json, sonar_precheck.json |
| `create-pr` | 6 Pull Request Creation (commit, push, PR, link PR on the story, then DEV/PR tasks created, or reused from an earlier run of the story) | - | `s7_pull_request_creation` | `dev-stage-4`: pr.json, ado.json |
| `quality-gate` | 7 SonarQube Quality Validation (NO → agent fix loop) | - | `s8_sonarqube_quality_validation` | `dev-stage-5`: quality.json |
| `gate-ado` + `ado-complete` (or `request-ado-approval`, see *Approval modes*) | 8 Approval + ADO Update & Development Complete (tasks updated + closed, PR linked, summary) | `approve-ado-update` (the only gate) | `s9_ado_update_complete` | - |
| `notify-failure` | Only when a step from 3 on fails: comments "failed at Step X" + run link on the ADO story (nothing in dry run) | - | `notify_failure` | - |

Module file names keep the original 9-step diagram numbers (`s4_`, `s6_`, ...). More gates exist in
`dev_pipe/steps/gate.py` (plan, implementation, verification, tests, PR, quality) but are not wired into the workflow.

Each job downloads the previous stage's `out/` folder, adds to it and uploads it again.

**No repeated work on unchanged code:** Step 4 hands its coverage files to Step 5 (and Step 5 to Step 7, through
Step 6) in `out/coverage-files/` with a fingerprint of the code (starting commit + `changes.patch`). When the next
step has exactly that code, its first Sonar scan reuses them instead of running the same tests again; after any AI
fix, tests run as before. Step 7 also requires the PR head to still be Step 6's commit. Not used for Java/Kotlin
code (Sonar needs the compiled classes). Step 3 reuses the AI loop's last build check when the code did not change
since, and Python project dependencies are installed once per job (again only if a dependency file changes).

**Job setup** (`.github/actions/setup-dev-pipe`): AI jobs use the Claude Code CLI bundled in the `claude-agent-sdk`
package (an npm install pinned to the SDK's CLI version runs only if it is missing). Node.js is set up only for jobs
that may build a JS/TS target or run Sonar's JS/TS analysis (Steps 3, 4, 5, 7). The Sonar scanner is cached
between runs (`sonar-scanner-version` input). Step 5 first checks whether the Sonar pre-check will run
(`dev_pipe/steps/sonar_needed.py`, same rule as the step); if Sonar is off and optional, it skips the heavy setup.
Runs are queued per story (`concurrency`), so different stories run side by side. Uploads go through `.github/actions/save-stage` (one place for the settings). Middle stages
(`dev-stage-1` to `dev-stage-3b`) are kept 5 days, the stages that can end a run (`dev-stage-4`, `dev-stage-5`,
`dev-stage-approval`) 14 days, `pipeline-report` 30 days. Each stage carries everything the earlier ones had. Nothing is pushed until Step 6 (Pull Request Creation). The agent never commits, pushes or writes to ADO; the pipeline does, after approval.

## Logs and the pipeline report

Every job's log ends with one plain-English block (`dev_pipe/steplog.py`), written for people who do not read code:
a title per step, short sections (THE USER STORY, FINDING THE CODE (AAVA), THE PLAN, WRITING THE CODE, RUNNING THE
CHECKS, WHAT SONARQUBE FOUND, QUALITY GATE, ...), lines marked ✔ done / ✘ problem / → action taken, and
`Result : PASSED in 1m 20s` plus `Next : ...`. Everything technical the job printed (AI activity, build output,
scanner output) sits above it in a collapsed "Step N technical details" group on GitHub.

The pipeline report (one row per step with key facts, total time, AI sessions and fix rounds, approvals and Azure
DevOps updates) is rebuilt after every step in `out/pipeline-report.md`, shown on the run summary page when the run
ends or stops, and uploaded as the `pipeline-report` artifact by the last job.

No personal names: whoever started the run, the story's assignee and the approver appear only as a role or yes/no
(GitHub's own run page and the approval issue still show GitHub users). No secrets; long text is shortened, with the
full text in the `out/` artifacts.

## 1. One-time setup

**Secrets** (Settings > Secrets and variables > Actions > Secrets)

| Name | Used by |
|---|---|
| `ADO_PAT` | All ADO steps (Work Items: Read & Write) |
| `ANTHROPIC_API_KEY` | Agent, when `agent.backend: anthropic` |
| `AZURE_OPENAI_API_KEY` | Agent, when `agent.backend: azure_openai` |
| `SONAR_TOKEN` | Steps 5 (Sonar Pre-check) and 7 (SonarQube Quality Validation), only when `sonar.enabled: true` in `config/dev-pipe.yaml` |
| `GH_PAT` | Optional. Only if the org blocks `GITHUB_TOKEN` from creating PRs |

**Variables** (same page > Variables)

| Name | Example | Purpose |
|---|---|---|
| `ADO_ORG_URL` | `https://dev.azure.com/<org>` | ADO organization |
| `ADO_PROJECT` | `<project>` | ADO project |
| `TEST_WORK_ITEM_ID` | `12345` | Story used for push-triggered runs. **Unset = push runs do nothing** |
| `DRY_RUN` | `true` | `false` enables writes to ADO and GitHub |
| `DEV_FEEDBACK` | | Optional feedback for the agent on a re-run |
| `SONAR_HOST_URL`, `SONAR_PROJECT_KEY`, `SONAR_ORGANIZATION` | | Sonar (organization only for SonarCloud) |
| `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_DEPLOYMENT` | | Only for `agent.backend: azure_openai` |

**Approvals (GitHub Issues, works on any plan)**: at each gate the pipeline opens an issue showing what to review (plan, diff, test results...) and waits. An allowed approver comments `approve` to continue or `reject: <reason>` to stop. Setup:
- Issues must be enabled on the repo (Settings > General > Features > Issues).
- Variable `APPROVERS`: comma-separated GitHub logins allowed to approve (default: whoever started the run). Others' comments are ignored.
- Variable `APPROVAL_TIMEOUT_MINUTES` (optional, default 240): the run stops if nobody answers in time (comment mode: later answers are refused).
- **Approval modes** (variable `APPROVAL_MODE`):
  - `wait` (default, or unset): a runner waits on the issue until a decision or the timeout. Uses Actions minutes while waiting.
  - `comment`: the run opens the issue and ends (job `request-ado-approval`). The approver's comment starts the
    **Dev Pipeline approval decision** workflow (`dev-pipe-approval-decision.yml`), which runs Step 8. No runner waits.
    Requirement: that workflow file must be on the repo's **default branch** (GitHub runs `issue_comment` workflows
    only from there); until then keep `wait`. Allowed approvers, time limit and dry run are read from the run's own
    artifact (`dev-stage-approval`), not from the issue. Step 8 runs the pipeline run's own commit.
- GitHub Environments are not used; any `approve-*` environments can be deleted.

**Org setting:** Settings > Actions > General > Workflow permissions > allow GitHub Actions to create pull requests (or use `GH_PAT`).

**Settings file:** `config/dev-pipe.yaml` holds app folder, branch pattern, coverage threshold, ADO state names and retry limits.

## 2. How to run

- **Trial (now):** set `TEST_WORK_ITEM_ID`, then push to `feature/dev-pipe`. The run starts automatically, but only when the push changes a file the pipeline uses (`dev_pipe/`, `dev_agent/`, `prompts/dev/`, `config/dev-pipe.yaml`, `sample_app/`, the dev-pipe workflows, ...; see `on.push.paths` in the workflow). Otherwise use Run workflow. PRs target `feature/dev-pipe` while `git.base_branch` is empty.
- **Run workflow button (later):** once the file is on the default branch: Actions > Dev Pipeline > Run workflow, enter the story ID, dry-run choice and optional feedback.
- **Approve or reject:** open the run > *Review deployments*. Read the run summary first (plan, diff, gate results).
- **Developer Verification (manual, between Steps 3 and 4):** download `dev-stage-2` (kept 5 days; later stages contain the same files), then locally on the same commit: `git apply out/changes.patch`, run and check the app.
- **Changes needed:** reject, set `DEV_FEEDBACK` (or the `feedback` input) and re-run.

## 3. Sonar

Sonar is **on** (`sonar.enabled: true` in `config/dev-pipe.yaml`) and is checked twice:

| When | What | Blocks |
|---|---|---|
| **Step 5 job, before the PR is raised** (pre-check) | Temporary branch analysis of the agent's change on SonarQube Cloud, for **every stack** | Blocking issues on the lines the agent added or changed. The agent fixes them (up to `sonar.precheck.max_fix_attempts`, default 3); build, tests and coverage re-run after each fix; no PR until there are none |
| Step 7, after the PR is raised | PR analysis + project quality gate | Quality gate ERROR (agent fix loop on the PR branch) |

**How the pre-check works** (`dev_pipe/sonar_precheck.py`):
1. Finds the exact lines the agent changed (`git diff -U0` against the starting commit).
2. Scans with `sonar-scanner` for JS/TS (Angular), Python, Java/Kotlin (compiled classes from the build check), Go,
   and with **SonarScanner for .NET** (begin → `dotnet build` → end) for each changed .NET project. Each scan is
   uploaded as a temporary branch `devpipe-precheck/<run>`, so the main branch and PR analyses are never touched.
3. Waits until SonarQube Cloud has finished processing the analysis, then reads the branch's open issues.
4. Keeps only issues on changed lines (`block_on: changed_lines`) with severity BLOCKER/CRITICAL/MAJOR (or MQR
   impact BLOCKER/HIGH/MEDIUM). Existing issues elsewhere, and issues of other repos sharing the project key, never block.
5. Sends them to the agent to fix (up to `sonar.precheck.max_fix_attempts`), re-runs build + tests + coverage +
   scan after each fix, then deletes the temporary branches.

If the pre-check cannot run (Sonar settings missing, scanner or SonarQube Cloud error), Step 5 fails straight away
without raising a PR, because `sonar.precheck.required: true`. Set it to `false` to skip with a warning instead.

**Settings:** `SONAR_TOKEN` (secret); `SONAR_HOST_URL` (`https://sonarcloud.io`), `SONAR_PROJECT_KEY`,
`SONAR_ORGANIZATION` as variables **or** secrets (both work). External mode with several repos: map each repo to
its own key in `sonar.project_keys` (`{"owner/repo": "key"}`); unmapped repos use `SONAR_PROJECT_KEY`.
Other options under `sonar.precheck`: `max_fix_attempts`, `block_on`, `severities`, `impact_severities`, `wait_seconds`, `keep_branch`.

**Coverage sent to Sonar (Steps 5 and 7):** every report written by this run's tests, found anywhere in the repo:
LCOV (`coverage/lcov.info`, `coverage/<app>/lcov.info`), Python `coverage.xml` (Python projects with a dependency file
run pytest with pytest-cov automatically) and JaCoCo XML. With coverage sent, the "Sonar way" gate in Step 7 also
checks coverage on new code (80% by default), so thin tests now fail Step 7.

**Baseline scan (Step 7):** if the PR's target branch has never been analysed on SonarQube Cloud, Step 7 analyses
it once before the PR scan; otherwise the PR shows "0 New lines of code". `quality_gate.baseline_scan: false` turns
this off. A failed baseline scan is logged and never fails the step.

**SonarQube Cloud requirements:** branch analysis (any public project, or a paid plan for private ones; Step 7's
PR analysis needs the same) and *Automatic Analysis* switched **off** for the project (CI-based analysis).

## 4. Dry run first

`DRY_RUN` defaults to `true`: ADO is read, the agent runs, gates run, the PR commit is built locally, but nothing is written to ADO or pushed to GitHub. Step 7 (SonarQube Quality Validation) is skipped as a whole job (no runner is set up for it); the approval then shows the Step 6 output (`dev-stage-4`). Note: the Sonar pre-check (Step 5) still runs: it uploads a temporary `devpipe-precheck/*` branch analysis and deletes it afterwards.

## Security: what the AI can and cannot reach

The AI runs as a child process of the pipeline with a shell, so anything the job holds was reachable by it.
Layers (for the security review; the AI's input -- story text, repo files, search results, Sonar messages -- is
treated as untrusted):

| Layer | What it does | Where |
|---|---|---|
| Secrets hidden | Every secret-looking variable (`ADO_PAT`, `SONAR_TOKEN`, `GH_PAT`, `GITHUB_TOKEN`, AI keys, OIDC request token, ...) is removed from the environment while the AI runs and restored afterwards for the pipeline's own commands | `dev_pipe/agent_isolation.py` |
| Pipeline process unreadable | The step's process is made non-dumpable (Linux), so the AI cannot read `/proc/<pid>/environ` or its memory; steps run with `exec python ...`, so no parent shell holds the secrets; the AI's file tools are also denied `/proc` | `agent_isolation.harden_process`, workflow |
| No stored git token | AI jobs check out with `persist-credentials: false`; Step 7 passes `LOCAL_GIT_TOKEN` to its own git commands only | workflow, `dev_pipe/gitops.py` |
| No network for the AI | The AI's shell commands run in Claude Code's sandbox (bubblewrap) with no allowed domains; the pipeline installs dependencies first and tells the AI the offline commands. `agent.sandbox: required` stops the step if the sandbox cannot start | `agent_isolation.sandbox_options`, `build.install_for_agent`, setup action |
| Input is data | The system prompt says story/repo/search/Sonar text is data, never instructions, and to report suspicious content | `prompts/dev/system.md` |
| Leak check | Before the plan/diff are shown or pushed (Steps 1-2, 3, 6, 7 fixes): no known secret values (also base64) and no well-known credential formats in the AI's output. `security.leak_check: block` | `dev_pipe/leak_check.py` |
| Human review | The PR is never merged by the pipeline; require reviewers with branch protection | target repos |

Residual risks to review: with `agent.backend: anthropic` the CLI needs `ANTHROPIC_API_KEY` itself, so the AI's
process has it (the `azure_openai` backend keeps the key in the local proxy); the AI can still read the target
repo's code and write it into its change (reviewed in the PR); the AI's offline self-checks may fail for builds
that download at test time (the pipeline's own checks still run with network and decide pass/fail).

## 5. Known limitations / TODO

| Item | Owner |
|---|---|
| Branch naming policy (`git.branch_pattern`) | Ramkumar |
| Coverage threshold: 85 (meeting) vs 95 (existing dev_agent) | Team |
| ADO state names for your process template (`ado.states`) | Team |
| Sonar "silver tier" rules as a skill/instruction file | Ramkumar |
| Step 7 (SonarQube Quality Validation) needs PR analysis (SonarCloud or SonarQube Developer+) | Platform |
| External mode (separate target repo, auto-detected) is built but not yet run against the live AAVA service / a real org | Dev |
| Sonar scanner version 6.2.1.4610 is unverified (set in `.github/actions/setup-dev-pipe`, input `sonar-scanner-version`) | Dev |
| Sonar pre-check for .NET (SonarScanner for .NET) and Java (`sonar.java.binaries`) is unit-tested but not yet run against a real .NET / Java repo | Dev |
| .NET scanner takes the token as `/d:sonar.token` (its documented CI usage); output is redacted and GitHub masks the secret | Dev |
| Deleting the temporary `devpipe-precheck/*` branches needs *Administer* permission on the Sonar project for `SONAR_TOKEN`; without it they stay (logged, not fatal) until SonarQube Cloud purges inactive branches | Platform |

## 6. External mode: find the repo/branch from the story

Set `target.mode: external` in `config/dev-pipe.yaml`. The pipeline then works on an existing repo in your
GitHub org instead of `sample_app/`, and raises the PR there. The story does not need to name the repo or branch.

**How the repo and branch are chosen (Steps 1-2, `dev_pipe/resolver.py`):**

1. **Manual override:** if the `target_repo` (and optionally `target_branch`) run input is set, that is used.
2. **Base branches:** list the org's repos (GitHub REST), take each repo's base branch (`git.base_branch` if it
   exists there, else the default branch), make sure it is indexed in AAVA (`/api/index/progress`, trigger
   `/api/index` if missing), and search it with the story (`/api/search`, 3 queries from title / acceptance
   criteria / description). Best similarity ≥ `discovery.base_min_similarity` wins.
3. **Branch fallback** (nothing good on base branches): for the top `repos_for_branch_scan` repos, list the
   branches (GitHub, one GraphQL call per 100 branches), newest last commit first, and keep at most
   `discovery.max_branches_scanned` (default 50; `0` = all, the old behaviour). No name or "ahead of base"
   filter. Each kept branch is indexed in AAVA if needed and searched; the best one above `base_min_similarity`
   wins. First runs on repos with many branches are slow (first-time indexing is 49 s to ~1 h per branch);
   `aava.index_wait_seconds` caps the wait. An older branch beyond the cap can still be chosen with `target_branch`.
   GitHub look-ups, AAVA index checks and searches run `discovery.parallel_requests` at a time (default 6).
4. **Nothing qualifies:** use the most likely repo's base branch with confidence **low** and list the shortlisted
   branches with their AAVA scores in the run summary, so the reviewer can reject and re-run with
   `target_repo` / `target_branch`. Stop if there is no signal at all.

The chosen branch is where the work starts **and** the PR target, so a PR never carries someone else's unmerged
work. The run summary shows the repo, branch, confidence, AAVA matches, other candidates and the full resolution
log, and the reviewer confirms it at the plan approval gate (before Step 3). Result: `out/target.json`.

**Checkout:** every job checks the target repo out in `target-checkout/` at the exact commit chosen in Steps 1-2
(`dev_pipe/workspace.py`), applies `changes.patch`, and in Step 6 pushes the branch and opens the PR on that repo.
The token is removed from the environment before the agent runs and is never written to disk or a remote URL.

**Setup:**

| Where | Name | Purpose |
|---|---|---|
| Secret | `GH_PAT` | Token with read access to all candidate repos and contents + pull-requests write on the repos that get PRs (fine-grained PAT or GitHub App token). Also sent to AAVA for private repos (`aava.send_github_token`) |
| Variable | `DISCOVERY_ORG` | GitHub org to search (or `discovery.github_org`; default: owner of this repo) |
| Variable | `AAVA_CONTEXT_BASE_URL` | Optional; overrides `aava.base_url` |
| Config | `discovery.*`, `aava.*` | Thresholds, limits, include/exclude lists |
| Config | `target.overrides` | Optional, per repo: `app_dir`, `app_package`, `test_dir`, `language`, `build_commands` (only when detection gets it wrong) |
| Workflow | `AAVA Index` (`aava-index.yml`) | Nightly: (re)indexes every candidate repo's base branch so runs don't wait for first-time indexing. Must be on the default branch to run on schedule |

**Build + test commands are detected per repo** (`dev_pipe/stack.py`, `target.language: auto`). Every project under
`app_dir` is found from its marker files, so monorepos (`frontend/`, `backend/`, ...) work, and only the projects
that contain a changed file are built:

| Marker | Commands |
|---|---|
| `package.json` | install (`npm ci` / `yarn` / `pnpm`, picked from the lockfile), the `typecheck` script or `tsc --noEmit` when TypeScript is used, `build`, `test` |
| `pyproject.toml`, `setup.py`, `requirements.txt`, `Pipfile` (or plain `.py` files) | install the repo's own dependencies into a separate virtualenv (`requirements*.txt`, `pip install -e .[test/dev extras]`, Poetry, `Pipfile.lock`), then `compileall`, `pytest` with that virtualenv. No dependency file = the pipeline's Python, with a warning |
| `pom.xml` / `build.gradle(.kts)` | `mvn -B -q verify` / `gradle build` (wrapper used when present) |
| `*.sln`, `*.csproj` | `dotnet build`, `dotnet test` when a test project exists |
| `go.mod` | `go build`, `go vet`, `go test` |

Precedence: `target.overrides["owner/repo"]` > the target repo's own `.devpipe.yml` (same keys) > global
`target.build_commands` > detection. If nothing is detected the step fails with a clear message (it never falls back
to Python). A project **without tests passes with a warning** shown in the run summary; its test command is skipped.
The agent is given the same commands, and the pipeline re-runs them itself. Build commands run without the
pipeline's secrets in their environment (`NPM_TOKEN` / `NODE_AUTH_TOKEN` are kept for private registries).
Python coverage and test-quality gates apply to a single Python project; other stacks are gated on their
build/test commands and the Sonar pre-check (every stack). For JS/TS projects whose `test` script writes an LCOV report (`coverage/lcov.info`,
e.g. `vitest run --coverage`), Step 4 reports the line coverage (report only, not gated) and Step 7 sends
it to Sonar (`sonar.javascript.lcov.reportPaths`); otherwise coverage shows as "not measured".
Step 7 also sets `sonar.scm.revision` to the target repo's PR head commit, so Sonar can see the PR's
changed lines (without it the scanner took this pipeline repo's `GITHUB_SHA` and reported 0 new lines).

**Limits to know:**
- AAVA indexes only `.md` and `.json`. Repos with little documentation score low, so the GitHub branch signals
  (keywords, recency) and the AAVA search on the shortlisted branches carry more weight. `base_min_similarity` (0.75) must be tuned on real stories.
- The AAVA response format is parsed tolerantly (`dev_pipe/aava.py`) because the guide does not pin the exact
  JSON nesting; verify against the live service on the first run.
- One `SONAR_PROJECT_KEY` is used for every repo unless `sonar.project_keys` maps the repo to its own key.

## 7. Local test

```bash
pip install -r requirements-dev.txt
python -m pytest tests/test_dev_pipe.py tests/test_dev_pipe_external.py -q
```
