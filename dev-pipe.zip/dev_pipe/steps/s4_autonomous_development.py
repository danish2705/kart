"""Step 3: Autonomous Development (runs right after Steps 1-2 planning).

ADO: story -> In Progress only. The DEV and PR tasks are created in Step 6, once the pull request exists,
so a failed run never leaves orphan tasks (dev_pipe/steps/s7_pull_request_creation.py).
Agent: implements the plan, no unit tests yet. Pipeline: build check, change set captured as a patch.
Outputs: out/changes.patch, out/changes.md
Next: Step 4 (Build + Test + Coverage), no approval in between.
"""
from __future__ import annotations

import hashlib
import time
from typing import Callable

from dev_pipe.ado import AdoClient
from dev_pipe.agent_runner import LAST_RUN, agent_brief, changes_followup, first_of, question_followup, run_agent
from dev_pipe.build import build_check_text, check_build
from dev_pipe.config import (app_dir, feedback, is_dry_run, load_prompt, resolved_target, settings,
                             target_settings, work_root)
from dev_pipe.gitops import (changed_files_stats, changed_paths, fix_architecture_file, head_sha, risky_changes,
                             snapshot_patch)
from dev_pipe.workspace import prepare_checkout
from dev_pipe.io_utils import (append_log, cell, read_json, read_text, set_output, summary, write_bytes,
                               write_json, write_text)
from dev_pipe.report_data import command_steps
from dev_pipe.steplog import StepLog, counts_text, fmt_duration, shorten, test_counts


def update_ado_on_start(story: dict) -> bool:
    """Story -> In Progress (so the team sees the work started). Tasks are created in Step 6.
    Returns True if the state was changed (False: already in that state, e.g. a re-run)."""
    active = settings()["ado"]["states"]["story_in_progress"]
    if str(story.get("state") or "").strip().lower() == active.strip().lower():
        print(f"[ado] story #{story['id']} is already \"{active}\"; not changed", flush=True)
        return False
    AdoClient().set_state(story["id"], active)
    return True


BUILD_ERROR_CHARS = 4000


def build_followup(t: dict, changed: Callable[[], list[str]], fingerprint: Callable[[], str] | None = None,
                   last: dict | None = None) -> Callable[[str], str | None]:
    """Runs the pipeline's build check on the changed projects; on failure returns the exact errors as the
    follow-up, so the agent fixes them in the same conversation (same pattern as the Step 4 fix loop).
    last/fingerprint: the latest result is kept with a fingerprint of the code it ran on, so Step 3 can reuse
    it for its own report instead of building the same code again."""
    def check(_text: str) -> str | None:
        paths = changed()
        if not paths:
            return None
        started = time.time()
        result = check_build(t, app_dir(), [work_root() / p for p in paths])
        if last is not None and fingerprint is not None:
            last.clear()
            last.update(result=result, seconds=time.time() - started, fp=fingerprint())
        if result.ok:
            return None
        errors = result.report()[-BUILD_ERROR_CHARS:]
        return ("the build failed\n\nThe pipeline ran the build check on your changes and it FAILED:\n\n"
                f"```\n{errors}\n```\n\nFix these errors now. Re-read each affected file before editing it (it may "
                "already contain duplicated or partial code from earlier edits); remove anything duplicated, and "
                "never repeat an edit that failed or returned 'No changes to make'. Then run the build again and "
                "give your final summary.")
    return check


def main() -> None:
    with StepLog("3", "Write the code") as log:
        prepare_checkout()  # external mode: target repo at the approved base commit (no-op in local mode)
        t = target_settings()
        story = read_json("story.json")
        plan = read_text("plan.md")
        base = head_sha()
        target = resolved_target()
        log.field("Starting point", f"Repository {target.get('full_name') or 'this repository'} at commit {base[:7]}"
                  + (f" (branch {target['base_branch']})" if target.get("base_branch") else ""))

        cfg_ado = settings()["ado"]
        changed_state = update_ado_on_start(story)
        dry = " (dry run: not written)" if is_dry_run() else ""
        log.heading("Azure DevOps")
        if changed_state:
            log.ok(f"Story #{story['id']} moved from \"{story.get('state') or '?'}\" to "
                   f"\"{cfg_ado['states']['story_in_progress']}\"{dry}.")
        else:
            log.ok(f"Story #{story['id']} is already \"{cfg_ado['states']['story_in_progress']}\" (not changed).")
        log.detail("The Development and PR tasks are created in Step 6, once the pull request exists.")

        def code_changes() -> list[str]:
            return [p for p in changed_paths(base) if p != t["architecture_file"]]  # architecture file alone isn't the change

        def code_fingerprint() -> str:
            return hashlib.sha256(snapshot_patch(base)).hexdigest()

        last_build: dict = {}   # the AI loop's latest build check, reused below if the code did not change since

        answer = run_agent(
            load_prompt("implement", plan=plan, feedback=feedback() or "(none)", app_dir=t["app_dir"],
                        test_dir=t["test_dir"], architecture_file=t["architecture_file"],
                        build_check=build_check_text(t, app_dir())),
            system_prompt=load_prompt("system", app_dir=t["app_dir"]),
            edit=True,
            # Checked after the agent stops, in this order; the first problem found is sent back to it in the same
            # conversation: no edits yet -> build/tests fail (exact errors) -> it asked a question instead of finishing.
            check=first_of(changes_followup(code_changes), build_followup(t, code_changes, code_fingerprint, last_build),
                           question_followup),
            max_followups=int(settings()["gates"].get("build_fix_attempts", 3)),
            on_incomplete="warn",  # still failing: the summary + patch below are written and the step fails there
            step="implement",
        )
        followups = LAST_RUN["followups"]
        brief = agent_brief()
        moved = fix_architecture_file(base, t["architecture_file"])

        patch = snapshot_patch(base)
        from dev_pipe import leak_check   # the diff and notes are shown on the run page, then pushed in Step 6
        leak_check.enforce(leak_check.scan_patch(patch) + leak_check.scan_text(answer, "the AI's notes"),
                           "the AI's code change or notes")
        write_bytes("changes.patch", patch)
        stats = changed_files_stats(base)
        risky = risky_changes(stats)
        code_stats = [r for r in stats if r["path"] != t["architecture_file"]]

        log.heading("Writing the code")
        log.ok(f"The AI wrote the code {brief}.")
        log.detail("Files changed:" if code_stats else "Files changed: none")
        for r in code_stats[:15]:
            kind = "new file" if r["new"] else "modified"
            log.detail(f"{r['path']} {'.' * max(3, 34 - len(r['path']))} {kind:<9} "
                       f"+{r['added']} lines / -{r['removed']} lines", indent=4)
        if len(code_stats) > 15:
            log.detail(f"... and {len(code_stats) - 15} more", indent=4)
        if risky:
            log.detail("Changes to EXISTING code (please review):")
            for r in risky[:10]:
                log.detail(f"{r['path']}: {r['removed']} existing line(s) changed or removed", indent=4)
        else:
            log.detail("Only new code was added; no existing lines were changed.")
        notes = [ln.strip("-* ").strip() for ln in shorten(answer, 12) if ln.strip("-* ").strip()]
        if notes:
            log.detail("What the AI says it did:")
            for ln in notes[:8]:
                log.detail(f"- {ln[:140]}", indent=4)
        arch = t["architecture_file"]
        if moved:
            log.ok("Architecture guide: " + "; ".join(moved) + ".")
        elif (work_root() / arch).exists():
            log.ok(f"Architecture guide is in the right place ({arch}).")
        else:
            log.warn(f"No architecture guide at {arch}.")

        # Build only the projects the agent changed (all of them if detection can't tell). If the AI loop's last
        # build check ran on exactly this code, its result is reused: same code, same build, no second run.
        reused = bool(last_build) and last_build.get("fp") == hashlib.sha256(patch).hexdigest()
        if reused:
            build, build_secs = last_build["result"], last_build["seconds"]
            print("[build] same code as the last build check after the AI finished: result reused, not built again",
                  flush=True)
        else:
            build_started = time.time()
            build = check_build(t, app_dir(), [work_root() / s["path"] for s in stats] or None)
            build_secs = time.time() - build_started
        ok, build_log = build.ok, build.report()
        write_json("changes.json", {"base": base, "files": stats, "risky": risky, "build_ok": ok,
                                    "build_projects": build.projects, "build_warnings": build.warnings})
        set_output("existing_code_changed", "true" if risky else "false")
        write_text("changes.md", answer)

        counts = test_counts(build.log)
        log.heading("Our own check (we do not trust the AI's word)")
        log.ok(f"Project(s) checked : {', '.join(build.projects) or 'none detected'}")
        for label, step_ok in command_steps(build.log):
            if label == "Ran the tests":
                (log.ok if step_ok else log.fail)(f"Ran the existing tests .......... {counts_text(counts)}")
            else:
                (log.ok if step_ok else log.fail)(f"{label} {'.' * max(3, 32 - len(label))} {'OK' if step_ok else 'FAILED'}")
        log.detail(f"Build and tests took {fmt_duration(build_secs)}."
                   + (" (Run once, right after the AI finished; the code has not changed since, so it was not "
                      "run a second time.)" if reused else ""))
        for w in build.warnings:
            log.warn(w[:160])
        allowed = settings()["gates"].get("build_fix_attempts", 3)
        (log.ok if not followups else log.arrow)(f"Build fixes the AI needed ....... {followups} of {allowed} allowed")
        log.metric("fix_rounds", followups)
        log.fact(f"{len(code_stats)} file(s) changed")
        if risky:
            log.fact(f"{len(risky)} existing file(s) edited")
        log.fact("builds OK" if ok else "build FAILED")

        rows = "\n".join(f"| `{cell(r['path'])}` | {'new' if r['new'] else 'modified'} | +{r['added']} / -{r['removed']} |"
                         for r in stats) or "| (no changes) | | |"
        risky_md = "\n".join(f"- `{r['path']}`: {r['removed']} existing line(s) removed or rewritten"
                             for r in risky) or "- none"
        summary(
            f"## Step 3: Autonomous Development {'complete' if ok else 'FAILED build'}\n\n"
            f"ADO: story #{story['id']} -> In Progress{' (dry run: not written)' if is_dry_run() else ''}; "
            "DEV/PR tasks are created in Step 6 with the pull request\n\n"
            f"| File | Type | Lines |\n|---|---|---|\n{rows}\n\n"
            f"**Changes to existing code (check these):**\n{risky_md}\n\n"
            f"**Build + existing tests:** {'PASS' if ok else 'FAIL'}"
            f"{f' ({len(build.warnings)} warning(s))' if build.warnings else ''}\n```\n{build_log}\n```\n\n"
            f"<details><summary>Agent's notes</summary>\n\n{answer}\n\n</details>\n\n"
            "<details><summary>Diff</summary>\n\n```diff\n" + patch[:60000].decode("utf-8", errors="replace") + "\n```\n\n</details>\n\n"
            + "**Next (Step 4: Build + Test + Coverage):** runs automatically. Review this implementation in the PR"
            + (" (existing code was changed, check the list above)" if risky else "")
            + " before the final approval (Step 8)."
        )
        append_log(f"- Step 3 (Autonomous Development): implemented {len(stats)} file(s); {len(risky)} change(s) to existing code; "
                   f"build {'passed' if ok else 'failed'}"
                   f"{f' with {len(build.warnings)} warning(s)' if ok and build.warnings else ''}.")
        if not stats:
            raise SystemExit("The AI made no changes.")
        if not ok:
            raise SystemExit("The build or the existing tests failed after the AI's changes (details in the "
                             "technical section above).")
        log.result("PASSED", next_step="The AI writes tests and we check quality (Step 4).")


if __name__ == "__main__":
    main()
