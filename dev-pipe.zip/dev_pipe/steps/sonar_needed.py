"""Step 5, before the job's setup: is the Sonar pre-check going to run?

Writes `needed=true|false` to GITHUB_OUTPUT. `false` only when Sonar is switched off / not configured AND the
pre-check is optional (sonar.precheck.required: false); Step 5 then just passes Step 4's output through, so the
job skips the heavy setup (Claude CLI, Node, the target repo's packages, the Sonar scanner).

Uses the SAME rule as Step 5 itself (dev_pipe.config.sonar_status / sonar_precheck_required), so the two can't
drift apart. Runs on the runner's own python3 before any install: if anything is missing (e.g. PyYAML) or goes
wrong, it answers `true` (full setup, the previous behaviour), never `false` by mistake.

The real SONAR_TOKEN is not given to this step: only SONAR_TOKEN_PRESENT ("true"/"false").
"""
from __future__ import annotations

import os
import sys


def needed() -> tuple[bool, str]:
    try:
        if os.environ.get("SONAR_TOKEN_PRESENT", "").strip().lower() == "true":
            os.environ.setdefault("SONAR_TOKEN", "present")   # sonar_status() only checks that it is set
        else:
            os.environ.pop("SONAR_TOKEN", None)
        from dev_pipe.config import sonar_precheck_required, sonar_status
        enabled, reason = sonar_status()
        if enabled:
            return True, "Sonar is enabled"
        if sonar_precheck_required():
            return True, f"Sonar is not available ({reason}) but required: Step 5 runs and fails with a clear message"
        return False, f"Sonar is off or not set up ({reason}) and optional: Step 5 will skip"
    except Exception as err:  # noqa: BLE001 - any doubt = full setup (safe default)
        return True, f"could not check ({type(err).__name__}: {str(err)[:120]}); doing the full setup"


def main() -> None:
    ok, why = needed()
    print(f"[sonar-needed] {why}", flush=True)
    path = os.environ.get("GITHUB_OUTPUT")
    if path:
        with open(path, "a", encoding="utf-8") as f:
            f.write(f"needed={'true' if ok else 'false'}\n")
    else:
        sys.stdout.write(f"needed={'true' if ok else 'false'}\n")


if __name__ == "__main__":
    main()
