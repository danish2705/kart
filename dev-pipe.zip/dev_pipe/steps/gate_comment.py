"""Comment-triggered approval (APPROVAL_MODE=comment): no runner waits while the reviewer decides.

The waiting gate (dev_pipe/steps/gate.py) keeps a runner busy for up to APPROVAL_TIMEOUT_MINUTES. Here the
pipeline run only opens the approval issue and ends; the `approve` / `reject: <reason>` comment then starts
.github/workflows/dev-pipe-approval-decision.yml, which finishes the work (Step 8 ADO update).

    python -m dev_pipe.steps.gate_comment prepare approve-ado-update   # pipeline run: write out/approval-request.json
    python -m dev_pipe.steps.gate_comment open                         # pipeline run: open the issue (after upload)
    python -m dev_pipe.steps.gate_comment locate                       # decision run: which pipeline run is this?
    python -m dev_pipe.steps.gate_comment decide                       # decision run: approve / reject / ignore

Trust rules:
- The issue only carries the pipeline run ID (in a hidden marker). Everything that decides the outcome
  (allowed approvers, time limit, dry run) comes from the run's own artifact, which nobody can edit.
- The run ID is checked against the GitHub API: it must be a run of .github/workflows/dev-pipe.yml in this repo.
- Comment text is untrusted: it is only matched against two keywords (dev_pipe/approval.py), never executed.
Standard library only (the decision job starts without installing dependencies).
"""
from __future__ import annotations

import json
import os
import re
import sys
import time
from pathlib import Path

from dev_pipe.approval import GitHubIssues, decide, parse_approvers
from dev_pipe.steps.gate import GATES, OUT, build_issue
from dev_pipe.steplog import StepLog, fmt_duration, write_summary

REQUEST_FILE = "approval-request.json"
WORKFLOW_PATH = ".github/workflows/dev-pipe.yml"
MARKER_RE = re.compile(r"<!-- dev-pipe-approval run_id=(\d+) -->")


def marker(run_id: str) -> str:
    return f"<!-- dev-pipe-approval run_id={int(run_id)} -->"


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


def _output(**values) -> None:
    """Step outputs for the workflow (GITHUB_OUTPUT), also printed for the log."""
    path = _env("GITHUB_OUTPUT")
    for key, value in values.items():
        print(f"[approval] {key}={value}", flush=True)
        if path:
            with open(path, "a", encoding="utf-8") as f:
                f.write(f"{key}={value}\n")


_summary = write_summary   # one shared writer (dev_pipe/steplog.py)


def _client(gh: GitHubIssues | None) -> GitHubIssues:
    return gh or GitHubIssues(_env("GITHUB_TOKEN"), _env("GITHUB_REPOSITORY"),
                              _env("GITHUB_API_URL", "https://api.github.com"))


def _run_url(run_id: str) -> str:
    return f"{_env('GITHUB_SERVER_URL', 'https://github.com')}/{_env('GITHUB_REPOSITORY')}/actions/runs/{run_id}"


# ---------------------------------------------------------------- pipeline run
def prepare(gate: str, out: Path = OUT, now=time.time) -> dict:
    """Writes out/approval-request.json (uploaded with the stage artifact BEFORE the issue opens, so a fast
    approver never finds the artifact missing)."""
    if gate not in GATES:
        raise SystemExit(f"Unknown approval gate '{gate}'. Expected one of: {', '.join(GATES)}")
    approvers = parse_approvers(_env("APPROVERS"))
    if not approvers:
        raise SystemExit("No approvers configured. Set the APPROVERS repository variable (comma-separated GitHub logins).")
    request = {
        "gate": gate,
        "run_id": _env("GITHUB_RUN_ID"),
        "approvers": sorted(approvers),
        "timeout_minutes": int(_env("APPROVAL_TIMEOUT_MINUTES", "240") or 240),
        "dry_run": "false" if _env("DRY_RUN", "true").lower() == "false" else "true",
        "requested_at": now(),
    }
    out.mkdir(parents=True, exist_ok=True)
    (out / REQUEST_FILE).write_text(json.dumps(request, indent=2), encoding="utf-8")
    return request


def open_issue(out: Path = OUT, gh: GitHubIssues | None = None) -> dict:
    request = json.loads((out / REQUEST_FILE).read_text(encoding="utf-8"))
    gate, run_id, timeout_min = request["gate"], request["run_id"], int(request["timeout_minutes"])
    label = GATES[gate][0]
    with StepLog("8", "Human approval", key="8-approval") as log:
        note = (f"No runner waits for your answer: your comment starts the next step. "
                f"Answers after {timeout_min} minutes are refused (re-run the pipeline instead).")
        title, body = build_issue(gate, out, _run_url(run_id), set(request["approvers"]), timeout_min,
                                  wait_note=note, marker=marker(run_id))
        issue = _client(gh).create_issue(title, body)
        url = issue.get("html_url", "")
        log.ok(f"Approval request opened: GitHub issue #{issue['number']}.")
        log.detail(f"{'Authorised reviewers':<21}: {len(request['approvers'])}")
        log.detail(f"{'Time limit':<21}: {timeout_min} minutes")
        log.detail(f"{'Link':<21}: {url}")
        log.detail("This run ends now. An `approve` comment starts the \"Dev Pipeline approval decision\" "
                   "workflow, which runs Step 8.")
        _summary(f"## {label} approval: requested\n\nApprove or reject in issue {url}. Your comment starts the "
                 "**Dev Pipeline approval decision** workflow (no runner waits in the meantime).")
        log.result("WAITING", next_step="Comment `approve` or `reject: <reason>` on the issue.")
    return issue


# ---------------------------------------------------------------- decision run (issue_comment)
def _event() -> dict:
    path = _env("GITHUB_EVENT_PATH")
    if not path:
        raise SystemExit("GITHUB_EVENT_PATH is not set (this runs from an issue_comment event).")
    return json.loads(Path(path).read_text(encoding="utf-8"))


def locate(event: dict, gh: GitHubIssues | None = None) -> dict:
    """Finds and checks the pipeline run behind the commented issue. found=false = not an approval issue."""
    found = MARKER_RE.search((event.get("issue") or {}).get("body") or "")
    if not found:
        _output(found="false")
        return {"found": False}
    run_id = found.group(1)
    run = _client(gh).get_run(int(run_id))
    path = str(run.get("path") or "").split("@", 1)[0]
    if path != WORKFLOW_PATH:
        print(f"[approval] run {run_id} is not a {WORKFLOW_PATH} run ({path or 'unknown'}): ignored", flush=True)
        _output(found="false")
        return {"found": False}
    result = {"found": True, "run_id": run_id, "head_sha": run.get("head_sha", ""),
              "run_url": run.get("html_url") or _run_url(run_id)}
    _output(found="true", run_id=run_id, head_sha=result["head_sha"], run_url=result["run_url"])
    return result


def decide_comment(event: dict, out: Path = OUT, gh: GitHubIssues | None = None, now=time.time) -> str:
    """Acts on ONE new comment. Returns approve | reject | expired | none (not an approver, or no keyword)."""
    request = json.loads((out / REQUEST_FILE).read_text(encoding="utf-8"))
    issue_no = int((event.get("issue") or {})["number"])
    comment = event.get("comment") or {}
    decision = decide([comment], set(request["approvers"]))
    if decision is None:
        print("[approval] comment ignored: not from an allowed approver, or not `approve` / `reject: <reason>`",
              flush=True)
        _output(decision="none")
        return "none"

    gh = _client(gh)
    verdict, reason, login = decision
    timeout_min = int(request["timeout_minutes"])
    waited = now() - float(request["requested_at"])
    pipeline_url = _run_url(request["run_id"])
    this_run = _run_url(_env("GITHUB_RUN_ID")) if _env("GITHUB_RUN_ID") else "(this run)"
    with StepLog("8", "Human approval", key="8-approval") as log:
        if waited > timeout_min * 60:
            gh.comment(issue_no, f"This approval request expired ({timeout_min} minutes). Nothing was changed. "
                                 f"Re-run the pipeline to try again: {pipeline_url}")
            gh.close(issue_no, completed=False)
            log.fail(f"Answer came after {fmt_duration(waited)}, past the {timeout_min}-minute limit: refused.")
            log.result("TIMED OUT")
            _output(decision="expired")
            return "expired"
        if verdict == "approve":
            gh.comment(issue_no, f"Approved by @{login}. Running Step 8 (ADO Update & Development Complete): {this_run}")
            gh.close(issue_no, completed=True)
            log.ok(f"Decision: APPROVED by an authorised reviewer after {fmt_duration(waited)}.")
            log.metric("approvals", 1)
            log.result("APPROVED", next_step="Update Azure DevOps and finish (Step 8).")
            _output(decision="approve", dry_run=request.get("dry_run", "true"))
            return "approve"
        gh.comment(issue_no, f"Rejected by @{login}: {reason}\n\nNothing more runs for this pipeline run. To retry "
                             "with this feedback, set the `DEV_FEEDBACK` repository variable (or the `feedback` input) "
                             f"and re-run: {pipeline_url}")
        gh.close(issue_no, completed=False)
        log.fail(f"Decision: REJECTED by an authorised reviewer after {fmt_duration(waited)}.")
        log.detail(f"Reason: {reason[:300]}")
        log.result("REJECTED")
        _output(decision="reject")
        return "reject"


def main(argv: list[str] | None = None) -> None:
    argv = sys.argv[1:] if argv is None else argv
    command = argv[0] if argv else ""
    if command == "prepare":
        prepare(argv[1] if len(argv) > 1 else _env("GATE"))
    elif command == "open":
        open_issue()
    elif command == "locate":
        locate(_event())
    elif command == "decide":
        result = decide_comment(_event())
        if result in ("reject", "expired"):
            raise SystemExit(1)   # shows the decision run as failed, like a rejected gate in the waiting mode
    else:
        raise SystemExit("Usage: python -m dev_pipe.steps.gate_comment prepare <gate> | open | locate | decide")


if __name__ == "__main__":
    main()
