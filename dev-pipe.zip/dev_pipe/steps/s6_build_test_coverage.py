"""Step 4: Build + Test + Coverage (runs right after Step 3 Autonomous Development).

Writes unit tests, then runs build, coverage and test quality. The Sonar pre-check runs in its own job
right after this one (Step 5, dev_pipe/steps/s6b_sonar_precheck.py), which reuses run_gates/fix_loop below.

Reuses the existing gate checks in dev_agent/checks/ unchanged. Loops back to the agent with the
exact failures until all gates pass or gates.max_fix_attempts is reached.
Outputs: out/changes.patch (implementation + tests), out/gates.json
Next: Step 5 (Sonar Pre-check), then Step 6 (Pull Request Creation), no approval in between.
"""
from __future__ import annotations

import os
import time

from dev_agent.checks.coverage_gate import run_coverage_gate
from dev_agent.checks.test_quality_review import review_test_files
from dev_pipe import coverage_handover
from dev_pipe.agent_runner import agent_brief, first_of, question_followup, run_agent, tests_followup
from dev_pipe.build import build_check_text, check_build, is_python_target, prepare_python
from dev_pipe.config import (OUT, app_dir, feedback, load_prompt, settings, sonar_connection,
                             sonar_precheck_required, sonar_status, target_settings, work_root)
from dev_pipe.gitops import apply_patch, change_diff, changed_paths, fix_architecture_file, head_sha, snapshot_patch
from dev_pipe.io_utils import append_log, read_json, read_text, summary, write_bytes, write_json
from dev_pipe.lcov import find_lcov_reports, line_coverage
from dev_pipe.steplog import StepLog, counts_text, test_counts
from dev_pipe.sonar_precheck import run_precheck
from dev_pipe.report_data import file_coverage, is_test_path, new_test_names
from dev_pipe.workspace import prepare_checkout


def pct(value) -> str:
    return "not measured" if value is None else f"{value}%"


# The last Sonar pre-check result (for the Step 5 log).
LAST_PRECHECK: dict = {}


def sonar_gate(base: str, started: float | None) -> tuple[str | None, str, bool]:
    """Sonar pre-check on the agent's change, for every stack (dev_pipe/sonar_precheck.py).
    Returns (failure text for the agent or None, result label, infra_error).
    infra_error = a problem the agent cannot fix (Sonar not configured while required, scanner or
    SonarQube Cloud failure): the fix loop stops and the step fails, so no PR is raised."""
    enabled, reason = sonar_status()
    if not enabled:
        print(f"[gate] Sonar pre-check skipped: {reason}", flush=True)
        if sonar_precheck_required():
            return (f"Sonar pre-check is required (sonar.precheck.required) but cannot run: {reason}",
                    f"error ({reason})", True)
        return None, f"skipped ({reason})", False
    if not base:
        return None, "skipped (no base commit)", False
    result = run_precheck(sonar_connection(), app_dir(), work_root(), change_diff(base),
                          settings().get("sonar", {}).get("precheck") or {},
                          run_id="-".join(x for x in (os.environ.get("GITHUB_RUN_ID", ""),
                                                      os.environ.get("GITHUB_RUN_ATTEMPT", "")) if x),
                          newer_than=started)
    print(f"[gate] {result.report()}", flush=True)
    LAST_PRECHECK.clear()
    LAST_PRECHECK.update(result=result, project_key=sonar_connection()["project_key"])
    if result.status == "error":
        return f"Sonar pre-check could not run: {result.message}", result.label(), True
    if result.status == "failed":
        return result.report(), result.label(), False
    return None, result.label(), False


def run_gates(threshold: float, base: str = "", with_sonar: bool = True,
              reuse: dict | None = None) -> tuple[list[str], dict]:
    """Returns (failure descriptions, result data). Empty failures = all gates passed.
    with_sonar=False: Step 4 (build, tests, coverage, test quality only). with_sonar=True: Step 5 re-runs
    those gates AND the Sonar pre-check, so a Sonar fix that breaks a test is caught before the PR.
    reuse: {"fingerprint", "previous"}: if the previous step's coverage files are for exactly this code, they are
    restored and its results (tests, coverage, test quality) reused, so only the Sonar scan runs.
    data["sonar_infra_error"] = True when the Sonar pre-check failed for a reason the agent cannot fix."""
    t = target_settings()
    adir = app_dir()
    failures: list[str] = []
    started = time.time()

    if reuse and coverage_handover.restore(work_root(), reuse["fingerprint"], out=OUT):
        keep = {k: v for k, v in (reuse.get("previous") or {}).items()
                if k not in ("passed", "attempts", "history", "sonar_precheck", "sonar_infra_error")}
        data = {**keep, "coverage_reused": True}
        print("[gate] build/tests/coverage: results of the previous step reused (same code, not run again)",
              flush=True)
        if with_sonar:
            sonar_failure, data["sonar_precheck"], data["sonar_infra_error"] = sonar_gate(base, started)
            if sonar_failure:
                failures.append(sonar_failure)
        return failures, data

    if not is_python_target(t, adir):
        # Other stacks are gated on their build/test commands (configured, or detected from the repo's
        # files) and on the Sonar pre-check. Coverage is REPORTED (not gated) when the test run writes an
        # LCOV report (e.g. Vitest/Jest with the `lcov` reporter -> coverage/lcov.info).
        changed = [work_root() / p for p in changed_paths(base)] if base else None
        build = check_build(t, adir, changed or None)
        if not build.ok:
            failures.append(f"Build/test commands FAILED:\n{build.report()}")
        reports = find_lcov_reports(adir, newer_than=started)
        coverage = line_coverage(reports)
        if reports:
            print(f"[gate] LCOV coverage {pct(coverage)} from {len(reports)} report(s) (report only, not gated)",
                  flush=True)
        data = {"coverage_pct": coverage, "coverage_threshold": threshold, "coverage_passed": None,
                "coverage_mode": "report only (non-Python)",
                "test_quality_findings": "n/a (non-Python)",
                "build_projects": build.projects, "build_warnings": build.warnings,
                "tests": test_counts(getattr(build, "log", ""))}
        if not with_sonar:
            data["sonar_precheck"] = "runs in Step 5"
        elif build.ok:   # Sonar needs compiled code (Java binaries, .NET build); a broken build is fixed first
            sonar_failure, data["sonar_precheck"], data["sonar_infra_error"] = sonar_gate(base, started)
            if sonar_failure:
                failures.append(sonar_failure)
        else:
            data["sonar_precheck"] = "not run (build failed)"
        return failures, data

    # Install the repo's own dependencies (requirements*.txt / pyproject.toml / ...) into its virtualenv first.
    deps_ok, python, deps_log = prepare_python(adir)
    if not deps_ok:
        return [f"Installing the project's dependencies FAILED:\n{deps_log}"], {
            "coverage_pct": None, "coverage_threshold": threshold, "coverage_passed": False,
            "test_quality_findings": "n/a", "sonar_precheck": "skipped"}

    cov = run_coverage_gate(adir, package=t["app_package"], threshold=threshold, test_dir=t["test_dir"],
                            python=python)
    if not cov.passed:
        detail = cov.summary() if cov.files else f"{cov.summary()}\n{(cov.raw_stdout + cov.raw_stderr)[-2000:]}"
        failures.append(f"Coverage gate FAILED:\n{detail}")

    findings = review_test_files(sorted((adir / t["test_dir"]).rglob("test_*.py")))
    if findings:
        failures.append("Test quality gate FAILED:\n" +
                        "\n".join(f"- {f.file}::{f.test_name}: {f.reason}" for f in findings))

    sonar_failure, sonar_label, sonar_infra = (sonar_gate(base, started) if with_sonar
                                               else (None, "runs in Step 5", False))
    if sonar_failure:
        failures.append(sonar_failure)

    data = {
        "coverage_pct": round(cov.coverage_pct, 1),
        "coverage_threshold": threshold,
        "coverage_passed": cov.passed,
        "test_quality_findings": len(findings),
        "sonar_precheck": sonar_label,
        "sonar_infra_error": sonar_infra,
        "build_projects": [f"{t.get('app_dir', '.')} (python)"],
        "tests": test_counts(cov.raw_stdout),
    }
    return failures, data


def fix_loop(threshold: float, base: str, max_attempts: int, with_sonar: bool,
             step: str = "fix_gates", reuse: dict | None = None) -> tuple[list[str], dict, int]:
    """Run the gates; on failure send the exact failures to the agent and run them again, until they pass,
    max_attempts fixes were tried, or the Sonar pre-check could not run (not a code problem).
    reuse: only for the FIRST run (same code as the previous step); after an AI fix everything runs again.
    Returns (failures, data, number of gate runs)."""
    t = target_settings()
    attempt = 0
    history: list[dict] = []
    while True:
        attempt += 1
        failures, data = run_gates(threshold, base, with_sonar=with_sonar, reuse=reuse if attempt == 1 else None)
        print(f"[gate] attempt {attempt}: {data}", flush=True)
        history.append({"run": attempt, "failures": [f.splitlines()[0][:160] for f in failures],
                        "details": [ln.strip()[:160] for f in failures for ln in f.splitlines()[1:6] if ln.strip()]})
        data["history"] = history
        if not failures or attempt > max_attempts:
            break
        if data.get("sonar_infra_error"):
            print("[gate] Sonar pre-check could not run (not a code problem): stopping the fix loop", flush=True)
            break
        run_agent(
            load_prompt("fix_gates", attempt=attempt, max_attempts=max_attempts,
                        failures="\n\n".join(failures), app_dir=t["app_dir"], test_dir=t["test_dir"],
                        build_check=build_check_text(t, app_dir())),
            system_prompt=load_prompt("system", app_dir=t["app_dir"]),
            edit=True,
            step=step,
        )
        history[-1]["agent"] = agent_brief()
    return failures, data, attempt


def log_fix_loop(log: StepLog, data: dict, attempt: int, max_attempts: int) -> int:
    """Plain-English account of the fix loop. Returns the number of AI fix rounds."""
    history = data.get("history") or []
    fixes = sum(1 for h in history if h.get("agent"))
    if not history:
        return 0
    if not fixes and not history[-1]["failures"]:
        log.ok(f"Fix attempts ......... 0 of {max_attempts} allowed \u2014 everything passed on the first run")
        return 0
    for n, h in enumerate(history, 1):
        if not h["failures"]:
            log.ok(f"Check run {n}: everything passed.")
            continue
        log.fail(f"Check run {n}: {len(h['failures'])} check(s) failed.")
        for f in h["failures"]:
            log.detail(f"- {f}", indent=4)
        for d in h.get("details", [])[:4]:
            log.detail(d, indent=6)
        if h.get("agent"):
            log.arrow(f"Sent to the AI to fix (attempt {n} of {max_attempts}). The AI worked {h['agent']}.")
    return fixes


def main() -> None:
    with StepLog("4", "Test the code") as log:
        job_started = time.time()
        prepare_checkout()  # external mode: target repo at the approved base commit (no-op in local mode)
        t = target_settings()
        g = settings()["gates"]
        threshold = float(g["coverage_threshold"])
        max_attempts = int(g["max_fix_attempts"])

        base = head_sha()
        step3_files = {f["path"] for f in read_json("changes.json", default={}).get("files", [])}
        log.field("Input", f"The code from Step 3 ({len(step3_files)} file(s) changed)")
        apply_patch(OUT / "changes.patch")

        run_agent(
            load_prompt("unit_tests", plan=read_text("plan.md"), feedback=feedback() or "(none)",
                        app_dir=t["app_dir"], test_dir=t["test_dir"], app_package=t["app_package"],
                        threshold=threshold, build_check=build_check_text(t, app_dir())),
            system_prompt=load_prompt("system", app_dir=t["app_dir"]),
            edit=True,
            # Stopped without writing tests -> ask it to finish. Only a warning after that: the gates below
            # decide pass/fail (and a repo without a test setup passes with a warning).
            check=first_of(tests_followup(lambda: changed_paths(base)), question_followup), on_incomplete="warn",
            step="unit_tests",
        )
        brief = agent_brief()
        moved = fix_architecture_file(base, t["architecture_file"])
        test_files = [p for p in changed_paths(base) if p not in step3_files and is_test_path(p)]
        names = new_test_names(change_diff(base))
        new_count = sum(len(v) for v in names.values())

        failures, data, attempt = fix_loop(threshold, base, max_attempts, with_sonar=False)

        passed = not failures
        data.update({"passed": passed, "attempts": attempt})
        write_json("gates.json", data)
        patch = snapshot_patch(base)
        write_bytes("changes.patch", patch)
        if passed:   # Step 5 reuses these for its first scan instead of running the same tests again
            coverage_handover.save(app_dir(), work_root(), coverage_handover.code_fingerprint(base, patch), job_started,
                                   out=OUT)

        log.heading("Writing tests")
        log.ok(f"The AI wrote unit tests {brief}.")
        log.detail(f"{'New test file(s)':<16}: " + (", ".join(test_files[:6]) if test_files else "none"))
        all_names = [n for v in names.values() for n in v]
        for n, name in enumerate(all_names[:10]):
            log.detail(f"{'New tests' if n == 0 else '':<16}: {name}")
        if len(all_names) > 10:
            log.detail(f"{'':<16}  ... and {len(all_names) - 10} more")
        for note in moved:
            log.detail(f"Architecture guide: {note}")

        tests = data.get("tests")
        log.heading("Running the checks")
        tests_ok = not any(k in "\n".join(failures) for k in ("Build/test commands FAILED", "Installing the project"))
        detail = counts_text(tests)
        if tests and new_count:
            detail += f" ({new_count} new, {max(tests['passed'] + tests['failed'] - new_count, 0)} existing)"
        (log.ok if tests_ok else log.fail)(f"Tests ................ {detail}")
        cov = data.get("coverage_pct")
        changed_src = [p for p in changed_paths(base) if not is_test_path(p) and p != t["architecture_file"]]
        per_file = file_coverage(work_root(), changed_src)
        if data.get("coverage_mode"):
            log.ok(f"Code coverage ........ {pct(cov)} (measured, not enforced for this type of project)")
        else:
            (log.ok if data.get("coverage_passed") else log.fail)(
                f"Code coverage ........ {pct(cov)} overall   (our minimum: {threshold:g}%)")
        for path, value in list(per_file.items())[:6]:
            log.detail(f"{'':<21}{path}: {value:g}% of lines tested")
        tq = data.get("test_quality_findings")
        if isinstance(tq, int):
            (log.ok if tq == 0 else log.fail)(f"Test quality ......... {tq} problem(s)"
                                              + (" (no empty tests, every test checks a result)" if tq == 0 else ""))
        else:
            log.detail(f"Test quality ......... {tq}")
        fixes = log_fix_loop(log, data, attempt, max_attempts)
        log.metric("fix_rounds", fixes)
        for w in data.get("build_warnings") or []:
            log.warn(str(w)[:160])

        log.heading("Summary of checks")
        cov_ok = "PASS" if data.get("coverage_passed") else ("INFO" if data.get("coverage_mode") else "FAIL")
        tq_ok = "PASS" if tq == 0 else ("INFO" if not isinstance(tq, int) else "FAIL")
        log.table([["Check", "Result", "Detail"],
                   ["Build + tests", "PASS" if tests_ok else "FAIL", counts_text(tests)],
                   ["Coverage", cov_ok, f"{pct(cov)}" + ("" if data.get("coverage_mode") else f" (needs {threshold:g}%)")],
                   ["Test quality", tq_ok, f"{tq} problem(s)" if isinstance(tq, int) else str(tq)]])
        if new_count:
            log.fact(f"{new_count} new test(s)")
        if tests:
            log.fact(f"{tests['passed']} passing")
        log.fact(f"{pct(cov)} coverage")

        summary(
            f"## Step 4: Build + Test + Coverage: {'PASSED' if passed else 'FAILED'}\n\n"
            f"| Gate | Result |\n|---|---|\n"
            f"| Tests | {counts_text(tests)} |\n"
            f"| Coverage | {pct(data['coverage_pct'])} "
            f"({data['coverage_mode'] if data.get('coverage_mode') else f'threshold {threshold:g}%'}) |\n"
            f"| Test quality | {data['test_quality_findings']} finding(s) |\n"
            f"| Gate runs | {attempt} |\n\n"
            + "".join(f"> WARNING: {w}\n" for w in data.get("build_warnings") or [])
            + ("\n" if data.get("build_warnings") else "")
            + ("" if passed else "```\n" + "\n\n".join(failures)[:6000] + "\n```\n\n")
            + "**Next (Step 5: Sonar Pre-check):** scans the change on SonarQube Cloud before the pull request is raised."
        )
        append_log(f"- Step 4 (Build + Test + Coverage): unit tests written; coverage {pct(data['coverage_pct'])} "
                   f"(threshold {threshold:g}%), test quality findings {data['test_quality_findings']}.")
        if not passed:
            raise SystemExit(f"Checks still failing after {max_attempts} AI fix attempt(s).")
        log.result("PASSED", next_step="Security and quality scan before the pull request (Step 5).")


if __name__ == "__main__":
    main()
