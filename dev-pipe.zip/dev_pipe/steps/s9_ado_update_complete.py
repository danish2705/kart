"""Step 8: ADO Update & Development Complete.

Updates the DEV and PR tasks, attaches the PR link, posts the development summary to the story,
and marks the tasks done. The story itself is left for the team's normal flow (review, QA).
"""
from __future__ import annotations

from dev_pipe.ado import AdoClient
from dev_pipe.config import is_dry_run, run_url, settings
from dev_pipe.io_utils import read_json, read_text, summary
from dev_pipe.steplog import StepLog, record_step, report_to_summary


def build_summary(story: dict, pr: dict, gates: dict, quality: dict, log: str) -> str:
    return (
        f"Development summary for #{story['id']}: {story['title']}\n\n"
        f"Pull request: {pr.get('url') or '(dry run)'}\n"
        f"Branch: {pr.get('head')} -> {pr.get('base')}\n"
        f"Coverage: {'not measured' if gates.get('coverage_pct') is None else str(gates.get('coverage_pct')) + '%'} (threshold {gates.get('coverage_threshold')}%)\n"
        f"Test quality findings: {gates.get('test_quality_findings')}\n"
        f"Sonar pre-check: {gates.get('sonar_precheck')}\n"
        f"SonarQube quality gate: {quality.get('status')}\n\n"
        f"Steps:\n{log.strip()}\n\n"
        f"Pipeline run: {run_url()}"
    )


def main() -> None:
    # The approval job (Step 8 approval) runs without the out/ artifact upload, so its row is added here:
    # this job only starts after an approval.
    record_step("8-approval", "8", "Human approval", "APPROVED", ["approved by an authorised reviewer"],
                metrics={"approvals": 1})
    with StepLog("8", "Update Azure DevOps and finish", key="8-ado") as log:
        cfg = settings()["ado"]
        story = read_json("story.json")
        pr = read_json("pr.json")
        gates = read_json("gates.json")
        quality = read_json("quality.json", default={"status": "skipped"})
        ids = read_json("ado.json", default={"dev_task_id": 0, "pr_task_id": 0})
        text = build_summary(story, pr, gates, quality, read_text("summary.md", default=""))
        dry = " (dry run: not written)" if is_dry_run() else ""

        ado = AdoClient()
        ado.add_comment(story["id"], text)
        tests = gates.get("tests") or {}
        cov = gates.get("coverage_pct")
        log.ok(f"Posted the development summary on story #{story['id']}{dry}:")
        log.detail("pull request link, branch, tests" + (f" ({tests.get('passed')} passed)" if tests else "")
                   + ", coverage" + (f" ({cov}%)" if cov is not None else "")
                   + f", SonarQube pre-check ({str(gates.get('sonar_precheck', 'n/a')).split(' (')[0]}),"
                   + f" quality gate ({quality.get('status', 'n/a')}), and a short log of every step.", indent=4)
        done_work = (cfg.get("close_fields") or {}).get("Microsoft.VSTS.Scheduling.CompletedWork")
        closed = 0
        for key, label in (("dev_task_id", "Development task"), ("pr_task_id", "PR task")):
            task_id = ids.get(key)
            if not task_id:
                log.warn(f"{label}: none to close (it was not created in Step 6).")
                continue
            if pr.get("url"):
                ado.add_hyperlink(task_id, pr["url"], f"Pull request #{pr.get('number')}")
            ado.add_comment(task_id, text)
            ado.set_state(task_id, cfg["states"]["task_done"], cfg.get("close_fields") or {})
            closed += 1
            log.ok(f"{label} #{task_id:<8}: " + ("pull request linked → " if pr.get("url") else "")
                   + cfg["states"]["task_done"]
                   + (f" (work recorded: {done_work} hour(s))" if done_work and key == "dev_task_id" else "") + dry)
        log.detail(f"Story #{story['id']} stays \"{cfg['states']['story_in_progress']}\" so the team can move it to "
                   "review or QA.")
        log.fact(f"{closed} task(s) closed" if not is_dry_run() else "dry run: nothing written")

        summary(
            f"## Step 8: ADO Update & Development Complete {'(dry run: nothing written)' if is_dry_run() else 'complete'}\n\n"
            f"Story #{story['id']} summary posted; DEV #{ids.get('dev_task_id')} and PR #{ids.get('pr_task_id')} "
            f"tasks -> {cfg['states']['task_done']}.\n\n```\n{text}\n```"
        )
        log.result("PASSED", next_step="The story is ready for code review.")
    report_to_summary()


if __name__ == "__main__":
    main()
