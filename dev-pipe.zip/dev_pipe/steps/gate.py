"""Human approval gate (steps 3 to 9): opens a GitHub Issue and waits for `approve` / `reject: <reason>`.

    python -m dev_pipe.steps.gate approve-plan

Reads the previous stage's out/ folder to show the reviewer what they are approving.
Exit code 0 = approved (pipeline continues); non-zero = rejected or timed out (pipeline stops).
Standard library only (see dev_pipe/approval.py).
"""
from __future__ import annotations

import json
import os
import re
import sys
import time
from pathlib import Path

from dev_pipe.approval import GitHubIssues, parse_approvers, wait_for_decision
from dev_pipe.steplog import StepLog, fmt_duration, write_summary

OUT = Path("out")
MAX_SECTION = 20000  # characters per section; GitHub issue bodies are limited to 65,536

# gate -> (diagram step, question for the reviewer, sections to show: (label, file, kind))
GATES: dict[str, tuple[str, str, list[tuple[str, str, str]]]] = {
    "approve-plan": ("Plan approval (before Step 3)", "Approve the development plan?",
                     [("Development plan", "plan.md", "markdown")]),
    "approve-implementation": ("Step 3 (Autonomous Development)", "Approve the implementation (code changes)?",
                               [("Agent's notes", "changes.md", "markdown"),
                                ("Changes to EXISTING code (check these carefully)", "changes.json", "risky"),
                                ("Diff", "changes.patch", "diff")]),
    "approve-changes": ("Developer Verification (before Step 4)", "Developer verification: did you test the change and does it work?",
                        [("How to verify", "", "verify_help"),
                         ("Files changed", "changes.json", "files")]),
    "approve-tests": ("Step 4 (Build + Test + Coverage)", "OK for the agent to write unit tests and run build, coverage and quality checks?",
                      [("Files changed so far", "changes.json", "files")]),
    "approve-pr": ("Step 6 (Pull Request Creation)", "OK to commit, push, raise the pull request and link it to the ADO story?",
                   [("Quality gate results", "gates.json", "json"),
                    ("Final diff (code + tests)", "changes.patch", "diff")]),
    "approve-quality-fix": ("Step 7 (SonarQube Quality Validation)", "OK to run the SonarQube quality gate on the PR and let the agent push fixes?",
                            [("Pull request", "pr.json", "json")]),
    "approve-ado-update": ("Step 8 (ADO Update & Development Complete)", "OK to post the development summary and close the DEV/PR tasks in ADO?",
                           [("Development log", "summary.md", "markdown"),
                            ("SonarQube quality gate", "quality.json", "json")]),
}

HOW_TO = """### How to respond
Comment on this issue with one of:
- `approve` to continue to the next step
- `reject: <reason>` to stop the pipeline (re-run with the reason in `DEV_FEEDBACK` so the agent can correct it)
"""


def _clip(text: str) -> str:
    return text if len(text) <= MAX_SECTION else text[:MAX_SECTION] + "\n\n... (truncated, see the run page for the full content)"


VERIFY_HELP = """1. Open the pipeline run (link above) and download the `dev-stage-2` artifact.
2. In your local clone, on the same commit as the run: `git apply out/changes.patch`
3. Run the app and tests, and check the change does what the story asks.
4. Undo locally when done: `git checkout -- . && git clean -fd` (careful: discards local changes)."""


def _section(label: str, path: Path, kind: str) -> str:
    if kind == "verify_help":
        return f"### {label}\n\n{VERIFY_HELP}\n"
    if not path.exists():
        return ""
    if kind == "diff":
        text = path.read_bytes().decode("utf-8", errors="replace").strip()
        return f"### {label}\n\n````diff\n{_clip(text) or '(no changes)'}\n````\n" if text else ""
    raw = path.read_text(encoding="utf-8", errors="replace")
    if kind in ("risky", "files"):
        data = json.loads(raw)
        rows = data.get("risky" if kind == "risky" else "files", [])
        empty = "- none (only new code was added)" if kind == "risky" else "- none"
        lines = [f"- `{r['path']}`: +{r['added']} / -{r['removed']}" for r in rows] or [empty]
        return f"### {label}\n\n" + "\n".join(lines) + "\n"
    if kind == "json":
        return f"### {label}\n\n````json\n{_clip(raw.strip())}\n````\n"
    return f"### {label}\n\n{_clip(raw.strip())}\n"


def build_issue(gate: str, out: Path, run_url: str, approvers: set[str], timeout_min: int,
                wait_note: str = "", marker: str = "") -> tuple[str, str]:
    """wait_note replaces the default "waits up to N minutes" line; marker (an HTML comment) is appended,
    used by the comment-triggered approval (dev_pipe/steps/gate_request.py)."""
    step, question, sections = GATES[gate]
    story = {}
    if (out / "story.json").exists():
        story = json.loads((out / "story.json").read_text(encoding="utf-8"))
    story_ref = f"#{story.get('id')} {story.get('title', '')}".strip() if story else "(unknown story)"
    title = f"[Dev Pipeline] {step}: {question[:80]} | Story {story_ref}"[:250]
    body = "\n".join([
        f"## {step}: {question}",
        f"**Story:** {story_ref}  ",
        f"**Pipeline run:** {run_url} (full summary and downloadable artifacts)",
        "",
        *[s for s in (_section(label, out / name if name else out, kind) for label, name, kind in sections) if s],
        "---",
        HOW_TO,
        f"Allowed approvers: {', '.join('@' + a for a in sorted(approvers))}. "
        + (wait_note or f"The pipeline waits up to {timeout_min} minutes, then stops."),
        *([marker] if marker else []),
    ])
    return title, body


_summary = write_summary   # one shared writer (dev_pipe/steplog.py)


def main(argv: list[str] | None = None, gh: GitHubIssues | None = None, waiter=wait_for_decision) -> None:
    argv = sys.argv[1:] if argv is None else argv
    gate = (argv[0] if argv else os.environ.get("GATE", "")).strip()
    if gate not in GATES:
        raise SystemExit(f"Unknown approval gate '{gate}'. Expected one of: {', '.join(GATES)}")
    label = GATES[gate][0]
    found = re.search(r"Step (\d+)", label)
    number = found.group(1) if found else "-"
    with StepLog(number, "Human approval", key=f"{number}-approval") as log:
        approvers = parse_approvers(os.environ.get("APPROVERS", ""))
        if not approvers:
            raise SystemExit("No approvers configured. Set the APPROVERS repository variable (comma-separated GitHub logins).")
        timeout_min = int(os.environ.get("APPROVAL_TIMEOUT_MINUTES", "240") or 240)

        server = os.environ.get("GITHUB_SERVER_URL", "https://github.com")
        repo = os.environ.get("GITHUB_REPOSITORY", "")
        run_url = f"{server}/{repo}/actions/runs/{os.environ.get('GITHUB_RUN_ID', '')}"
        gh = gh or GitHubIssues(os.environ.get("GITHUB_TOKEN", ""), repo,
                                os.environ.get("GITHUB_API_URL", "https://api.github.com"))

        title, body = build_issue(gate, OUT, run_url, approvers, timeout_min)
        issue = gh.create_issue(title, body)
        issue_no, issue_url = issue["number"], issue.get("html_url", "")
        log.ok(f"Approval request opened: GitHub issue #{issue_no} (includes the pull request link and check results).")
        log.detail(f"{'Authorised reviewers':<21}: {len(approvers)}")
        log.detail(f"{'Time limit':<21}: {timeout_min} minutes")
        log.detail(f"{'Link':<21}: {issue_url}")
        _summary(f"## {label} approval: waiting\n\nApprove or reject in issue {issue_url}")

        # Stop polling ~2 minutes before the job's own timeout so the issue is always closed cleanly.
        started = time.time()
        decision = waiter(gh, issue_no, approvers, timeout_s=max(60, (timeout_min - 2) * 60))
        waited = fmt_duration(time.time() - started)

        if decision is None:
            gh.comment(issue_no, f"No decision within {timeout_min} minutes. The pipeline has stopped. Re-run it to try again.")
            gh.close(issue_no, completed=False)
            _summary(f"**Timed out** waiting for approval ({timeout_min} min). Pipeline stopped.")
            log.fail(f"No decision within {timeout_min} minutes. The pipeline stopped; re-run it to try again.")
            log.result("TIMED OUT")
            raise SystemExit(1)

        verdict, reason, login = decision
        if verdict == "approve":
            gh.comment(issue_no, f"Approved by @{login}. Continuing with the pipeline: {run_url}")
            gh.close(issue_no, completed=True)
            _summary(f"**Approved** by an allowed approver in {issue_url}")
            log.ok(f"Decision: APPROVED by an authorised reviewer after {waited}.")
            log.metric("approvals", 1)
            log.result("APPROVED", next_step="Update Azure DevOps and finish (Step 8).")
            return

        gh.comment(issue_no, f"Rejected by @{login}: {reason}\n\nThe pipeline has stopped. To retry with this feedback, "
                             "set the `DEV_FEEDBACK` repository variable (or the `feedback` input) and re-run.")
        gh.close(issue_no, completed=False)
        _summary(f"**Rejected** by an allowed approver: {reason}")
        log.fail(f"Decision: REJECTED by an authorised reviewer after {waited}.")
        log.detail(f"Reason: {reason[:300]}")
        log.detail("To retry, re-run the pipeline with this reason as feedback for the AI.")
        log.result("REJECTED")
        raise SystemExit(1)

if __name__ == "__main__":
    main()
