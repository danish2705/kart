"""Step 5: Sonar Pre-check, its own job between Step 4 (Build + Test + Coverage) and Step 6 (Pull Request
Creation). No pull request is raised until this passes.

Applies Step 4's change set (implementation + unit tests) to the same starting commit, then scans it on
SonarQube Cloud for every stack (dev_pipe/sonar_precheck.py). Blocking issues on the lines the agent changed
go back to the agent; after each fix the build, tests, coverage and test-quality gates run AGAIN together
with the scan (Step 4's run_gates), so a Sonar fix can never break what Step 4 already passed.

Outputs: out/changes.patch (updated with any Sonar fixes), out/gates.json (updated), out/sonar_precheck.json
Next: Step 6 (Pull Request Creation), no approval in between.
"""
from __future__ import annotations

import time

from dev_pipe import coverage_handover
from dev_pipe.config import OUT, app_dir, resolved_target, settings, sonar_precheck_required, sonar_status, work_root
from dev_pipe.gitops import apply_patch, head_sha, snapshot_patch
from dev_pipe.io_utils import append_log, read_json, summary, write_bytes, write_json
from dev_pipe.steplog import StepLog, counts_text, fmt_duration
from dev_pipe.steps.s6_build_test_coverage import LAST_PRECHECK, fix_loop, log_fix_loop, pct
from dev_pipe.workspace import fetch_base_ref, prepare_checkout

DEFAULT_FIX_ATTEMPTS = 3


def main() -> None:
    with StepLog("5", "Quality and security check") as log:
        enabled, reason = sonar_status()
        if not enabled and not sonar_precheck_required():
            # Optional and switched off / not configured: pass the Step 4 output through unchanged.
            write_json("sonar_precheck.json", {"status": "skipped", "reason": reason})
            gates = read_json("gates.json", default={})
            gates["sonar_precheck"] = f"skipped ({reason})"
            write_json("gates.json", gates)
            summary(f"## Step 5: Sonar Pre-check: skipped ({reason})\n\n"
                    "**Next (Step 6: Pull Request Creation):** commits, pushes and opens the pull request automatically.")
            append_log(f"- Step 5 (Sonar Pre-check): skipped ({reason}).")
            log.warn(f"SonarQube check is switched off or not set up ({reason}), and it is optional, so it was skipped.")
            log.fact("skipped")
            log.result("SKIPPED", next_step="Create the pull request (Step 6).")
            return

        job_started = time.time()
        prepare_checkout()  # external mode: target repo at the approved base commit (no-op in local mode)
        fetch_base_ref(resolved_target().get("base_branch", ""))  # reference branch for the scanner
        cfg = settings()
        threshold = float(cfg["gates"]["coverage_threshold"])
        pre = cfg.get("sonar", {}).get("precheck") or {}
        max_attempts = int(pre.get("max_fix_attempts", DEFAULT_FIX_ATTEMPTS))

        base = head_sha()
        step4_patch = (OUT / "changes.patch").read_bytes() if (OUT / "changes.patch").exists() else b""
        apply_patch(OUT / "changes.patch")

        # Same code as Step 4 -> its coverage files and test results are reused for the first scan (no second test
        # run). Java/Kotlin: Sonar needs the compiled classes, so the build + tests run as before.
        reuse = None if coverage_handover.has_java(app_dir()) else {
            "fingerprint": coverage_handover.code_fingerprint(base, step4_patch),
            "previous": read_json("gates.json", default={})}
        failures, data, attempt = fix_loop(threshold, base, max_attempts, with_sonar=True, step="fix_sonar",
                                           reuse=reuse)

        passed = not failures
        infra = bool(data.get("sonar_infra_error"))
        gates = {**read_json("gates.json", default={}), **data, "passed": passed}
        write_json("gates.json", gates)
        write_json("sonar_precheck.json", {"status": "passed" if passed else ("error" if infra else "failed"),
                                           "result": data.get("sonar_precheck"), "gate_runs": attempt})
        final_patch = snapshot_patch(base)
        write_bytes("changes.patch", final_patch)
        if passed:   # Step 7 reuses these for its first PR scan if the PR still holds exactly this code
            coverage_handover.save(app_dir(), work_root(), coverage_handover.code_fingerprint(base, final_patch),
                                   job_started, out=OUT)

        result = LAST_PRECHECK.get("result")
        d = result.details if result else {}
        log.field("Input", f"Code and tests from Step 4 ({d.get('changed_files', 'n/a')} files, "
                           f"{d.get('changed_lines', 'n/a')} new or changed lines)")

        log.heading("The scan")
        if result and result.status != "error":
            log.ok("Scanned with SonarQube Cloud (project: " + LAST_PRECHECK.get("project_key", "?") + ").")
            langs = d.get("languages") or []
            log.detail(f"{'Languages scanned':<18}: " + (", ".join(langs) if langs else "not reported")
                       + (f" ({d['files_indexed']} files in total)" if d.get("files_indexed") else ""))
            secs = d.get("processing_seconds") or []
            log.detail(f"{'Time on SonarQube':<18}: {fmt_duration(sum(secs)) if secs else 'not available'}")
            cov = d.get("coverage") or []
            log.detail(f"{'Test coverage sent':<18}: " + (", ".join(cov) if cov else "none (no coverage report written)"))
        elif result:
            log.fail(f"SonarQube could not run: {result.message}")
        else:
            log.fail(f"SonarQube could not run: {data.get('sonar_precheck')}")

        if result and result.status != "error":
            history = data.get("history") or []
            fixes = sum(1 for h in history if h.get("agent"))
            log.heading("What SonarQube found" + (f" (final scan, after {fixes} fix round(s))" if fixes else ""))
            log.kv("Issues in the whole project", d.get("total_issues", "n/a"), indent=2, width=48)
            log.kv("Issues in the AI's new or changed lines", f"{len(result.blocking)}   ← only these can block",
                   indent=2, width=48)
            log.kv("Older issues (not part of this story)", f"{result.ignored}   → ignored", indent=2, width=48)
            sev = "/".join(s.title() for s in pre.get("severities", ["BLOCKER", "CRITICAL", "MAJOR"]))
            log.detail(f"Blocking rule: {sev} issues in the new lines")
            for i in result.blocking[:15]:
                loc = f"{i['path']}, line {i['line']}" if i.get("line") else i["path"]
                log.fail(f"[{str(i['severity']).title()}] {loc} — {i['message'][:110]} (rule {i['rule']})")

        log.heading("After the scan")
        tests = data.get("tests")
        history = data.get("history") or []
        if data.get("coverage_reused") and not any(h.get("agent") for h in history):
            log.ok(f"Tests: not run again (same code as Step 4, whose results and coverage were reused): "
                   f"{counts_text(tests)}.")
        else:
            (log.ok if tests and not tests.get("failed") else log.warn)(
                f"Tests run again after the scan: {counts_text(tests)}.")
        fixes = log_fix_loop(log, data, attempt, max_attempts)
        log.metric("fix_rounds", fixes)
        if d.get("branches"):
            (log.ok if d.get("deleted") else log.warn)(
                "Temporary scan data on SonarQube was deleted." if d.get("deleted")
                else "Temporary scan data on SonarQube was kept.")
        log.fact(f"{len(result.blocking) if result else 'n/a'} problems in new code"
                 + (f" ({result.ignored} older issues ignored)" if result and result.ignored else ""))
        if fixes:
            log.fact(f"{fixes} AI fix round(s)")

        summary(
            f"## Step 5: Sonar Pre-check: {'PASSED' if passed else ('COULD NOT RUN' if infra else 'FAILED')}\n\n"
            f"| Check | Result |\n|---|---|\n"
            f"| Sonar pre-check (changed lines) | {data.get('sonar_precheck')} |\n"
            f"| Build + tests re-run | {counts_text(data.get('tests'))} |\n"
            f"| Coverage | {pct(data.get('coverage_pct'))} |\n"
            f"| Gate runs | {attempt} (agent fix attempts allowed: {max_attempts}) |\n\n"
            + ("" if passed else "```\n" + "\n\n".join(failures)[:6000] + "\n```\n\n")
            + ("**Next (Step 6: Pull Request Creation):** commits, pushes and opens the pull request automatically."
               if passed else "**No pull request is raised.**")
        )
        append_log(f"- Step 5 (Sonar Pre-check): {data.get('sonar_precheck')} after {attempt} run(s).")
        if not passed:
            raise SystemExit("SonarQube could not run, so no pull request is raised." if infra
                             else f"Problems are still there after {max_attempts} AI fix attempt(s); no pull request is raised.")
        log.result("PASSED", summary="no known problems in the new code, safe to open the pull request.",
                   next_step="Create the pull request (Step 6).")


if __name__ == "__main__":
    main()
