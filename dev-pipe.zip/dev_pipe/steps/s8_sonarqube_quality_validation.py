"""Step 7: SonarQube Quality Validation on the PR, with the NO -> fix loop from the diagram.

Skipped (and reported as skipped) when sonar.enabled is false, Sonar is not fully configured, or in dry run.
Outputs: out/quality.json
"""
from __future__ import annotations

import os
import subprocess
import tempfile
import time
from pathlib import Path

import requests

from dev_agent.checks.coverage_gate import run_coverage_gate
from dev_pipe import coverage_handover
from dev_pipe.agent_runner import agent_brief, run_agent
from dev_pipe.build import check_build, is_python_target, prepare_python
from dev_pipe.config import (app_dir, is_dry_run, load_prompt, settings, sonar_project_key, sonar_status,
                             target_settings, work_root)
from dev_pipe.gitops import changed_paths, configure_identity, git
from dev_pipe.io_utils import append_log, read_json, read_text, summary, write_json
from dev_pipe.steplog import StepLog, counts_text, fmt_duration, test_counts
from dev_pipe.sonar_precheck import ScanUnit, SonarApi, coverage_args, java_args, read_task_id, run_cli_scan
from dev_pipe.sonar import (evaluate_gate, fetch_gate, fetch_pr_issues, fetch_pr_measures, issues_text, run_pr_scan,
                            debug_enabled, scanner_debug_args, scanner_diag_lines, scanner_problems,
                            scanner_scm_lines, scanner_tail)
from dev_pipe.workspace import prepare_full_clone


NEXT_STEP = ("**Next (Step 8: ADO Update & Development Complete):** the only approval issue opens next. Review the PR "
             "on GitHub, then comment `approve` to post the development summary and close the DEV/PR tasks in ADO.")


def skip(reason: str) -> None:
    write_json("quality.json", {"status": "skipped", "reason": reason})
    summary(f"## Step 7: SonarQube Quality Validation: skipped ({reason})\n\n" + NEXT_STEP)
    append_log(f"- Step 7 (SonarQube Quality Validation): skipped ({reason}).")


def fetch_history_for_sonar(base: str) -> None:
    """Sonar finds a PR's new lines by diffing against origin/<base> and needs full history for blame.
    The external-mode checkout is a depth-1 clone with no origin/<base> ref, which made Sonar report
    "0 New Lines of Code" plus shallow-clone / missing-ref warnings."""
    if git("rev-parse", "--is-shallow-repository", check=False) == "true":
        git("fetch", "-q", "--unshallow", "origin")
    git("fetch", "-q", "origin", f"+refs/heads/{base}:refs/remotes/origin/{base}")


def git_diagnostics(base_ref: str) -> None:
    """Debug mode: the git facts the scanner depends on to find the PR's changed lines."""
    print("[sonar-debug] git --version: " + git("--version", check=False), flush=True)
    print("[sonar-debug] index version: " + (git("update-index", "--show-index-version", check=False) or "n/a"),
          flush=True)
    print("[sonar-debug] repo: " + git("rev-parse", "--show-toplevel", "--git-dir", "--is-shallow-repository",
                                       check=False).replace("\n", " | "), flush=True)
    cfg = [ln for ln in git("config", "--show-origin", "--list", check=False).splitlines()
           if not any(s in ln.lower() for s in ("extraheader", "token", "password", "authorization", "credential"))]
    print("[sonar-debug] git config (secrets removed):\n  " + "\n  ".join(cfg[:60]), flush=True)
    diff = git("diff", "-U0", "--no-color", base_ref + "...HEAD", "--", "*.py", check=False)
    print("[sonar-debug] git diff -U0 (Python files, first 40 lines):\n" + "\n".join(diff.splitlines()[:40]), flush=True)


def save_debug(scan, attempt: int) -> None:
    """Debug mode: full scanner output to out/ (uploaded with the dev-stage-5 artifact) + the diagnostic lines."""
    from dev_pipe.config import OUT
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / f"sonar-scanner-step7-attempt{attempt}.log"
    text = (scan.stdout or "") + "\n" + (scan.stderr or "")
    for secret in (os.environ.get("SONAR_TOKEN", ""), os.environ.get("TARGET_GITHUB_TOKEN", "")):
        if secret:
            text = text.replace(secret, "***")   # the artifact is not masked by GitHub, so never keep a token
    path.write_text(text, encoding="utf-8")
    print(f"[sonar-debug] full scanner output saved to out/{path.name} (artifact dev-stage-5)", flush=True)
    for line in scanner_diag_lines(scan):
        print(f"[sonar-debug] {line}", flush=True)


def ensure_base_analysed(conn: dict, base: str, pr_head: str, wait_seconds: int) -> str:
    """SonarQube Cloud compares a PR with its target branch. If that branch (or, when it is unknown, the
    project's main branch) has never been analysed, the PR shows "0 New lines of code" and no measures.
    This runs one analysis of the target branch first, only when needed. Never fails the step.
    Returns a one-line result for the step log."""
    if not settings()["quality_gate"].get("baseline_scan", True):
        return "not checked (quality_gate.baseline_scan is off)"
    api = SonarApi(conn["host"], conn["token"], conn["project_key"])
    try:
        branches = api.branches()
    except requests.RequestException as err:
        print(f"[sonar-baseline] could not list branches ({type(err).__name__}); skipped", flush=True)
        return f"could not check ({type(err).__name__})"
    hit = next((b for b in branches if b.get("name") == base), None)
    main = next((b for b in branches if b.get("isMain")), None)
    if hit and hit.get("analysisDate"):
        print(f"[sonar-baseline] target branch '{base}' already analysed ({hit['analysisDate']})", flush=True)
        return f"yes (last analysis {str(hit['analysisDate'])[:10]})"
    as_main = (hit or {}).get("isMain") or not (main and main.get("analysisDate"))
    label = "the project's main branch" if as_main else f"branch '{base}'"
    print(f"[sonar-baseline] '{base}' has no analysis on SonarQube Cloud: analysing it once as {label}", flush=True)
    outcome = "no -> baseline scan skipped"
    try:
        git("checkout", "-q", "--detach", f"origin/{base}")
        started = time.time()
        with tempfile.TemporaryDirectory(prefix="devpipe-sonar-") as tmp:
            metadata = Path(tmp) / "report-task.txt"
            unit = ScanUnit("baseline", "cli", app_dir(), "" if as_main else base)
            scan = run_cli_scan(unit, conn, metadata, [f"-Dsonar.scm.revision={git('rev-parse', 'HEAD')}"]
                                + java_args(app_dir()))
            task = read_task_id(metadata, app_dir(), started)
        if scan.returncode != 0 or not task:
            print(f"[sonar-baseline] scan failed (exit {scan.returncode}); PR analysis continues\n{scanner_tail(scan)}",
                  flush=True)
            outcome = f"no -> baseline scan failed (exit {scan.returncode}); PR analysis continues"
        else:
            status, err = api.wait_for_task(task, wait_seconds, 5)
            print(f"[sonar-baseline] analysis {status} {err}".rstrip(), flush=True)
            outcome = f"no -> analysed once now as {label} ({status.lower()}, {fmt_duration(time.time() - started)})"
    except (RuntimeError, OSError, SystemExit, requests.RequestException, subprocess.SubprocessError) as err:
        print(f"[sonar-baseline] skipped: {err}", flush=True)
        outcome = f"no -> baseline scan skipped ({str(err)[:80]})"
    finally:
        git("checkout", "-q", "-B", pr_head, f"origin/{pr_head}")
    return outcome


# Values gathered during the scan, for the Step 7 log.
LAST_SCAN: dict = {}

_METRICS = {
    "new_violations": "New issues", "new_coverage": "Coverage on new code",
    "new_duplicated_lines_density": "Duplicated lines on new code",
    "new_security_hotspots_reviewed": "Security hotspots reviewed", "new_reliability_rating": "Reliability rating",
    "new_security_rating": "Security rating", "new_maintainability_rating": "Maintainability rating",
    "new_software_quality_blocker_issues": "New blocker issues", "new_software_quality_high_issues": "New high issues",
}
_PERCENT = {"new_coverage", "new_duplicated_lines_density", "new_security_hotspots_reviewed"}


def _value(metric: str, value) -> str:
    if value in (None, ""):
        return "n/a"
    if metric.endswith("_rating"):
        try:
            return "ABCDE"[int(float(value)) - 1]
        except (ValueError, IndexError):
            return str(value)
    if metric in _PERCENT:
        try:
            return f"{float(value):.1f}%"
        except ValueError:
            return str(value)
    return str(value)


def gate_table(status: dict) -> list[str]:
    """QUALITY GATE section: every condition with actual, required and result."""
    rows = [f"{'Condition':<34}{'Actual':<10}{'Required':<12}Result"]
    for c in status.get("conditions") or []:
        metric = c.get("metricKey", "")
        sign = {"LT": ">=", "GT": "<="}.get(c.get("comparator", ""), c.get("comparator", ""))
        required = f"{sign} {_value(metric, c.get('errorThreshold'))}"
        result = {"OK": "OK", "ERROR": "FAILED", "WARN": "WARN"}.get(c.get("status", ""), c.get("status", "n/a"))
        rows.append(f"{_METRICS.get(metric, metric)[:33]:<34}{_value(metric, c.get('actualValue')):<10}"
                    f"{required:<12}{result}")
    if len(rows) == 1:
        rows.append("(no conditions returned by SonarQube Cloud)")
    return rows


def scan_context_args(t: dict, base: str, started: float | None = None, reused: bool = False) -> list[str]:
    """Extra scanner properties for the PR checkout:
    - sonar.scm.revision: the PR head commit of the TARGET repo. Without it the scanner (which detects
      GitHub Actions) takes GITHUB_SHA, the pipeline repo's commit, which does not exist in the target
      repo, so Sonar could not tell which lines the PR changed ("0 New lines of code").
    - non-Python: runs the changed projects' build/test commands so their test runs write coverage.
    - coverage reports written by this run (LCOV, coverage.xml, JaCoCo, anywhere under app_dir) are passed
      to the scanner (dev_pipe/sonar_precheck.coverage_args).
    reused=True: Step 5's coverage files for exactly this code were restored, so the build/tests are not run."""
    args = [f"-Dsonar.scm.revision={git('rev-parse', 'HEAD')}"]
    if is_python_target(t, app_dir()):
        return args + _coverage(started)
    merge_base = git("merge-base", f"origin/{base}", "HEAD", check=False)
    if not reused:
        changed = [work_root() / p for p in changed_paths(merge_base)] if merge_base else None
        started = time.time()
        build = check_build(t, app_dir(), changed or None)
        LAST_SCAN["tests"] = test_counts(build.log)
        if not build.ok:
            print("[sonar] WARNING: build/test commands failed before the scan; coverage may be missing",
                  flush=True)
    if merge_base and debug_enabled():
        # Diagnostics (SONAR_SCANNER_DEBUG=true): the scanner compares the merge base with the files ON DISK.
        print("[sonar] working tree vs merge base just before the scan (git diff --stat):\n"
              + (git("diff", "--stat", merge_base, check=False)[-2000:] or "(empty)"), flush=True)
        print("[sonar] git status --short:\n" + (git("status", "--short", check=False)[-1500:] or "(clean)"), flush=True)
        repo_cfg = [ln for ln in git("config", "--local", "--list", check=False).splitlines()
                    if ln.split("=", 1)[0].startswith(("core.", "extensions.", "index."))]
        print("[sonar] git repo config: " + "; ".join(repo_cfg), flush=True)
        print(f"[sonar] .gitattributes present: {(app_dir() / '.gitattributes').exists()}", flush=True)
    return args + _coverage(started)


def _coverage(started: float | None) -> list[str]:
    cov = coverage_args(app_dir(), started)
    LAST_SCAN["coverage"] = [a.split("=", 1)[1] for a in cov]
    if cov:
        print("[sonar] sending coverage: " + "; ".join(cov), flush=True)
    else:
        print("[sonar] no coverage report written by the test run; coverage will show as 0% "
              "(JS/TS: an LCOV reporter, e.g. `vitest run --coverage`; Python: pytest-cov writes coverage.xml)",
              flush=True)
    return cov


def main() -> None:
    with StepLog("7", "Quality gate on the pull request") as log:
        cfg = settings()
        qg, t = cfg["quality_gate"], target_settings()
        pr = read_json("pr.json")
        enabled, reason = sonar_status()
        if not enabled or is_dry_run() or not pr.get("number"):
            why = reason if not enabled else "dry run, no PR"
            skip(why)
            log.warn(f"Nothing to check: {why}.")
            log.fact(f"skipped ({why})")
            log.result("SKIPPED", next_step="Waiting for human approval (Step 8).")
            return
        log.field("Input", f"Pull request #{pr['number']} ({pr['head']} into {pr['base']})")

        token = os.environ["SONAR_TOKEN"]
        key, host = sonar_project_key(), os.environ["SONAR_HOST_URL"]
        org = os.environ.get("SONAR_ORGANIZATION", "")
        # External mode: a regular full clone of the target repo (no-op in local mode). The shallow
        # checkout from prepare_checkout made the scanner find 0 changed lines on the PR.
        prepare_full_clone()
        t = target_settings()  # re-read now that the checkout (and any .devpipe.yml in it) exists
        configure_identity()
        git("fetch", "origin", pr["head"])
        git("checkout", "-B", pr["head"], f"origin/{pr['head']}")
        fetch_history_for_sonar(pr["base"])
        baseline = ensure_base_analysed({"host": host, "token": token, "project_key": key, "organization": org},
                                        pr["base"], pr["head"], int(qg.get("wait_seconds", 300)))
        if baseline.startswith("yes"):
            when = baseline.split("last analysis", 1)[-1].strip(" )") if "last analysis" in baseline else ""
            log.ok(f"\"{pr['base']}\" already has a SonarQube baseline" + (f" (last analysed {when})" if when else "")
                   + ", so the pull request can be compared.")
        elif baseline.startswith("no ->"):
            log.ok(f"\"{pr['base']}\" had no SonarQube baseline yet: " + baseline[5:].strip() + ".")
        else:
            log.detail(f"Baseline check: {baseline}.")
        base_ref = "origin/" + pr["base"]
        pr_files = git("diff", "--name-only", base_ref + "...HEAD", check=False).splitlines()
        if debug_enabled():
            # Diagnostics for "0 New lines of code" on the PR (SONAR_SCANNER_DEBUG=true): what git sees as the change.
            print(f"[sonar-debug] HEAD {git('rev-parse', 'HEAD', check=False)} | "
                  f"{base_ref} {git('rev-parse', base_ref, check=False)} | "
                  f"merge-base {git('merge-base', base_ref, 'HEAD', check=False)}", flush=True)
            print("[sonar-debug] PR diff vs base (git diff --stat):\n"
                  + (git("diff", "--stat", base_ref + "...HEAD", check=False)[-3000:] or "(empty)"), flush=True)
            git_diagnostics(base_ref)
        log.ok("Pull request size : " + (git("diff", "--shortstat", base_ref + "...HEAD", check=False).strip()
                                           or "no changes"))

        max_attempts = int(qg.get("max_fix_attempts", 2))
        attempt, passed, conditions, issues, status, measures = 0, False, [], [], {}, {}
        history: list[str] = []
        # First scan: if the PR still holds exactly Step 6's commit (nobody pushed since) and there is no Java/Kotlin
        # code (Sonar needs compiled classes), reuse Step 5's coverage files and test results instead of running
        # the same tests again. After an AI fix in the loop below, the tests run as before.
        can_reuse = (bool(pr.get("commit")) and git("rev-parse", "HEAD") == pr["commit"]
                     and not coverage_handover.has_java(app_dir()))
        while True:
            attempt += 1
            started = time.time()
            LAST_SCAN.clear()
            reused = (attempt == 1 and can_reuse
                      and bool(coverage_handover.restore(work_root(), pr.get("code_fingerprint", ""))))
            if reused:
                LAST_SCAN["tests"] = read_json("gates.json", default={}).get("tests")
            elif is_python_target(t, app_dir()):
                _, python, _ = prepare_python(app_dir())  # the repo's own dependencies, in its virtualenv
                cov = run_coverage_gate(app_dir(), package=t["app_package"], test_dir=t["test_dir"],
                                        python=python)  # writes coverage.xml
                LAST_SCAN["tests"] = test_counts(cov.raw_stdout)
            waited = time.time()
            scan = run_pr_scan(str(app_dir()), key, host, token, org, pr, int(qg.get("wait_seconds", 300)),
                               extra_args=scan_context_args(t, pr["base"], started, reused=reused) + scanner_debug_args())
            print(f"[sonar] scanner exit {scan.returncode}", flush=True)
            for line in scanner_problems(scan):
                print(f"[sonar] {line}", flush=True)
            if debug_enabled():
                for line in scanner_scm_lines(scan, pr_files):  # how the scanner found the PR's changed lines
                    print(f"[sonar-debug] {line}", flush=True)
                save_debug(scan, attempt)
            measures = fetch_pr_measures(host, token, key, pr["number"])
            print(f"[sonar] stored on SonarCloud for PR {pr['number']}: {measures}", flush=True)
            if scan.returncode != 0:
                print(f"[sonar] scanner output (last lines):\n{scanner_tail(scan)}", flush=True)
            status = fetch_gate(host, token, key, pr["number"])
            passed, conditions = evaluate_gate(status)
            issues = fetch_pr_issues(host, token, key, pr["number"])
            print(f"[sonar] attempt {attempt}: {'OK' if passed else 'ERROR'} {conditions}", flush=True)
            history.append(f"Check {attempt}: quality gate {'passed' if passed else 'FAILED'} "
                           f"({len(issues)} open issue(s); scan + processing {fmt_duration(time.time() - waited)})")
            history += [f"  - {c}" for c in conditions]
            if passed or attempt > max_attempts:
                break
            run_agent(
                load_prompt("fix_quality_gate", pr_number=pr["number"], attempt=attempt, max_attempts=max_attempts,
                            conditions="\n".join(f"- {c}" for c in conditions) or "(none reported)",
                            issues=issues_text(issues), plan=read_text("plan.md"),
                            app_dir=t["app_dir"], test_dir=t["test_dir"]),
                system_prompt=load_prompt("system", app_dir=t["app_dir"]),
                edit=True,
                step="fix_quality_gate",
            )
            history.append(f"  -> sent to the AI agent to fix (worked {agent_brief()}); the fix was pushed to the pull request")
            build = check_build(t, app_dir())
            if not build.ok:
                raise SystemExit(f"Build failed after the quality-gate fix:\n{build.report()}")
            git("add", "-A", "--", t["app_dir"])
            from dev_pipe import leak_check   # nothing that looks like a credential is pushed to the PR
            leak_check.enforce(leak_check.scan_patch(git("diff", "--cached", "--", t["app_dir"])),
                               "the AI's quality-gate fix")
            git("commit", "-m", f"Fix SonarQube quality gate findings (attempt {attempt})")
            git("push", "origin", pr["head"])

        tests = LAST_SCAN.get("tests")
        cov_sent = LAST_SCAN.get("coverage") or []
        if reused:   # the last scan used Step 5's files (no fix round changed the code)
            log.ok(f"Tests: not run again (the pull request holds exactly the code Step 5 tested; its results and "
                   f"coverage were reused): {counts_text(tests)}. "
                   + ("Coverage report sent to SonarQube." if cov_sent else "No coverage report was available."))
        else:
            (log.ok if tests and not tests.get("failed") else log.warn)(
                f"Tests run again for coverage: {counts_text(tests)}. "
                + ("Coverage report sent to SonarQube." if cov_sent else "No coverage report was written."))
        new_lines = measures.get("new_lines") if isinstance(measures, dict) else None
        log.ok("SonarQube analysed the pull request"
               + (f" ({new_lines} new lines of code)" if new_lines not in (None, "") else "") + ".")
        if new_lines in (None, "", "0", 0):
            log.warn("SonarQube recorded no new lines for this pull request, so coverage rules could not be checked.")

        status_word = status.get("status", "n/a")
        log.heading(f"Quality gate: {'PASSED' if status_word == 'OK' else 'FAILED' if status_word == 'ERROR' else status_word}")
        rows = [["Rule", "Result", "Required", "Status"]]
        for c in status.get("conditions") or []:
            metric = c.get("metricKey", "")
            sign = {"LT": "at least", "GT": "at most"}.get(c.get("comparator", ""), c.get("comparator", ""))
            rows.append([_METRICS.get(metric, metric), _value(metric, c.get("actualValue")),
                         f"{sign} {_value(metric, c.get('errorThreshold'))}",
                         {"OK": "OK", "ERROR": "FAILED"}.get(c.get("status", ""), c.get("status", ""))])
        if len(rows) > 1:
            log.table(rows)
        else:
            log.detail("SonarQube returned no rules for this quality gate.")

        (log.ok if not issues else log.warn)(f"Open issues on the pull request: {len(issues)}")
        for i in issues[:10]:
            comp = str(i.get("component", "")).split(":", 1)[-1]
            log.detail(f"[{str(i.get('severity', '')).title()}] {comp}"
                       + (f", line {i['line']}" if i.get("line") else "") + f" \u2014 {str(i.get('message', ''))[:110]}")
        fixes = sum(1 for h in history if "sent to the AI agent" in h)
        if fixes:
            log.heading("Fix rounds")
            for h in history:
                log.detail(h.replace("  -> sent to the AI agent to fix", "\u2192 Sent to the AI to fix"))
        (log.ok if not fixes else log.arrow)(f"Fix attempts: {fixes} of {max_attempts} allowed.")
        link = f"{host.rstrip('/')}/summary/new_code?id={key}&pullRequest={pr['number']}"
        log.ok(f"Full report: {link}")
        log.metric("fix_rounds", fixes)
        log.fact(f"gate {'passed' if passed else 'FAILED'}")
        if isinstance(measures, dict) and measures.get("new_coverage") not in (None, ""):
            log.fact(f"{_value('new_coverage', measures['new_coverage'])} coverage on new code")
        if issues:
            log.fact(f"{len(issues)} open issue(s)")

        write_json("quality.json", {"status": "passed" if passed else "failed", "attempts": attempt,
                                    "conditions": conditions, "open_issues": len(issues), "report": link})
        summary(
            f"## Step 7: SonarQube Quality Validation: {'PASSED' if passed else 'FAILED'}\n\n"
            f"Attempts: {attempt} | Open issues on PR: {len(issues)} | [SonarQube report]({link})\n\n"
            + ("\n".join(f"- {c}" for c in conditions) or "")
            + ("\n\n" + NEXT_STEP if passed else "")
        )
        append_log(f"- Step 7 (SonarQube Quality Validation): quality gate {'passed' if passed else 'failed'} after {attempt} run(s).")
        if not passed:
            raise SystemExit("The quality gate is still failing after the AI's fix attempts. Fix it on the pull "
                             "request branch, then re-run this job.")
        log.result("PASSED", next_step="Waiting for human approval (Step 8).")


if __name__ == "__main__":
    main()
