"""Posts "pipeline run failed at Step X" on the ADO story when a run fails after Step 3 started.

Step 3 moves the story to Active, so without this a failed run leaves an Active story with no pull request
and nobody knows why. Runs as the last job of the Dev Pipeline (`notify-failure`, only on failure).

Input: NEEDS_JSON = the workflow's `toJSON(needs)` (each job's result). Skipped in dry run (AdoClient).
Never fails the run a second time: an ADO error is printed as a warning.
"""
from __future__ import annotations

import json
import os

from dev_pipe.config import run_url, work_item_id

# Workflow job id -> what to tell the team. In run order: the first failed job is the one reported.
JOBS = [
    ("implement", "Step 3 (Autonomous Development: writing the code)"),
    ("test-gates", "Step 4 (Build + Test + Coverage)"),
    ("sonar-precheck", "Step 5 (Sonar Pre-check)"),
    ("create-pr", "Step 6 (Pull Request Creation)"),
    ("quality-gate", "Step 7 (SonarQube Quality Validation)"),
    ("gate-ado", "Step 8 (approval: rejected or no answer in time)"),
    ("request-ado-approval", "Step 8 (opening the approval request)"),
    ("ado-complete", "Step 8 (ADO Update & Development Complete)"),
]
PR_RAISED_AFTER = {"quality-gate", "gate-ado", "request-ado-approval", "ado-complete"}


def failed_step(needs: dict) -> tuple[str, str] | None:
    """(job id, label) of the first failed job, or None (nothing failed after Step 3 started)."""
    for job, label in JOBS:
        if (needs.get(job) or {}).get("result") == "failure":
            return job, label
    return None


def message(job: str, label: str, url: str) -> str:
    if job in PR_RAISED_AFTER:
        state = "The pull request was raised; its Development and PR tasks stay open until this is resolved."
    elif job == "create-pr":
        state = ("The pull request and/or its Development and PR tasks may not have been created. The story was "
                 "moved to Active when the run started.")
    else:
        state = ("No pull request was raised and no tasks were created. The story was moved to Active when the "
                 "run started.")
    return (f"Dev Agent pipeline run failed at {label}.\n{state}\n"
            f"Details (plain-English log per step): {url}\n"
            "To retry: fix the cause (or give the AI feedback in DEV_FEEDBACK) and re-run the pipeline. "
            "A re-run reuses this story's open tasks; it does not create duplicates.")


def main() -> None:
    needs = json.loads(os.environ.get("NEEDS_JSON") or "{}")
    found = failed_step(needs)
    if not found:
        print("[notify] no failed step after Step 3 started; nothing to post", flush=True)
        return
    job, label = found
    text = message(job, label, run_url())
    print(f"[notify] {text}", flush=True)
    try:
        from dev_pipe.ado import AdoClient
        AdoClient().add_comment(work_item_id(), text)
    except (SystemExit, Exception) as err:   # noqa: BLE001 - reporting only, the run has already failed
        print(f"[notify] WARNING: could not post the comment on the ADO story: {str(err)[:300]}", flush=True)


if __name__ == "__main__":
    main()
