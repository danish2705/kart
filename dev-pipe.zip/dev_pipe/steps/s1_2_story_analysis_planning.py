"""Step 1 (User Story Analysis) + Step 2 (Development Planning).

Fetches the ADO story. In external mode, also finds the target repo + branch (GitHub REST + AAVA Code
Context Service, see dev_pipe/resolver.py), checks it out in target-checkout/ and gives the agent the AAVA
code matches. Then reads the architecture context file and generates the development plan.

Outputs: out/story.json, out/plan.md, out/plan.json (+ out/target.json in external mode)
Next: Step 3 (Autonomous Development), no approval in between. The chosen repo/branch is not
confirmed by a human, so check the run summary and cancel the run if it is wrong.
"""
from __future__ import annotations

import json
import os
import re
import time

from dev_pipe.ado import AdoClient
from dev_pipe.agent_runner import agent_brief, extract_json_block, plan_followup, run_agent, strip_json_block
from dev_pipe.config import (branch_name, feedback, is_dry_run, is_external, load_prompt, run_url, settings,
                             target_settings, work_item_id, work_root)
from dev_pipe.io_utils import append_log, cell, summary, write_json, write_text
from dev_pipe.steplog import StepLog, fmt_duration, numbered, shorten, story_link, trigger_text


def resolve_target(story: dict) -> dict:
    from dev_pipe.aava import Aava
    from dev_pipe.github_api import GitHub
    from dev_pipe.resolver import Resolver
    from dev_pipe.workspace import take_token

    cfg = settings()
    d = dict(cfg.get("discovery") or {})
    d["github_org"] = (d.get("github_org") or os.environ.get("DISCOVERY_ORG")
                       or os.environ.get("GITHUB_REPOSITORY_OWNER", ""))
    d["aava"] = cfg.get("aava") or {}
    d["base_branch"] = cfg.get("git", {}).get("base_branch", "")
    token = take_token()
    if not token:
        raise SystemExit("Missing TARGET_GITHUB_TOKEN (GH_PAT secret): needed to list and read the target repos.")
    a = d["aava"]
    aava = Aava(os.environ.get("AAVA_CONTEXT_BASE_URL") or a.get("base_url", ""),
                github_token=token if a.get("send_github_token", True) else "")
    return Resolver(GitHub(token), aava, d).resolve(
        story, os.environ.get("TARGET_REPO", "").strip(), os.environ.get("TARGET_BRANCH", "").strip())


def target_summary(target: dict) -> str:
    if not target:
        return ""
    alts = "\n".join(f"| {cell(a['full_name'])} | `{cell(a['branch'])}` | {a['similarity']} | {a['signal']} | "
                     f"{cell(a.get('last_commit', '')[:10])} | {cell(a.get('evidence', ''), 160)} |"
                     for a in target.get("alternatives", [])) or "| (none) | | | | | |"
    matches = "\n".join(f"- `{cell(m['filePath'])}:{m.get('startLine')}-{m.get('endLine')}` ({m['similarity']:.2f})"
                        for m in target.get("matches", [])[:8]) or "- (none)"
    warn = ("\n\n> **Low confidence: check the repo/branch below now.** If it is wrong, cancel this run and "
            "re-run with the `target_repo` / `target_branch` inputs." if target["confidence"] == "low" else "")
    return (
        f"### Target repository\n\n**{target['full_name']}** branch `{target['base_branch']}` "
        f"(commit `{target['base_sha'][:10]}`); confidence **{target['confidence']}**; {target['reason']}{warn}\n\n"
        f"PR will target `{target['base_branch']}`.\n\n"
        f"**AAVA matches used as context:**\n{matches}\n\n"
        f"<details{' open' if target['confidence'] == 'low' else ''}><summary>Other candidates</summary>\n\n"
        f"| Repo | Branch | AAVA similarity | Keyword score | Last commit | Evidence |\n"
        f"|---|---|---|---|---|---|\n{alts}\n\n</details>\n\n"
        f"<details><summary>Resolution log</summary>\n\n```\n" + "\n".join(target.get("trace", []))[:6000]
        + "\n```\n\n</details>\n\n"
    )


def plan_risks(plan_md: str, limit: int = 3) -> list[str]:
    """First bullet points under the plan's '## Risks and open questions' heading."""
    m = re.search(r"^##\s*Risks[^\n]*\n(.*?)(?=^##\s|\Z)", plan_md or "", re.M | re.S)
    items = [re.sub(r"^\s*[-*\d.)]+\s*", "", ln).strip() for ln in (m.group(1).splitlines() if m else [])]
    items = [i for i in items if i and i.lower() not in ("none", "none.", "n/a")]
    return [i[:140] for i in items[:limit]]


def main() -> None:
    wid = work_item_id()
    with StepLog("1-2", "Understand the story and plan the work") as log:
        log.field("Started", trigger_text().replace(" | ", "  |  "))
        log.field("Mode", "Dry run (nothing is written to Azure DevOps or GitHub)" if is_dry_run()
                  else "Live run (Azure DevOps and GitHub will be updated)")

        started = time.time()
        story = AdoClient().get_work_item(wid)
        criteria = numbered(story.get("acceptance_criteria", ""))
        log.heading("The user story")
        log.ok(f"Read story #{wid} from Azure DevOps in {fmt_duration(time.time() - started)}.")
        log.detail(f"{'Title':<12}: {story.get('title') or 'not available'}")
        log.detail(f"{'Type/State':<12}: {story.get('type') or '?'} / {story.get('state') or '?'}")
        log.detail(f"{'Assigned':<12}: {'Yes' if story.get('assigned_to') else 'No'}   |   "
                   f"Sprint: {story.get('iteration_path') or 'not set'}   |   Area: {story.get('area_path') or 'not set'}")
        log.detail(f"{'Link':<12}: {story_link(story)}")
        desc = shorten(story.get("description"), 12, "full text in story.json")
        log.detail(f"{'Description':<12}: {desc[0]}")
        for ln in desc[1:]:
            log.detail(f"{'':<14}{ln}")
        log.detail(f"Acceptance criteria ({len(criteria)}):")
        for n, c in enumerate(criteria[:15], 1):
            log.detail(f"{n}. {c[:150]}", indent=4)
        if len(criteria) > 15:
            log.detail(f"... and {len(criteria) - 15} more (full text in story.json)", indent=4)
        if not story["description"] and not story["acceptance_criteria"]:
            raise SystemExit(f"Story #{wid} has no description or acceptance criteria to implement.")
        write_json("story.json", story)
        log.fact(f"{len(criteria)} acceptance criteria")

        target: dict = {}
        code_context = "(local mode: no code context service lookup)"
        log.heading("Finding the code (AAVA)")
        if is_external():
            from dev_pipe.resolver import code_context as format_context
            from dev_pipe.workspace import prepare_checkout
            target = resolve_target(story)
            write_json("target.json", target)
            prepare_checkout(target)
            code_context = format_context(target)
            log.ok(f"Repository chosen : {target['full_name']}, branch \"{target['base_branch']}\" "
                   f"(commit {target['base_sha'][:7]})")
            manual = target.get("found_on") == "manual"
            log.detail(f"{'How it was chosen':<18}: " + ("Named in the run settings; AAVA was used to find the relevant files."
                                                         if manual else f"AAVA search ({target.get('reason', '')}), "
                                                         f"confidence {target.get('confidence', '?')}."))
            state = str(target.get("index_state") or "").upper()
            log.detail(f"{'AAVA index status':<18}: " + {
                "COMPLETED": "Already indexed (no new indexing needed).",
                "DONE": "Already indexed (no new indexing needed).",
                "NOT_INDEXED": "Not indexed; AAVA could not be searched for this branch.",
            }.get(state, f"{state.title() or 'Unknown'}"))
            if target.get("queries"):
                log.detail(f"AAVA searched with {target['queries']} questions taken from the story "
                           "(title, acceptance criteria, description).")
            matches = target.get("matches") or []
            if matches:
                log.detail("Top matches given to the AI as context:")
                for m in matches[:5]:
                    log.detail(f"- {m.get('filePath')}, lines {m.get('startLine') or '?'}-{m.get('endLine') or '?'} "
                               f"(match {float(m.get('similarity') or 0):.2f})", indent=4)
            else:
                log.detail("AAVA returned no matches; the AI explores the repository itself.")
            alts = target.get("alternatives") or []
            if alts:
                log.detail(f"Other repositories/branches considered: {len(alts)} (match scores: "
                           + ", ".join(f"{a.get('similarity')}" for a in alts[:5]) + ")")
            if target.get("confidence") == "low":
                log.warn("Low confidence in the repository choice. If it is wrong, cancel and re-run with target_repo.")
        else:
            log.ok(f"Working in this repository (app folder {target_settings()['app_dir']}); AAVA is not used in local mode.")

        t = target_settings()
        arch_path = work_root() / t["architecture_file"]
        if arch_path.exists():
            architecture = arch_path.read_text(encoding="utf-8")
            log.ok(f"Architecture guide found: {t['architecture_file']} ({len(architecture.splitlines())} lines).")
            log.detail("The AI used it instead of reading the whole codebase, which saves time and AI cost.")
        else:
            architecture = (f"(No {t['architecture_file']} found. Explore only what you need; "
                            "it will be created during implementation.)")
            log.warn(f"No architecture guide at {t['architecture_file']}; the AI will create one in Step 3.")
        target_line = (f"{target['full_name']} @ {target['base_branch']} ({target['reason']})" if target
                       else "this repository")
        if feedback():
            log.ok("Reviewer feedback from an earlier run was given to the AI.")

        hint = branch_name(wid, story["title"])
        answer = run_agent(
            load_prompt("plan", story=json.dumps({k: v for k, v in story.items() if k != "assigned_to"}, indent=2),  # no personal data in prompts/logs
                        architecture=architecture,
                        feedback=feedback() or "(none)", app_dir=t["app_dir"], branch_hint=hint,
                        target=target_line, code_context=code_context),
            system_prompt=load_prompt("system", app_dir=t["app_dir"]),
            edit=False,
            check=plan_followup,  # stopped early / no ```json block -> ask it to finish (same conversation)
            step="plan",
        )
        meta = extract_json_block(answer)
        meta["branch"] = branch_name(wid, story["title"], meta.get("branch", ""))
        plan_md = strip_json_block(answer)
        from dev_pipe import leak_check   # the plan is shown on the run page and in the approval issue
        leak_check.enforce(leak_check.scan_text(answer, "the plan"), "the AI's plan")
        write_text("plan.md", plan_md)
        write_json("plan.json", meta)

        files = meta.get("files") or []
        log.heading("The plan")
        log.ok(f"The AI wrote the development plan {agent_brief()}.")
        log.detail(f"{'Branch name':<17}: {meta['branch']}")
        changes = [f for f in files if str(f.get("action", "")).lower() != "create"]
        creates = [f for f in files if str(f.get("action", "")).lower() == "create"]
        for label, group in (("Files to change", changes), ("Files to create", creates)):
            for n, f in enumerate(group):
                log.detail(f"{label if n == 0 else '':<17}: {f.get('path')}  → {str(f.get('reason', ''))[:90]}")
        if not files:
            log.detail(f"{'Files':<17}: none listed")
        modifies = meta.get("modifies_existing_code")
        log.detail(f"{'Existing code':<17}: " + ("will change" if modifies else "no changes to existing code"
                                                  if modifies is False else "not stated"))
        tests = [str(c) for c in meta.get("test_cases") or []]
        for n, c in enumerate(tests[:8], 1):
            log.detail(f"{'Test cases' if n == 1 else '':<17}: {n}. {c[:120]}")
        if not tests:
            log.detail(f"{'Test cases':<17}: none listed")
        est = meta.get("estimate_hours")
        log.detail(f"{'Estimate':<17}: " + (f"{est} hour(s)" if est not in (None, "") else "not given"))
        questions = [str(q) for q in meta.get("open_questions") or []]
        log.detail(f"{'Open questions':<17}: " + ("; ".join(q[:120] for q in questions[:3]) if questions else "None"))
        risks = plan_risks(plan_md)
        log.detail(f"{'Risks noted':<17}: " + ("; ".join(risks) if risks else "None"))
        log.fact(f"{len(files)} file(s) planned")
        if est not in (None, ""):
            log.fact(f"{est}h estimate")

        files_md = "\n".join(f"| {cell(f.get('action'))} | `{cell(f.get('path'))}` | {cell(f.get('reason'))} |"
                             for f in files)
        summary(
            f"## Steps 1-2: User Story Analysis + Development Planning (story #{wid})\n\n"
            f"**{cell(story['title'], 200)}** ({story['type']}, {story['state']}, "
            f"{'assigned' if story['assigned_to'] else 'not assigned'})\n\n"
            + target_summary(target)
            + f"Architecture file: {'found' if arch_path.exists() else 'not found (will be created)'} | "
            f"Branch: `{meta['branch']}` | Estimate: {meta.get('estimate_hours', '?')}h | "
            f"Changes existing code: {meta.get('modifies_existing_code', '?')}\n\n"
            f"| Action | File | Reason |\n|---|---|---|\n{files_md}\n\n"
            f"<details><summary>Full plan</summary>\n\n{plan_md}\n\n</details>\n\n"
            "**Next (Step 3: Autonomous Development):** runs automatically, no approval here. If the plan"
            + (" or the target repo/branch" if target else "")
            + " looks wrong, cancel the run and re-run with your reason in the `feedback` input."
        )
        append_log(f"- Steps 1-2 (User Story Analysis + Development Planning): plan generated for #{wid} "
                   f"(branch `{meta['branch']}`"
                   + (f", repo {target['full_name']} from `{target['base_branch']}`" if target else "")
                   + f"). Run: {run_url()}")
        log.result("PASSED", next_step="The AI writes the code (Step 3).")


if __name__ == "__main__":
    main()
