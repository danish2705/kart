"""Deterministic build + test check (the agent also runs these, but the pipeline doesn't trust it).

Which commands run, in order of precedence:
  1. target.build_commands (config/dev-pipe.yaml, a per-repo target.overrides entry, or the target
     repo's own .devpipe.yml) -- run as given in app_dir.
  2. Auto-detection (dev_pipe/stack.py): every project under app_dir is found from its marker files
     (package.json, pyproject.toml, pom.xml, ...). If the changed files are known, only the projects
     that contain a change are built. target.language (if not "auto") limits detection to that stack.
  3. Nothing detected -> the check FAILS with a clear message (it never guesses Python).

A project without tests passes with a warning; its test command is skipped.
"""
from __future__ import annotations

import os
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from dev_pipe.stack import (Command, detect_projects, python_env, python_project, select_projects,
                            stacks_for_language)

COMMAND_TIMEOUT_SECONDS = 30 * 60
LOG_TAIL_LINES = 30

# Pipeline secrets are removed from the environment of build/test commands: those commands come from the
# target repo (package.json scripts, .devpipe.yml) and must not be able to read them.
_SECRET_NAME = re.compile(r"(TOKEN|_KEY|_PAT|SECRET|PASSWORD)$|^(ADO_PAT|GH_PAT|ANTHROPIC_|AZURE_OPENAI_API)", re.I)
_ALLOWED_SECRETS = {"NPM_TOKEN", "NODE_AUTH_TOKEN"}  # needed for private package registries


@dataclass
class BuildUnit:
    label: str            # e.g. "frontend (node)"
    cwd: Path
    commands: list[Command]
    agent_commands: list[Command] = field(default_factory=list)   # offline variant for the sandboxed AI
    install_commands: list[Command] = field(default_factory=list)  # run by the pipeline before the AI


def sandboxed() -> bool:
    """True when the AI's shell runs without network (agent.sandbox not 'off'): it is then told the offline
    build/test commands, and the pipeline installs dependencies before it starts."""
    from dev_pipe.config import settings
    return str((settings().get("agent") or {}).get("sandbox", "required")).strip().lower() != "off"


@dataclass
class BuildPlan:
    units: list[BuildUnit] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    error: str = ""       # set when nothing can be built


@dataclass
class BuildResult:
    ok: bool
    log: str
    warnings: list[str] = field(default_factory=list)
    projects: list[str] = field(default_factory=list)

    def report(self) -> str:
        """Log plus warnings, for run summaries."""
        head = f"Projects: {', '.join(self.projects) or 'none'}\n"
        warn = "".join(f"WARNING: {w}\n" for w in self.warnings)
        return (head + warn + ("\n" if warn else "") + self.log).strip()


def build_commands(t: dict) -> list[str]:
    return [c for c in (t.get("build_commands") or []) if str(c).strip()]


def is_python_target(t: dict, app_dir: Path) -> bool:
    """True when the Python coverage + test-quality gates apply: no custom build commands, and either
    language is set to python or detection finds exactly one Python project at app_dir itself."""
    if build_commands(t):
        return False
    lang = str(t.get("language") or "auto").strip().lower()
    if lang in ("python", "py"):
        return True
    if lang not in ("", "auto"):
        return False
    projects = detect_projects(app_dir, t.get("test_dir") or "tests")
    return len(projects) == 1 and projects[0].stack == "python" and projects[0].path == app_dir.resolve()


def plan_build(t: dict, app_dir: Path, changed: list[Path] | None = None) -> BuildPlan:
    app_dir = Path(app_dir).resolve()
    cmds = build_commands(t)
    if cmds:
        configured = [Command(c) for c in cmds]
        return BuildPlan([BuildUnit(f"{t.get('app_dir', '.')} (configured)", app_dir, configured, configured)])

    test_dir = t.get("test_dir") or "tests"
    language = str(t.get("language") or "auto")
    wanted = stacks_for_language(language)
    projects = detect_projects(app_dir, test_dir)
    if wanted is not None:
        projects = [p for p in projects if p.stack in wanted]
        if not projects and "python" in wanted:
            projects = [python_project(app_dir, test_dir)]   # explicit python: build app_dir as before
    if not projects:
        where = f"`{t.get('app_dir', '.')}`"
        what = "a supported project" if wanted is None else f"a `{language}` project"
        return BuildPlan(error=(
            f"No build system detected: could not find {what} in {where} (looked for package.json, "
            "pyproject.toml/setup.py/requirements.txt, pom.xml, build.gradle, *.sln/*.csproj, go.mod). "
            "Set target.build_commands for this repo (config/dev-pipe.yaml target.overrides, or a "
            ".devpipe.yml file in the target repo)."))

    selected, note = select_projects(projects, changed)
    plan = BuildPlan(warnings=[note] if note else [])
    for p in selected:
        label = f"{p.rel(app_dir)} ({p.stack})"
        plan.units.append(BuildUnit(label, p.path, p.commands, p.agent_commands(), p.install_commands()))
        plan.warnings += [f"{label}: {w}" for w in p.warnings]
    return plan


def build_check_text(t: dict, app_dir: Path | None = None) -> str:
    """The build instruction given to the agent (the same commands check_build runs)."""
    cmds = build_commands(t)
    if cmds:
        return ("in `" + t["app_dir"] + "` run " + ", then ".join(f"`{c}`" for c in cmds)
                + ". The pipeline re-runs exactly these and fails the step if any fails; only report a check "
                "as passed if you ran it and it passed.")
    if app_dir is None:
        from dev_pipe.config import app_dir as _app_dir
        app_dir = _app_dir()
    plan = plan_build(t, app_dir)
    if plan.error:
        return f"{plan.error} Tell the developer in your final message."
    parts = [f"in `{u.cwd.relative_to(Path(app_dir).resolve()).as_posix() or '.'}` run "
             + ", then ".join(f"`{c.cmd}`" for c in (u.agent_commands if sandboxed() else u.commands))
             for u in plan.units if (u.agent_commands if sandboxed() else u.commands)]
    text = ("; ".join(parts) + " (paths relative to `" + str(t.get("app_dir", ".")) + "`; you only need the "
            "projects you changed). The pipeline re-runs these and fails the step if any fails; only report a "
            "check as passed if you ran it and it passed.")
    if plan.warnings:
        text += " Notes: " + "; ".join(plan.warnings) + "."
    return text


def check_build(t: dict, app_dir: Path, changed: list[Path] | None = None) -> BuildResult:
    """Build + test the projects affected by `changed` (all projects when None)."""
    plan = plan_build(t, app_dir, changed)
    if plan.error:
        return BuildResult(False, plan.error)
    log, ok = [], True
    for unit in plan.units:
        unit_ok, unit_log = _run_commands(unit.cwd, unit.commands)
        log.append(f"### {unit.label}\n{unit_log}")
        ok = ok and unit_ok
    for w in plan.warnings:
        print(f"[build] WARNING: {w}", flush=True)
    return BuildResult(ok, "\n\n".join(log), plan.warnings, [u.label for u in plan.units])


def run_build(app_dir: Path, test_dir: str, commands: list[str] | None = None) -> tuple[bool, str]:
    """Explicit commands, or the Python check (compileall + pytest) on app_dir. Returns (ok, short log).
    Kept for callers that already know the commands; steps use check_build()."""
    if commands:
        return _run_commands(Path(app_dir), [Command(c) for c in commands if str(c).strip()])
    project = python_project(Path(app_dir), test_dir)
    ok, log = _run_commands(Path(app_dir), project.commands)
    return ok, "\n".join([f"WARNING: {w}" for w in project.warnings] + [log])


# Dependency files whose content decides what prepare_python installs (stack.python_install_commands).
_DEP_FILES = ("pyproject.toml", "setup.py", "setup.cfg", "Pipfile", "Pipfile.lock", "poetry.lock")
# app_dir -> (fingerprint of its dependency files, interpreter) after a successful install in THIS job.
_PREPARED: dict[str, tuple[str, str]] = {}


def _deps_fingerprint(app_dir: Path) -> str:
    import hashlib
    h = hashlib.sha256()
    from dev_pipe.stack import PY_REQUIREMENT_FILES
    names = sorted({p.name for p in app_dir.glob("requirements*.txt")} | set(PY_REQUIREMENT_FILES) | set(_DEP_FILES))
    for name in names:
        f = app_dir / name
        if f.is_file():
            h.update(name.encode() + b"\0" + f.read_bytes() + b"\0")
    return h.hexdigest()


def prepare_python(app_dir: Path) -> tuple[bool, str, str]:
    """Installs a Python project's own dependencies into its virtualenv (see stack.python_env).
    Returns (ok, interpreter to run tests with, log). Used before the coverage gate.
    Installs once per job: later check rounds skip it unless a dependency file changed (e.g. the AI added a
    package to requirements.txt), instead of re-running every pip install."""
    app_dir = Path(app_dir)
    key, fp = str(app_dir.resolve()), _deps_fingerprint(app_dir)
    cached = _PREPARED.get(key)
    if cached and cached[0] == fp:
        print("[build] project dependencies already installed in this job (dependency files unchanged)", flush=True)
        return True, cached[1], ""
    py, setup = python_env(app_dir)
    if not setup:
        return True, py, ""
    ok, log = _run_commands(app_dir, setup)
    if ok:
        _PREPARED[key] = (fp, py)
    else:
        _PREPARED.pop(key, None)
    return ok, py, log


def install_for_agent() -> None:
    """"Install first, then no network": downloads every detected project's dependencies (and, for Java/.NET/Go,
    what the build and tests need) BEFORE the AI starts, outside its sandbox. Never fails the step: the
    pipeline's own build check (which has network) reports any real problem. Once per job."""
    global _INSTALLED
    if _INSTALLED:
        return
    _INSTALLED = True
    from dev_pipe.config import app_dir as _app_dir, target_settings
    t = target_settings()
    if build_commands(t):
        print("[install] custom target.build_commands: they run as configured; the AI's sandbox has no network, "
              "so they must work offline once the pipeline's first build check has run", flush=True)
        return
    plan = plan_build(t, _app_dir())
    for unit in plan.units:
        if not unit.install_commands:
            continue
        ok, log = _run_commands(unit.cwd, unit.install_commands)
        print(f"[install] {unit.label}: dependencies {'installed' if ok else 'install FAILED'} before the AI starts"
              + ("" if ok else f"\n{log[-1500:]}"), flush=True)


_INSTALLED = False


def _build_env() -> dict:
    env = {k: v for k, v in os.environ.items() if k in _ALLOWED_SECRETS or not _SECRET_NAME.search(k)}
    # While the AI runs, its secrets are hidden (dev_pipe/agent_isolation.py); the pipeline's own build checks
    # still get the private-registry tokens they need.
    from dev_pipe.agent_isolation import held
    for name in _ALLOWED_SECRETS:
        if name not in env and held(name):
            env[name] = held(name)
    env.setdefault("CI", "true")   # non-interactive test runners (jest/vitest watch mode off)
    return env


def _run_commands(cwd: Path, commands: list[Command]) -> tuple[bool, str]:
    log = []
    env = _build_env()
    for c in commands:
        # Commands come from the reviewed config, the target repo's build files or stack detection,
        # never from the agent's output or the story text.
        try:
            proc = subprocess.run(c.cmd, cwd=cwd, shell=True, capture_output=True, text=True,  # noqa: S602
                                  env=env, timeout=COMMAND_TIMEOUT_SECONDS)
            code, output = proc.returncode, (proc.stdout or "") + (proc.stderr or "")
        except subprocess.TimeoutExpired as exc:
            code = -1
            parts = [p.decode(errors="replace") if isinstance(p, bytes) else (p or "")
                     for p in (exc.stdout, exc.stderr)]
            output = "".join(parts) + f"\nTimed out after {COMMAND_TIMEOUT_SECONDS}s"
        tail = output.strip().splitlines()[-LOG_TAIL_LINES:]
        log.append(f"$ {c.cmd}  (exit {code})\n" + "\n".join(tail))
        if code not in c.ok_codes:
            return False, "\n".join(log)
    return True, "\n".join(log)
