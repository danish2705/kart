"""Keeps the AAVA index of every candidate repo's base branch fresh (run on a schedule).

First-time indexing can take up to ~1 hour, so doing it ahead of time keeps Steps 1-2 fast.
Only triggers indexing; it does not wait. Re-triggering an unchanged repo is a cheap no-op on the
AAVA side (per USAGE_GUIDE.md), and a new commit gets picked up.

Usage (GitHub Actions: .github/workflows/aava-index.yml):
    python -m dev_pipe.index_base_branches
Env: TARGET_GITHUB_TOKEN (or GH_PAT), optional DISCOVERY_ORG, AAVA_CONTEXT_BASE_URL.
"""
from __future__ import annotations

import os

from dev_pipe.aava import Aava, AavaError
from dev_pipe.config import settings
from dev_pipe.github_api import GitHub
from dev_pipe.io_utils import summary
from dev_pipe.resolver import Resolver
from dev_pipe.workspace import take_token


def main() -> None:
    cfg = settings()
    d = dict(cfg.get("discovery") or {})
    d["github_org"] = (d.get("github_org") or os.environ.get("DISCOVERY_ORG")
                       or os.environ.get("GITHUB_REPOSITORY_OWNER", ""))
    d["base_branch"] = cfg.get("git", {}).get("base_branch", "")
    a = cfg.get("aava") or {}
    token = take_token()
    if not token:
        raise SystemExit("Missing TARGET_GITHUB_TOKEN (GH_PAT secret).")
    gh = GitHub(token)
    aava = Aava(os.environ.get("AAVA_CONTEXT_BASE_URL") or a.get("base_url", ""),
                github_token=token if a.get("send_github_token", True) else "")
    resolver = Resolver(gh, aava, d)

    rows = []
    for repo in resolver.candidate_repos():
        c = resolver._base_candidate(repo, set())
        if not c:
            continue
        try:
            status = aava.trigger_index(c["owner"], c["repo"], c["branch"])
        except AavaError as err:
            status = f"error: {err}"
        rows.append(f"| {c['full_name']} | `{c['branch']}` | {status or 'ok'} |")
    summary("## AAVA index refresh\n\n| Repo | Branch | Result |\n|---|---|---|\n" + ("\n".join(rows) or "| (none) | | |"))


if __name__ == "__main__":
    main()
