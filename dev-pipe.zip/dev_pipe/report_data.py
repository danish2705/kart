"""Small facts for the plain-English step logs: which tests are new, and per-file coverage.

Read-only helpers; every function returns empty results instead of failing, so logging never breaks a step.
"""
from __future__ import annotations

import os
import re
import xml.etree.ElementTree as ET
from pathlib import Path

_SKIP = {"node_modules", ".git", "__pycache__", ".venv", "venv", "dist", "build", ".scannerwork", ".sonarqube"}
# The ONE rule for "is this a test file?" (Step 4's completion check in agent_runner uses it too).
_TEST_PATH = re.compile(r"(^|/)([Tt]ests?|__tests__|spec|src/test)/|(^|/)test_[^/]+\.py$|_test\.(py|go)$|"
                        r"\.(test|spec)\.[cm]?[jt]sx?$|[a-z0-9]Tests?\.(cs|fs|vb|java|kt|scala)$|\.Tests?/")
_PY_TEST = re.compile(r"^\+\s*(?:async\s+)?def\s+(test_\w+)\s*\(")
_JS_TEST = re.compile(r"""^\+\s*(?:it|test)(?:\.\w+)?\(\s*(['"`])(.+?)\1""")
_JAVA_CS_TEST = re.compile(r"^\+\s*(?:public\s+)?(?:async\s+)?(?:void|Task)\s+(\w+)\s*\(")


def is_test_path(path: str) -> bool:
    return bool(_TEST_PATH.search(path.replace("\\", "/")))


def new_test_names(diff_text: str) -> dict[str, list[str]]:
    """`git diff -U0` text -> {test file: [names of test functions/cases added]}."""
    found: dict[str, list[str]] = {}
    current = ""
    prev_annotation = False
    for line in diff_text.splitlines():
        if line.startswith("+++ "):
            target = line[4:].strip()
            current = target[2:] if target.startswith("b/") else ("" if target == "/dev/null" else target)
            continue
        if not current or not is_test_path(current) or not line.startswith("+"):
            prev_annotation = False
            continue
        m = _PY_TEST.match(line) or _JS_TEST.match(line)
        name = (m.group(2) if m and m.re is _JS_TEST else m.group(1)) if m else ""
        if not name and prev_annotation:
            j = _JAVA_CS_TEST.match(line)
            name = j.group(1) if j else ""
        prev_annotation = bool(re.match(r"^\+\s*(@Test|\[(Fact|Theory|Test|TestMethod)\])", line))
        if name:
            found.setdefault(current, []).append(name)
    return found


def _walk(root: Path):
    for d, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if x not in _SKIP]
        yield Path(d), files


def file_coverage(root: Path, rel_paths: list[str], newer_than: float | None = None) -> dict[str, float]:
    """{repo-relative source path: % of lines covered} for the given files, read from the coverage reports the
    test run wrote (Cobertura coverage.xml from pytest-cov, LCOV lcov.info from Vitest/Jest)."""
    root = Path(root).resolve()
    wanted = [p.replace("\\", "/") for p in rel_paths]
    result: dict[str, float] = {}

    def match(path: str) -> str | None:
        path = path.replace("\\", "/")
        hits = [w for w in wanted if w == path or w.endswith("/" + path) or path.endswith("/" + w)]
        return max(hits, key=len) if hits else None

    for d, files in _walk(root):
        for f in files:
            report = d / f
            if f not in ("coverage.xml", "lcov.info"):
                continue
            try:
                if newer_than is not None and report.stat().st_mtime < newer_than - 2:
                    continue
                if f == "coverage.xml":
                    tree = ET.parse(report)
                    sources = [Path(s.text.strip()) for s in tree.iter("source") if s.text and s.text.strip()]
                    for cls in tree.iter("class"):
                        name = cls.get("filename", "")
                        candidates = [name]
                        for src in sources or [report.parent]:
                            try:
                                candidates.append((src / name).resolve().relative_to(root).as_posix())
                            except ValueError:
                                pass
                        key = next((k for k in (match(c) for c in candidates) if k), None)
                        if key:
                            result[key] = round(100 * float(cls.get("line-rate", 0)), 1)
                else:
                    sf, lf, lh = "", 0, 0
                    for line in report.read_text(encoding="utf-8", errors="replace").splitlines():
                        if line.startswith("SF:"):
                            sf, lf, lh = line[3:].strip(), 0, 0
                        elif line.startswith("LF:"):
                            lf = int(line[3:] or 0)
                        elif line.startswith("LH:"):
                            lh = int(line[3:] or 0)
                        elif line.startswith("end_of_record") and sf:
                            path = sf
                            try:
                                path = Path(sf).resolve().relative_to(root).as_posix() if os.path.isabs(sf) else sf
                            except ValueError:
                                pass
                            key = match(path)
                            if key and lf:
                                result[key] = round(100 * lh / lf, 1)
            except (OSError, ValueError, ET.ParseError):
                continue
    return result


_CMD = re.compile(r"^\$ (.+?)  \(exit (-?\d+)\)", re.M)


def friendly_command(cmd: str) -> str:
    c = cmd.lower()
    if any(k in c for k in ("pip install", "npm ci", "npm install", "yarn install", "pnpm install", "poetry install",
                            "venv.create", "dotnet restore", "go mod download")):
        return "Installed dependencies"
    if any(k in c for k in ("pytest", "npm test", "npm run test", "yarn test", "pnpm test", "dotnet test",
                            "go test", "vitest", "jest")):
        return "Ran the tests"
    if any(k in c for k in ("compileall", "tsc", "npm run build", "yarn build", "pnpm build", "dotnet build",
                            "go build", "go vet", "mvn", "gradle", "typecheck")):
        return "Compiled / built the code"
    return "Ran " + cmd.split()[0].rsplit("/", 1)[-1]


def command_steps(build_log: str) -> list[tuple[str, bool]]:
    """Build log -> [(plain label, ok)], one per distinct label, in order."""
    seen: dict[str, bool] = {}
    for cmd, code in _CMD.findall(build_log or ""):
        label = friendly_command(cmd)
        ok = int(code) in (0, 5) if "pytest" in cmd else int(code) == 0
        seen[label] = seen.get(label, True) and ok
    return list(seen.items())
