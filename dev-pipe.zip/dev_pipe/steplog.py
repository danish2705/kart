"""Readable, step-by-step logs for every pipeline job, plus one pipeline report for the whole run.

Each job prints one block that anyone can follow without knowing the code:

    ==================== STEP 3: AUTONOMOUS DEVELOPMENT ====================
    What this step does : ...
    Input               : ...
    [3.1] ADO: story state ....................... New -> Active
          Assignee / iteration ................... copied from the story / Sprint 12
    ---------------------------- CODE CHANGES ----------------------------
    ...
    Decision            : ...
    RESULT              : PASSED (2m 40s)
    Output              : ... -> Step 4

Every step also records its result in out/steps.json (handed to the next job with the out/ artifact), and
out/pipeline-report.md is rebuilt from it, so the report always covers the steps that ran so far.

Rules: no personal names (people appear as roles or yes/no), never secrets; long text is shortened (the full
text stays in the out/ artifact). Standard library only: the approval-gate job uses it without installing deps.
"""
from __future__ import annotations

import json
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "out"
# AI agent sessions and time in this job (updated by dev_pipe/agent_runner.py; summed in the report).
AI_TOTALS: dict = {"sessions": 0, "seconds": 0.0}
WIDTH = 46            # label column incl. dots
MAX_LINES = 40        # lines of a long text block before it is shortened
MAX_LINE_CHARS = 160


def fmt_duration(seconds: float | None) -> str:
    if seconds is None:
        return "n/a"
    seconds = int(round(seconds))
    if seconds < 60:
        return f"{seconds}s"
    m, s = divmod(seconds, 60)
    if m < 60:
        return f"{m}m {s:02d}s"
    h, m = divmod(m, 60)
    return f"{h}h {m:02d}m"


def shorten(text: str, max_lines: int = MAX_LINES, note: str = "") -> list[str]:
    lines = [ln.rstrip()[:MAX_LINE_CHARS] for ln in str(text or "").strip().splitlines()]
    lines = [ln for i, ln in enumerate(lines) if ln or (i and lines[i - 1])]   # collapse blank runs
    if len(lines) > max_lines:
        lines = lines[:max_lines] + [f"... ({len(lines) - max_lines} more lines{'; ' + note if note else ''})"]
    return lines or ["(none)"]


def _now_utc() -> str:
    return datetime.now(timezone.utc).strftime("%d-%b-%Y %H:%M UTC")


class StepLog:
    """with StepLog("3", "Write the code") as log: ...

    The readable block is collected while the step runs and printed at the end, right after a collapsed
    "Technical details" group that holds everything else the step printed (agent activity, build output,
    scanner output). On GitHub only the plain-English block is visible unless someone expands the group.
    An exception leaving the block prints "Result : FAILED" with the reason (and is re-raised)."""

    def __init__(self, number: str, name: str, what: str = "", out_dir: Path | None = None, key: str = ""):
        self.number, self.name, self.what = number, name, what
        self.key = key or number            # row id in steps.json (two jobs can share a step number)
        self.out = Path(out_dir) if out_dir else OUT
        self.prefix = number.split("-")[0]
        self.counter = 0
        self.started = time.time()
        self.facts: list[str] = []
        self.metrics: dict = {}
        self.lines: list[str] = []
        self.done = False
        self._grouped = False

    # ------------------------------------------------------------ output
    def _print(self, text: str = "") -> None:
        print(text, flush=True)

    def _add(self, text: str = "") -> None:
        self.lines.extend(str(text).splitlines() or [""])

    def __enter__(self) -> "StepLog":
        if os.environ.get("GITHUB_ACTIONS") == "true":
            self._print(f"::group::Step {self.number} technical details (click to expand)")
            self._grouped = True
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        if not self.done and exc_type is not None:
            if isinstance(exc, SystemExit):
                code = exc.code
                if code in (0, None):
                    self.result("PASSED")
                    return False
                reason = code if isinstance(code, str) else f"exit code {code}"
            else:
                reason = f"{exc_type.__name__}: {exc}"
            self.fail(f"Stopped: {reason}"[:600])
            self.result("FAILED")
        elif not self.done:
            self.result("PASSED")
        return False   # never swallow the exception

    # plain-English building blocks
    def field(self, label: str, value) -> None:
        """`Label             : value` (multi-line values are indented)."""
        lines = str(value if value is not None else "not available").splitlines() or [""]
        self._add(f"{label:<18}: {lines[0]}")
        for ln in lines[1:]:
            self._add(f"{'':<20}{ln}")

    def heading(self, title: str) -> None:
        self._add("")
        self._add(title.upper())

    def ok(self, text: str) -> None:
        self._mark("\u2714", text)

    def fail(self, text: str) -> None:
        self._mark("\u2718", text)

    def warn(self, text: str) -> None:
        self._mark("!", text)

    def arrow(self, text: str) -> None:
        self._mark("\u2192", text)

    def detail(self, text: str, indent: int = 2) -> None:
        for ln in str(text).splitlines() or [""]:
            self._add(" " * indent + ln)

    def kv(self, label: str, value, indent: int = 2, width: int = 34) -> None:
        """Indented `label ..... value` row."""
        head = f"{' ' * indent}{label} "
        self._add(f"{head}{'.' * max(3, width - len(head))} {value}")

    def table(self, rows: list[list[str]], indent: int = 2) -> None:
        widths = [max(len(str(r[c])) for r in rows) for c in range(len(rows[0]))] if rows else []
        for r in rows:
            self._add(" " * indent + "  ".join(str(v).ljust(widths[i]) for i, v in enumerate(r)).rstrip())

    def _mark(self, sign: str, text: str) -> None:
        lines = str(text).splitlines() or [""]
        self._add(f"{sign} {lines[0]}")
        for ln in lines[1:]:
            self._add(f"  {ln}")

    # kept for older callers: numbered rows and dashed sections
    def item(self, label: str, value, num: str | None = None) -> None:
        self.ok(f"{label}: {value}")

    def sub(self, label: str, value) -> None:
        self.detail(f"{label}: {value}")

    def note(self, text: str) -> None:
        self.detail(f"({text})")

    def section(self, title: str, lines: list[str] | str) -> None:
        self.heading(title)
        for ln in (lines.splitlines() if isinstance(lines, str) else lines):
            self.detail(ln)

    def fact(self, text: str) -> None:
        """Short key fact for the pipeline report table."""
        if text:
            self.facts.append(text)

    def metric(self, name: str, value) -> None:
        """Numbers summed in the pipeline report (ai_sessions, ai_seconds, fix_rounds, approvals)."""
        self.metrics[name] = value

    # ------------------------------------------------------------ result
    def result(self, status: str, summary: str = "", next_step: str = "", *, decision: str = "",
               output: str = "") -> None:
        if self.done:
            return
        self.done = True
        took = time.time() - self.started
        if self._grouped:
            self._print("::endgroup::")
        title = f" STEP {self.number}: {self.name.upper()} "
        self._print("")
        self._print(f"{'=' * 20}{title}{'=' * 20}")
        for ln in self.lines:
            self._print(ln)
        self._print("")
        when = "" if status in ("APPROVED", "REJECTED", "TIMED OUT") else f" in {fmt_duration(took)}"
        extra = summary or decision
        self._print(f"{'Result':<8}: {status}{when}" + (f" \u2014 {extra}" if extra else ""))
        if next_step:
            self._print(f"{'Next':<8}: {next_step}")
        self._print("=" * (40 + len(title)))
        metrics = {"ai_sessions": AI_TOTALS["sessions"], "ai_seconds": round(AI_TOTALS["seconds"], 1),
                   **self.metrics}
        record_step(self.key, self.number, self.name, status, self.facts, took, self.out, metrics)
        if status not in ("PASSED", "SKIPPED", "APPROVED"):
            report_to_summary(self.out)   # the run stops here: show the whole run so far on the run page


def record_step(key: str, number: str, name: str, status: str, facts: list[str] | None = None,
                seconds: float | None = None, out: Path | None = None, metrics: dict | None = None) -> None:
    """Adds/replaces one row in out/steps.json and rebuilds out/pipeline-report.md. Never raises."""
    out = Path(out) if out else OUT
    try:
        out.mkdir(parents=True, exist_ok=True)
        path = out / "steps.json"
        steps = json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
        steps = [s for s in steps if s.get("key", s.get("step")) != key]   # a re-run replaces its row
        steps.append({"key": key, "step": number, "name": name, "result": status,
                      "seconds": None if seconds is None else round(seconds, 1), "facts": list(facts or []),
                      "metrics": dict(metrics or {}), "finished": _now_utc(),
                      "finished_ts": round(time.time(), 1)})
        path.write_text(json.dumps(steps, indent=2), encoding="utf-8")
        (out / "pipeline-report.md").write_text(build_report(steps, out), encoding="utf-8")
    except (OSError, ValueError) as err:   # logging must never fail a step
        print(f"[steplog] could not record the step: {err}", flush=True)


# ------------------------------------------------------------------ pipeline report

def _order(step: str) -> int:
    m = re.match(r"\d+", str(step))
    return int(m.group()) if m else 99


SHORT_NAMES = {"1-2": "Plan", "3": "Code", "4": "Tests", "5": "Quality check", "6": "Pull request",
               "7": "Quality gate", "8-approval": "Approval", "8-ado": "ADO update"}
SIGN = {"PASSED": "\u2714 PASSED", "APPROVED": "\u2714 APPROVED", "SKIPPED": "- SKIPPED", "FAILED": "\u2718 FAILED",
        "REJECTED": "\u2718 REJECTED", "TIMED OUT": "\u2718 TIMED OUT"}


def build_report(steps: list[dict], out: Path | None = None) -> str:
    """Plain-English report of every step recorded so far (out/pipeline-report.md and the final run summary)."""
    out = Path(out) if out else OUT

    def load(name: str) -> dict:
        try:
            return json.loads((out / name).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    story, target, pr, ado = load("story.json"), load("target.json"), load("pr.json"), load("ado.json")
    steps = sorted(steps, key=lambda s: _order(s["step"]))
    stopped = [s for s in steps if s["result"] in ("FAILED", "REJECTED", "TIMED OUT")]
    done = any(s.get("key") == "8-ado" and s["result"] == "PASSED" for s in steps)
    overall = (f"STOPPED AT STEP {stopped[0]['step']}" if stopped else "COMPLETED" if done
               else "IN PROGRESS" if steps else "not available")
    repo = os.environ.get("GITHUB_REPOSITORY", "")
    run_no = os.environ.get("GITHUB_RUN_NUMBER", "")
    ends = [s.get("finished_ts") for s in steps if s.get("finished_ts")]
    starts = [s["finished_ts"] - (s.get("seconds") or 0) for s in steps if s.get("finished_ts")]
    span = ""
    if starts and ends:
        fmt = "%H:%M"
        span = (f"{datetime.fromtimestamp(min(starts), timezone.utc).strftime(fmt)} \u2192 "
                f"{datetime.fromtimestamp(max(ends), timezone.utc).strftime(fmt)} UTC  |  "
                f"Total {fmt_duration(max(ends) - min(starts))}  |  ")

    rows = [["Step", "Result", "Time", "Key facts"]]
    for s in steps:
        label = f"{s['step']:<4}{SHORT_NAMES.get(s.get('key', s['step']), s['name'])}"
        rows.append([label, SIGN.get(s["result"], s["result"]),
                     "-" if s.get("key") == "8-approval" else fmt_duration(s.get("seconds")),
                     ", ".join(s.get("facts") or []) or "-"])
    widths = [max(len(str(r[c])) for r in rows) for c in range(4)]
    table = ["  ".join(str(v).ljust(widths[i]) for i, v in enumerate(r)).rstrip() for r in rows]

    m = lambda name: sum((s.get("metrics") or {}).get(name, 0) or 0 for s in steps)
    ado_bits = []
    if ado.get("dev_task_id") or ado.get("pr_task_id"):
        n = sum(1 for k in ("dev_task_id", "pr_task_id") if ado.get(k))
        ado_bits.append(f"story Active, {n} task(s) ready" + (" and closed" if done else ""))
    if pr.get("url"):
        ado_bits.append("pull request linked")
    lines = [
        "```text",
        "DEV AGENT PIPELINE REPORT",
        f"Story        : #{story.get('id', '?')} \"{story.get('title', '')}\"",
        f"Repository   : {target.get('full_name') or repo or 'this repository'}"
        + (f" ({target.get('base_branch')})" if target.get("base_branch") else ""),
        "Pull request : " + (f"#{pr.get('number')}  {pr.get('url')}" if pr.get("url")
                              else "dry run (not created)" if pr.get("dry_run") else "not created yet"),
        "Run          : " + (f"#{run_no}  |  " if run_no else "") + span + f"RESULT: {overall}",
        "",
        *table,
        "",
        f"AI work      : {m('ai_sessions')} AI session(s), {m('fix_rounds')} fix round(s) needed, "
        f"about {fmt_duration(m('ai_seconds'))} of AI time",
        f"Human effort : {m('approvals')} approval(s)",
        f"Azure DevOps : {', '.join(ado_bits) or 'not updated yet'}",
        "```",
    ]
    if stopped:
        lines.append(f"\n**Stopped at Step {stopped[0]['step']} ({stopped[0]['name']}).** "
                     "Open that job's log for the reason.")
    return "\n".join(lines) + "\n"


def write_summary(markdown: str) -> None:
    """Prints markdown and appends it to the GitHub run summary (visible on the run page). The ONE writer used
    by every step (dev_pipe/io_utils.summary) and the approval jobs; standard library only."""
    print(markdown, flush=True)
    target = os.environ.get("GITHUB_STEP_SUMMARY")
    if target:
        with open(target, "a", encoding="utf-8") as f:
            f.write(markdown + "\n")


def report_to_summary(out: Path | None = None) -> None:
    """Appends the pipeline report to the GitHub run summary (final step, or a failed step)."""
    out = Path(out) if out else OUT
    path = out / "pipeline-report.md"
    if not path.exists():
        return
    text = path.read_text(encoding="utf-8")
    print(text, flush=True)
    target = os.environ.get("GITHUB_STEP_SUMMARY")
    if target:
        with open(target, "a", encoding="utf-8") as f:
            f.write("\n" + text + "\n")


# ------------------------------------------------------------------ shared helpers for the steps

def trigger_text() -> str:
    """How the run started, without naming the person: 'push to feature/x | run #12 | 29-Oct-2026 10:41 UTC'."""
    event = os.environ.get("GITHUB_EVENT_NAME", "")
    ref = os.environ.get("GITHUB_REF_NAME", "")
    how = {"push": f"push to {ref}", "workflow_dispatch": f"manual run on {ref}"}.get(event, event or "local run")
    run = os.environ.get("GITHUB_RUN_NUMBER", "")
    return f"{how}{f' | run #{run}' if run else ''} | {_now_utc()}"


def story_link(story: dict) -> str:
    org = os.environ.get("ADO_ORG_URL", "").rstrip("/")
    project = os.environ.get("ADO_PROJECT", "")
    return f"{org}/{project}/_workitems/edit/{story.get('id')}" if org and project else "n/a"


def numbered(text: str) -> list[str]:
    """Acceptance criteria text -> list of items (one per non-empty line, list markers removed)."""
    items = []
    for ln in str(text or "").splitlines():
        ln = re.sub(r"^\s*(?:[-*\u2022]|\d+[.)])\s*", "", ln).strip()
        if ln:
            items.append(ln)
    return items


def story_lines(story: dict) -> list[str]:
    """The USER STORY block. No personal names: the assignee is shown as yes/no."""
    lines = [
        f"{'ID / Type / State':<20}: {story.get('id')} / {story.get('type') or 'n/a'} / {story.get('state') or 'n/a'}",
        f"{'Title':<20}: {story.get('title') or 'n/a'}",
        f"{'Assigned':<20}: {'yes' if story.get('assigned_to') else 'no'}",
        f"{'Iteration / Area':<20}: {story.get('iteration_path') or 'n/a'} / {story.get('area_path') or 'n/a'}",
        f"{'Link':<20}: {story_link(story)}",
        "Description:",
    ]
    lines += ["  " + ln for ln in shorten(story.get("description"), note="full text in story.json")]
    criteria = numbered(story.get("acceptance_criteria", ""))
    lines.append(f"Acceptance criteria ({len(criteria)}):")
    shown = criteria[:MAX_LINES]
    lines += [f"  {i}. {c[:MAX_LINE_CHARS]}" for i, c in enumerate(shown, 1)] or ["  (none)"]
    if len(criteria) > len(shown):
        lines.append(f"  ... ({len(criteria) - len(shown)} more; full text in story.json)")
    return lines


_COUNT = re.compile(r"(\d+)\s+(passed|failed|skipped|errors?)\b", re.I)
_DOTNET = re.compile(r"Failed:\s*(\d+),\s*Passed:\s*(\d+),\s*Skipped:\s*(\d+)", re.I)


def test_counts(log: str) -> dict | None:
    """Test totals from build/test output (pytest, Vitest, Jest, dotnet, Maven surefire). None = not found."""
    totals = {"passed": 0, "failed": 0, "skipped": 0}
    found = False
    for line in str(log or "").splitlines():
        if re.search(r"Test (Files|Suites)", line):         # file/suite totals, not test totals
            continue
        m = _DOTNET.search(line)
        if m:
            totals["failed"] += int(m.group(1)); totals["passed"] += int(m.group(2)); totals["skipped"] += int(m.group(3))
            found = True
            continue
        sure = re.search(r"Tests run:\s*(\d+),\s*Failures:\s*(\d+),\s*Errors:\s*(\d+),\s*Skipped:\s*(\d+)", line)
        if sure and "Time elapsed" not in line:
            run, fail, err, skip = map(int, sure.groups())
            totals["passed"] += run - fail - err - skip; totals["failed"] += fail + err; totals["skipped"] += skip
            found = True
            continue
        hits = _COUNT.findall(line)
        if hits and re.search(r"\b(passed|failed)\b", line, re.I) and ("in " in line or "Tests" in line
                                                                       or line.strip().startswith(("=", "-"))
                                                                       or re.match(r"^\s*\d+ (passed|failed)", line)):
            for n, kind in hits:
                key = "failed" if kind.lower().startswith(("fail", "error")) else kind.lower()
                totals[key] += int(n)
            found = True
    return totals if found else None


def counts_text(counts: dict | None) -> str:
    if not counts:
        return "n/a (no test summary in the output)"
    return f"{counts['passed']} passed, {counts['failed']} failed, {counts['skipped']} skipped"
