"""Stack detection: works out how to build and test a repo from the files in it.

The pipeline used to assume Python (compileall + pytest) unless a repo was configured by hand. This module
looks for the usual project marker files instead, so any repo can be built without per-repo config:

    package.json            -> Node / TypeScript (npm, yarn or pnpm, picked from the lockfile)
    pyproject.toml, setup.py, setup.cfg, requirements.txt, Pipfile (or plain .py files) -> Python
    pom.xml                 -> Maven
    build.gradle(.kts)      -> Gradle
    *.sln / *.csproj / *.fsproj -> .NET
    go.mod                  -> Go

Monorepos: every project root under the app folder is found (frontend/, backend/, ...). When the changed
files are known, only the projects that contain a change are built.

No tests: a project without tests is NOT a failure. Its test command is skipped and a warning is
returned, so the run passes with the warning visible in the summary (coverage is enforced in Step 4).
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

# Folders never searched for projects or tests (dependencies, build output, VCS, virtualenvs).
SKIP_DIRS = {
    "node_modules", ".git", ".hg", ".svn", ".venv", "venv", "env", ".tox", ".nox", "__pycache__",
    ".pytest_cache", ".mypy_cache", "dist", "build", "out", "target", "bin", "obj", "vendor",
    ".next", ".nuxt", ".turbo", ".cache", "coverage", "htmlcov", ".idea", ".vscode", ".gradle",
    ".target", "target-checkout", ".tools", "site-packages",
}
MAX_DEPTH = 5

PYTHON_MARKERS = ("pyproject.toml", "setup.py", "setup.cfg", "requirements.txt", "Pipfile")
NPM_DEFAULT_TEST = "no test specified"

# Names users may put in target.language, mapped to the detected stack names.
LANGUAGE_ALIASES = {
    "node": {"node"}, "javascript": {"node"}, "typescript": {"node"}, "js": {"node"}, "ts": {"node"},
    "react": {"node"}, "angular": {"node"}, "vue": {"node"},
    "python": {"python"}, "py": {"python"},
    "java": {"maven", "gradle"}, "kotlin": {"gradle", "maven"}, "maven": {"maven"}, "gradle": {"gradle"},
    "dotnet": {"dotnet"}, ".net": {"dotnet"}, "csharp": {"dotnet"}, "c#": {"dotnet"},
    "go": {"go"}, "golang": {"go"},
}


@dataclass
class Command:
    cmd: str
    ok_codes: tuple[int, ...] = (0,)
    install: bool = False           # downloads dependencies (needs network): run by the pipeline before the AI


@dataclass
class Project:
    path: Path                      # absolute project root
    stack: str                      # node | python | maven | gradle | dotnet | go
    commands: list[Command] = field(default_factory=list)
    has_tests: bool = True
    warnings: list[str] = field(default_factory=list)
    # "Install first, then no network": what the pipeline runs BEFORE the AI (downloads everything the build and
    # tests need), and the offline build/test commands the AI is told to use inside its network-less sandbox.
    prefetch: list[Command] = field(default_factory=list)
    offline: list[Command] | None = None   # None = the normal commands minus the install ones

    def agent_commands(self) -> list[Command]:
        return self.offline if self.offline is not None else [c for c in self.commands if not c.install]

    def install_commands(self) -> list[Command]:
        return [c for c in self.commands if c.install] + self.prefetch

    def rel(self, base: Path) -> str:
        try:
            r = self.path.resolve().relative_to(base.resolve()).as_posix()
        except ValueError:
            r = self.path.as_posix()
        return r or "."


# ---------------------------------------------------------------- helpers
def _walk(root: Path, max_depth: int = MAX_DEPTH):
    """os.walk limited in depth, skipping dependency/build folders. Yields (dir Path, filenames)."""
    root = root.resolve()
    base_depth = len(root.parts)
    for dirpath, dirnames, filenames in os.walk(root):
        p = Path(dirpath)
        depth = len(p.parts) - base_depth
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")) \
            if depth < max_depth else []
        yield p, filenames


def _any_file(root: Path, pattern: re.Pattern, max_depth: int = MAX_DEPTH) -> bool:
    return any(pattern.search(f) for _, files in _walk(root, max_depth) for f in files)


def load_jsonc(path: Path) -> dict:
    """Tolerant JSON loader for package.json / tsconfig.json (comments and trailing commas allowed)."""
    try:
        text = path.read_text(encoding="utf-8-sig")
    except OSError:
        return {}
    try:
        return json.loads(text)
    except ValueError:
        pass
    out, i, n, in_str = [], 0, len(text), False
    while i < n:
        c = text[i]
        if in_str:
            out.append(c)
            if c == "\\" and i + 1 < n:
                out.append(text[i + 1])
                i += 1
            elif c == '"':
                in_str = False
        elif c == '"':
            in_str = True
            out.append(c)
        elif text.startswith("//", i):
            i = text.find("\n", i)
            i = n if i < 0 else i
            continue
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2)
            i = n if j < 0 else j + 2
            continue
        else:
            out.append(c)
        i += 1
    cleaned = re.sub(r",(\s*[}\]])", r"\1", "".join(out))
    try:
        return json.loads(cleaned)
    except ValueError:
        return {}


# ---------------------------------------------------------------- per-stack command builders
def _node_project(path: Path) -> Project:
    pkg = load_jsonc(path / "package.json")
    scripts = pkg.get("scripts") or {}
    deps = {**(pkg.get("dependencies") or {}), **(pkg.get("devDependencies") or {})}

    if (path / "pnpm-lock.yaml").exists():
        install, run = "corepack pnpm install --frozen-lockfile", "corepack pnpm run"
    elif (path / "yarn.lock").exists():
        berry = (path / ".yarnrc.yml").exists()
        install = "corepack yarn install --immutable" if berry else "yarn install --frozen-lockfile"
        run = "corepack yarn run" if berry else "yarn run"
    elif (path / "package-lock.json").exists() or (path / "npm-shrinkwrap.json").exists():
        install, run = "npm ci", "npm run"
    else:
        install, run = "npm install --no-audit --no-fund", "npm run"

    p = Project(path, "node", [Command(install, install=True)])

    build_script = str(scripts.get("build", ""))
    type_script = next((s for s in ("typecheck", "type-check", "tsc", "check-types") if s in scripts), None)
    if type_script:
        p.commands.append(Command(f"{run} {type_script}"))
    elif (path / "tsconfig.json").exists() and "typescript" in deps and "tsc" not in build_script:
        # Bundlers like Vite/esbuild strip types without checking them, so type-check explicitly.
        for cfg in _tsconfigs_to_check(path):
            p.commands.append(Command(f"npx --no-install tsc --noEmit -p {shlex.quote(cfg)}"))
    if "build" in scripts:
        p.commands.append(Command(f"{run} build"))

    test_script = str(scripts.get("test", ""))
    if not test_script or NPM_DEFAULT_TEST in test_script:
        p.has_tests = False
        p.warnings.append("no `test` script in package.json; tests skipped")
    elif not _node_has_test_files(path):
        p.has_tests = False
        p.warnings.append("a `test` script exists but no test files were found; tests skipped")
    else:
        p.commands.append(Command(f"{run} test"))
    if len(p.commands) == 1:
        p.warnings.append("no build, type-check or test script found; only dependencies were installed")
    return p


def _tsconfigs_to_check(path: Path) -> list[str]:
    """tsconfig.json, or the configs it references when it is a 'solution' file (files: [] + references)."""
    cfg = load_jsonc(path / "tsconfig.json")
    refs = [r.get("path", "") for r in (cfg.get("references") or []) if isinstance(r, dict)]
    if refs and cfg.get("files") == [] and not cfg.get("include"):
        out = []
        for ref in refs:
            ref_path = (path / ref)
            ref_path = ref_path / "tsconfig.json" if ref_path.is_dir() else ref_path
            if ref_path.exists():
                out.append(ref_path.relative_to(path).as_posix())
        return out or ["tsconfig.json"]
    return ["tsconfig.json"]


_NODE_TEST_FILE = re.compile(r"\.(test|spec)\.[cm]?[jt]sx?$")


def _node_has_test_files(path: Path) -> bool:
    for d, files in _walk(path):
        if d.name in ("__tests__", "tests", "test", "e2e", "cypress") and any(
                re.search(r"\.[cm]?[jt]sx?$", f) for f in files):
            return True
        if any(_NODE_TEST_FILE.search(f) for f in files):
            return True
    return False


_PY_TEST_FILE = re.compile(r"^(test_.*|.*_test)\.py$")

# Requirement files installed when present (the main one first, then the ones tests usually need).
PY_REQUIREMENT_FILES = (
    "requirements.txt", "requirements-dev.txt", "requirements_dev.txt", "dev-requirements.txt",
    "requirements-test.txt", "requirements_test.txt", "test-requirements.txt",
    "requirements/base.txt", "requirements/dev.txt", "requirements/test.txt",
)
PY_TEST_EXTRAS = ("test", "tests", "testing", "dev")
VENV_ROOT = Path(tempfile.gettempdir()) / "devpipe-venvs"


def _read_pyproject(path: Path) -> dict:
    f = path / "pyproject.toml"
    if not f.is_file():
        return {}
    text = f.read_text(encoding="utf-8", errors="ignore")
    try:
        import tomllib  # Python 3.11+ (the pipeline runs on 3.12)
        return tomllib.loads(text)
    except ImportError:
        # Older Python: enough to tell the project type (no extras).
        return {k: {} for k in ("project", "build-system") if re.search(rf"^\[{re.escape(k)}\]", text, re.M)} | \
            ({"tool": {"poetry": {}}} if re.search(r"^\[tool\.poetry\]", text, re.M) else {})
    except ValueError:
        return {}


def python_install_commands(path: Path, py: str) -> list[str]:
    """Commands that install the project's own dependencies with interpreter `py` (already shell-quoted).
    Read from the project's files: requirements*.txt, pyproject.toml (PEP 621 / Poetry), setup.py/setup.cfg,
    Pipfile.lock. Empty when the project declares no dependencies."""
    cmds = [f"{py} -m pip install -q -r {shlex.quote(f)}" for f in PY_REQUIREMENT_FILES if (path / f).is_file()]
    pyproject = _read_pyproject(path)
    poetry = "poetry" in (pyproject.get("tool") or {}) and "project" not in pyproject
    if poetry:
        cmds.append(f"{py} -m pip install -q poetry && POETRY_VIRTUALENVS_CREATE=false "
                    f"{py} -m poetry install --no-interaction")
    elif "project" in pyproject or "build-system" in pyproject or (path / "setup.py").is_file() \
            or (path / "setup.cfg").is_file():
        extras = sorted(set((pyproject.get("project") or {}).get("optional-dependencies") or {}) & set(PY_TEST_EXTRAS))
        target = f".[{','.join(extras)}]" if extras else "."
        cmds.append(f"{py} -m pip install -q -e {shlex.quote(target)}")
    if (path / "Pipfile.lock").is_file() and not cmds:
        req = VENV_ROOT / "pipfile-requirements.txt"
        cmds.append(f"{py} -m pip install -q pipenv && {py} -m pipenv requirements --dev > {shlex.quote(str(req))} "
                    f"&& {py} -m pip install -q -r {shlex.quote(str(req))}")
    return cmds


def python_env(path: Path) -> tuple[str, list[Command]]:
    """(interpreter, setup commands) for a Python project.

    Projects that declare dependencies get their own virtualenv (outside the repo, so nothing ends up in the
    change set) with those dependencies plus pytest/pytest-cov installed. This keeps the target's packages
    from changing the pipeline's own environment. Projects without a dependency file use the pipeline's
    Python, as before."""
    probe = python_install_commands(path, "PY")
    if not probe:
        return sys.executable, []
    key = hashlib.sha1(str(path.resolve()).encode()).hexdigest()[:12]
    venv = VENV_ROOT / f"{path.name or 'root'}-{key}"
    py_path = venv / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    py = shlex.quote(str(py_path))
    create = (f"{shlex.quote(sys.executable)} -c "
              "\"import os, sys, venv; os.path.exists(sys.argv[2]) or venv.create(sys.argv[1], with_pip=True)\" "
              f"{shlex.quote(str(venv))} {py}")
    cmds = [Command(create, install=True)] + [Command(c, install=True) for c in python_install_commands(path, py)]
    cmds.append(Command(f"{py} -m pip install -q pytest pytest-cov", install=True))
    return str(py_path), cmds


def python_project(path: Path, test_dir: str = "tests") -> Project:
    py_exe, setup = python_env(path)
    py = shlex.quote(py_exe)
    excludes = shlex.quote(r"[\\/](node_modules|\.venv|venv|\.git|\.target|target-checkout|\.tox|site-packages)[\\/]")
    p = Project(path, "python", setup + [Command(f"{py} -m compileall -q -x {excludes} .")])
    if not setup:
        p.warnings.append("no dependency file (requirements*.txt, pyproject.toml, setup.py, Pipfile.lock) found; "
                          "using the pipeline's Python environment")
    candidates = [d for d in (test_dir, "tests", "test") if d]
    found = next((d for d in candidates if (path / d).is_dir()), None)
    if found:
        target = shlex.quote(found)
    elif _any_file(path, _PY_TEST_FILE):
        target = ""
    else:
        p.has_tests = False
        p.warnings.append("no test folder or test_*.py files found; tests skipped")
        return p
    # Exit code 5 = no tests collected: not a build failure.
    # In the project's own virtualenv pytest-cov is installed (python_env), so the run also writes
    # coverage.xml, which the Sonar pre-check (Step 5) and PR analysis (Step 7) send to SonarQube Cloud.
    # Its data file (.coverage) goes into the virtualenv folder, outside the repo, so Sonar never scans it.
    # No extra -q: with a repo's own `addopts = -q` it would hide the "N passed" summary the step logs read.
    cov = " --cov=. --cov-report=xml:coverage.xml" if setup else ""
    env = f"COVERAGE_FILE={shlex.quote(str(Path(py_exe).parent.parent / '.coverage'))} " if setup else ""
    p.commands.append(Command(f"{env}{py} -m pytest {target} -p no:cacheprovider{cov}".replace("  ", " "), (0, 5)))
    return p


def _maven_project(path: Path) -> Project:
    mvn = "sh ./mvnw" if (path / "mvnw").exists() else "mvn"
    p = Project(path, "maven", [Command(f"{mvn} -B -q verify")],
                prefetch=[Command(f"{mvn} -B -q dependency:go-offline test-compile")],
                offline=[Command(f"{mvn} -o -B -q verify")])
    if not any(d.name == "test" and d.parent.name == "src" for d, _ in _walk(path)):
        p.has_tests = False
        p.warnings.append("no src/test folder found; build ran without tests")
    return p


def _gradle_project(path: Path) -> Project:
    gradle = "sh ./gradlew" if (path / "gradlew").exists() else "gradle"
    p = Project(path, "gradle", [Command(f"{gradle} build --no-daemon -q")],
                prefetch=[Command(f"{gradle} testClasses --no-daemon -q")],
                offline=[Command(f"{gradle} build --offline --no-daemon -q")])
    if not any(d.name == "test" and d.parent.name == "src" for d, _ in _walk(path)):
        p.has_tests = False
        p.warnings.append("no src/test folder found; build ran without tests")
    return p


def _dotnet_project(path: Path, files: list[str]) -> Project:
    slns = sorted(f for f in files if f.endswith(".sln"))
    target = f" {shlex.quote(slns[0])}" if slns else ""
    p = Project(path, "dotnet", [Command(f"dotnet build{target} -nologo")],
                prefetch=[Command(f"dotnet restore{target} -nologo")],
                offline=[Command(f"dotnet build{target} --no-restore -nologo")])
    has_tests = False
    for d, fs in _walk(path):
        for f in fs:
            if f.endswith((".csproj", ".fsproj", ".vbproj")):
                try:
                    text = (d / f).read_text(encoding="utf-8", errors="ignore")
                except OSError:
                    continue
                if "Microsoft.NET.Test.Sdk" in text or re.search(r"test", f, re.I):
                    has_tests = True
                    break
        if has_tests:
            break
    if has_tests:
        p.commands.append(Command(f"dotnet test{target} --no-build -nologo"))
        p.offline.append(Command(f"dotnet test{target} --no-build -nologo"))
    else:
        p.has_tests = False
        p.warnings.append("no test project found; tests skipped")
    return p


def _go_project(path: Path) -> Project:
    p = Project(path, "go", [Command("go build ./..."), Command("go vet ./...")],
                prefetch=[Command("go mod download")])
    if _any_file(path, re.compile(r"_test\.go$")):
        p.commands.append(Command("go test ./..."))
    else:
        p.has_tests = False
        p.warnings.append("no *_test.go files found; tests skipped")
    return p


# ---------------------------------------------------------------- detection
def _markers(files: list[str]) -> list[str]:
    s = set(files)
    found = []
    if "package.json" in s:
        found.append("node")
    if any(m in s for m in PYTHON_MARKERS):
        found.append("python")
    if "pom.xml" in s:
        found.append("maven")
    if "build.gradle" in s or "build.gradle.kts" in s:
        found.append("gradle")
    if any(f.endswith((".sln", ".csproj", ".fsproj")) for f in files):
        found.append("dotnet")
    if "go.mod" in s:
        found.append("go")
    return found


def _covers_children(project_dir: Path, stack: str, files: list[str]) -> bool:
    """Does a project of this stack already build its sub-folders (so nested ones are skipped)?"""
    if stack == "node":
        # Separate apps (frontend/, admin/) each build on their own unless the root declares workspaces.
        return "pnpm-workspace.yaml" in files or bool(load_jsonc(project_dir / "package.json").get("workspaces"))
    if stack in ("go", "python"):
        # go: nested go.mod files are separate modules (`go build ./...` stops at them).
        # python: a root requirements.txt does not run backend/tests, so nested projects build on their own.
        return False
    return True                 # maven/gradle multi-module, dotnet solutions


def detect_projects(root: Path, test_dir: str = "tests") -> list[Project]:
    """All buildable projects under root (shallowest first)."""
    root = root.resolve()
    projects: list[Project] = []
    covered: list[tuple[str, Path]] = []        # (stack, dir) whose build already includes sub-folders
    for d, files in _walk(root):
        for stack in _markers(files):
            if any(s == stack and (d == c or c in d.parents) for s, c in covered):
                continue
            if stack == "node":
                proj = _node_project(d)
            elif stack == "python":
                proj = python_project(d, test_dir)
            elif stack == "maven":
                proj = _maven_project(d)
            elif stack == "gradle":
                proj = _gradle_project(d)
            elif stack == "dotnet":
                proj = _dotnet_project(d, files)
            else:
                proj = _go_project(d)
            projects.append(proj)
            if _covers_children(d, stack, files):
                covered.append((stack, d))
    # Plain Python with no packaging file (e.g. sample_app/: app/ + tests/): treat the root as a project.
    if not projects and _any_file(root, re.compile(r"\.py$"), max_depth=2):
        projects.append(python_project(root, test_dir))
    return projects


def select_projects(projects: list[Project], changed: list[Path] | None) -> tuple[list[Project], str]:
    """Projects that contain at least one changed file. (selected, note)."""
    if not changed:
        return projects, ""
    changed = [c.resolve() for c in changed]
    hit = [p for p in projects if any(c == p.path or p.path in c.parents for c in changed)]
    if not hit:
        return projects, "changed files are outside every detected project, so all projects were built"
    return hit, ""


def stacks_for_language(language: str) -> set[str] | None:
    """None = auto (any stack)."""
    lang = (language or "").strip().lower()
    if lang in ("", "auto"):
        return None
    return LANGUAGE_ALIASES.get(lang, {lang})
