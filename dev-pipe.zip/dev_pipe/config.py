"""Settings, secrets and run context shared by every step."""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "out"
PROMPTS = ROOT / "prompts" / "dev"
SETTINGS_FILE = ROOT / "config" / "dev-pipe.yaml"
# External mode: the target repo is checked out here (git-ignored, never part of this repo).
# NOT a hidden (dot) folder: SonarQube treats everything under a hidden folder as hidden files, which its
# language sensors (Python, Java, JS/TS, ...) skip, so a PR showed "0 New lines of code" and no measures.
TARGET_CHECKOUT = ROOT / "target-checkout"

_settings: dict | None = None


def settings() -> dict:
    """Non-secret settings from config/dev-pipe.yaml (loaded once)."""
    global _settings
    if _settings is None:
        _settings = yaml.safe_load(SETTINGS_FILE.read_text(encoding="utf-8")) or {}
    return _settings


def secret(name: str, required: bool = True) -> str:
    """Read a secret from the environment (set by the workflow from GitHub Secrets)."""
    value = os.environ.get(name, "").strip()
    if required and not value:
        raise SystemExit(
            f"Missing '{name}'. Add it in Settings > Secrets and variables > Actions, "
            f"and pass it to this step in the workflow 'env:' block."
        )
    return value


def is_dry_run() -> bool:
    """Dry run unless DRY_RUN is explicitly 'false'. Dry run = no writes to ADO or GitHub."""
    return os.environ.get("DRY_RUN", "true").strip().lower() != "false"


def work_item_id() -> int:
    value = os.environ.get("WORK_ITEM_ID", "").strip()
    if not value.isdigit():
        raise SystemExit(
            "WORK_ITEM_ID is missing or not a number. Enter it when running the workflow, "
            "or set the TEST_WORK_ITEM_ID repository variable for push-triggered runs."
        )
    return int(value)


def feedback() -> str:
    """Optional reviewer feedback for a re-run (workflow input or DEV_FEEDBACK variable)."""
    return os.environ.get("DEV_FEEDBACK", "").strip()


def sonar_status() -> tuple[bool, str]:
    """(enabled, reason). Sonar runs only when switched on in config AND fully configured,
    so a half-configured Sonar is skipped with a clear reason instead of failing the run."""
    if not settings().get("sonar", {}).get("enabled", False):
        return False, "disabled in config (sonar.enabled: false)"
    missing = [n for n in ("SONAR_TOKEN", "SONAR_HOST_URL") if not os.environ.get(n, "").strip()]
    if not sonar_project_key():
        missing.append("SONAR_PROJECT_KEY")
    if missing:
        return False, f"missing {', '.join(missing)}"
    return True, "enabled"


def sonar_project_key() -> str:
    """Sonar project key for the repo being changed: `sonar.project_keys["owner/repo"]` in
    config/dev-pipe.yaml (external mode, one key per target repo) > the SONAR_PROJECT_KEY variable/secret."""
    keys = settings().get("sonar", {}).get("project_keys") or {}
    full = resolved_target().get("full_name", "") if is_external() else ""
    return str(keys.get(full) or os.environ.get("SONAR_PROJECT_KEY", "")).strip()


def sonar_connection() -> dict:
    """host, token, project_key, organization (call after sonar_status() returned enabled)."""
    return {"host": os.environ["SONAR_HOST_URL"].strip().rstrip("/"),
            "token": os.environ["SONAR_TOKEN"].strip(),
            "project_key": sonar_project_key(),
            "organization": os.environ.get("SONAR_ORGANIZATION", "").strip()}


def sonar_precheck_required() -> bool:
    """sonar.precheck.required: true = a skipped Sonar pre-check (switched off or not configured) FAILS
    Step 5 (Sonar Pre-check), so no pull request is ever raised without it."""
    return bool((settings().get("sonar", {}).get("precheck") or {}).get("required", False))


def is_external() -> bool:
    """external = find the repo/branch from the story (GitHub + AAVA) and raise the PR there.
    local = change target.app_dir inside this repo (original behaviour).
    The TARGET_MODE env var (GitHub repo variable) overrides target.mode in config/dev-pipe.yaml."""
    mode = os.environ.get("TARGET_MODE", "").strip() or settings()["target"].get("mode", "local")
    return str(mode).strip().lower() == "external"


def resolved_target() -> dict:
    """out/target.json written by Steps 1-2 in external mode ({} in local mode or before it exists)."""
    path = OUT / "target.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


# Keys a target repo may set in its own .devpipe.yml (same keys as target.overrides).
REPO_FILE = ".devpipe.yml"
REPO_FILE_KEYS = ("app_dir", "app_package", "test_dir", "language", "build_commands")


def repo_file_settings() -> dict:
    """External mode: settings from the target repo's own .devpipe.yml ({} if absent or invalid)."""
    path = TARGET_CHECKOUT / REPO_FILE
    if not is_external() or not path.is_file():
        return {}
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError) as exc:
        print(f"[config] ignoring {REPO_FILE}: {exc}", flush=True)
        return {}
    if not isinstance(data, dict):
        return {}
    return {k: v for k, v in data.items() if k in REPO_FILE_KEYS and v not in (None, "")}


def target_settings() -> dict:
    """The `target` section, adjusted for external mode. Precedence (highest last):
    config/dev-pipe.yaml `target` -> the target repo's .devpipe.yml -> `target.overrides["owner/repo"]`.
    app_dir defaults to the repo root in external mode. language "auto" (default) = detect the stack
    from the repo's files (dev_pipe/stack.py)."""
    t = dict(settings()["target"])
    t.pop("overrides", None)
    if is_external():
        t["app_dir"] = "."
        t.update(repo_file_settings())
        full = resolved_target().get("full_name", "")
        overrides = settings()["target"].get("overrides") or {}
        t.update({k: v for k, v in (overrides.get(full) or {}).items() if v not in (None, "")})
    if not t.get("language"):
        t["language"] = "auto"
    t.setdefault("build_commands", [])
    t.setdefault("test_dir", "tests")
    return t


def work_root() -> Path:
    """Git working tree the agent edits and the pipeline commits from."""
    return TARGET_CHECKOUT if is_external() else ROOT


def app_dir() -> Path:
    return (work_root() / target_settings()["app_dir"]).resolve()


def load_prompt(name: str, **values) -> str:
    text = (PROMPTS / f"{name}.md").read_text(encoding="utf-8")
    for key, value in values.items():
        text = text.replace("{{" + key + "}}", str(value))
    return text


def run_url() -> str:
    # Comment-triggered approval: Step 8 runs in the decision workflow, but links to the pipeline run.
    if os.environ.get("DEV_PIPE_RUN_URL", "").strip():
        return os.environ["DEV_PIPE_RUN_URL"].strip()
    server = os.environ.get("GITHUB_SERVER_URL", "")
    repo = os.environ.get("GITHUB_REPOSITORY", "")
    run_id = os.environ.get("GITHUB_RUN_ID", "")
    return f"{server}/{repo}/actions/runs/{run_id}" if run_id else "local run"


def slugify(text: str, max_len: int = 40) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return slug[:max_len].rstrip("-") or "change"


def branch_name(wid: int, title: str, suggested: str = "") -> str:
    """Branch from the plan if it follows the policy pattern's prefix, otherwise build one."""
    pattern = settings()["git"]["branch_pattern"]
    prefix = pattern.split("{", 1)[0]
    suggested = (suggested or "").strip()
    if suggested and suggested.startswith(prefix) and re.fullmatch(r"[A-Za-z0-9._/-]+", suggested):
        return suggested
    return pattern.format(id=wid, slug=slugify(title))
