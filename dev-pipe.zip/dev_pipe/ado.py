"""Azure DevOps Work Items REST client (v7.1) for the pipeline's deterministic ADO steps.

The agent never writes to ADO itself: state changes, task creation, links and
summaries are done here, so every write is explicit, logged and skipped in dry run.
Auth: Basic with empty user + ADO_PAT (needs Work Items: Read & Write).
"""
from __future__ import annotations

import html
import json
import re
from datetime import date, datetime, timedelta, timezone

import requests

from dev_pipe.config import is_dry_run, secret, settings


def strip_html(text: str) -> str:
    text = re.sub(r"<br\s*/?>|</p>|</li>|</div>", "\n", text or "", flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)
    return re.sub(r"\n{3,}", "\n\n", html.unescape(text)).strip()


def simplify(raw: dict) -> dict:
    """ADO work item JSON -> the fields the pipeline uses."""
    f = raw.get("fields", {})
    assigned = f.get("System.AssignedTo") or {}
    return {
        "id": raw.get("id"),
        "url": raw.get("url", ""),
        "title": f.get("System.Title", ""),
        "type": f.get("System.WorkItemType", ""),
        "state": f.get("System.State", ""),
        "area_path": f.get("System.AreaPath", ""),
        "iteration_path": f.get("System.IterationPath", ""),
        "assigned_to": assigned.get("uniqueName", "") if isinstance(assigned, dict) else str(assigned),
        "description": strip_html(f.get("System.Description", "")),
        "acceptance_criteria": strip_html(f.get("Microsoft.VSTS.Common.AcceptanceCriteria", "")),
    }


# ---------- JSON Patch builders (pure, unit-tested)

def patch_fields(fields: dict) -> list[dict]:
    return [{"op": "add", "path": f"/fields/{k}", "value": v} for k, v in fields.items() if v not in (None, "")]


_DATE_RE = re.compile(r"^\{today(?:\s*\+\s*(\d+))?\}$")


def resolve_field_value(value, today: date | None = None):
    """Config value -> ADO value. '{today}' / '{today+N}' become an ISO date (UTC midnight), N days ahead;
    anything else is passed through unchanged."""
    if isinstance(value, str):
        m = _DATE_RE.match(value.strip())
        if m:
            day = (today or datetime.now(timezone.utc).date()) + timedelta(days=int(m.group(1) or 0))
            return f"{day.isoformat()}T00:00:00Z"
    return value


def patch_new_task(title: str, parent_url: str, assigned_to: str, area: str, iteration: str,
                   remaining_hours: float = 0, extra_fields: dict | None = None) -> list[dict]:
    fields = {
        "System.Title": title,
        "System.AssignedTo": assigned_to,
        "System.AreaPath": area,
        "System.IterationPath": iteration,
    }
    if remaining_hours:
        fields["Microsoft.VSTS.Scheduling.RemainingWork"] = remaining_hours
    # Fields the ADO process template makes required on Tasks (config: ado.task_fields).
    for name, value in (extra_fields or {}).items():
        fields.setdefault(name, resolve_field_value(value))
    ops = patch_fields(fields)
    ops.append({"op": "add", "path": "/relations/-",
                "value": {"rel": "System.LinkTypes.Hierarchy-Reverse", "url": parent_url}})
    return ops


def rule_errors(body: str) -> str:
    """ADO 400 body -> one line per failing field, e.g. 'Microsoft.VSTS.Scheduling.OriginalEstimate: Required'.
    ADO truncates its own ErrorMessage ('2 additional errors occurred'), so list them all from the JSON."""
    try:
        errors = json.loads(body).get("customProperties", {}).get("RuleValidationErrors") or []
    except (ValueError, AttributeError):
        return ""
    def hint(e: dict) -> str:
        flags = (e.get("fieldStatusFlags") or "").lower()
        if "invalidnotempty" in flags:
            return " -> must be EMPTY: remove it from the config"
        if "required" in flags or "invalidempty" in flags:
            return " -> required: add it to the config"
        return ""
    lines = [f"- {e.get('fieldReferenceName')}: {e.get('errorMessage', '')}{hint(e)}"
             for e in errors if isinstance(e, dict)]
    return ("\nFields ADO rejected (config/dev-pipe.yaml: ado.task_fields if it failed creating a task, "
            "ado.close_fields if it failed closing one):\n"
            + "\n".join(lines)) if lines else ""


def pick_existing_task(tasks: list[dict], title: str, closed_states: set[str]) -> dict | None:
    """The open task with this title (same story, earlier run), or None. Closed/removed tasks are never reused:
    a new run after the work was closed is new work and gets new tasks."""
    want = title.strip().lower()
    closed = {s.lower() for s in closed_states}
    for t in tasks:
        if str(t.get("title", "")).strip().lower() == want and str(t.get("state", "")).lower() not in closed:
            return t
    return None


def patch_hyperlink(url: str, comment: str) -> list[dict]:
    return [{"op": "add", "path": "/relations/-",
             "value": {"rel": "Hyperlink", "url": url, "attributes": {"comment": comment}}}]


class AdoClient:
    def __init__(self):
        org = secret("ADO_ORG_URL").rstrip("/")
        project = secret("ADO_PROJECT")
        self.api = f"{org}/{project}/_apis/wit"
        self.version = settings().get("ado", {}).get("api_version", "7.1")
        self.dry_run = is_dry_run()
        self.session = requests.Session()
        self.session.auth = ("", secret("ADO_PAT"))

    def _call(self, method: str, url: str, **kwargs) -> dict:
        # No redirects: an invalid PAT makes ADO redirect to its sign-in page.
        resp = self.session.request(method, url, timeout=30, allow_redirects=False, **kwargs)
        where = f"ADO {method} {url.split('?')[0]}"
        if resp.status_code >= 400:
            # Never echo headers/auth; body is ADO's error message.
            raise SystemExit(f"{where} -> HTTP {resp.status_code}: {resp.text[:400]}{rule_errors(resp.text)}")
        content_type = resp.headers.get("Content-Type", "")
        if resp.status_code in (203, 301, 302) or (resp.content and "json" not in content_type):
            # ADO answers a bad/expired PAT or no-access org with a sign-in page, not a 401.
            raise SystemExit(
                f"{where} -> HTTP {resp.status_code} ({content_type or 'no content type'}): ADO returned a "
                "sign-in page instead of data. Check: (1) ADO_PAT secret is valid, not expired, and has "
                "Work Items Read & Write; (2) the PAT was created in the same organization as ADO_ORG_URL; "
                "(3) ADO_ORG_URL looks like https://dev.azure.com/<org> and ADO_PROJECT is the exact project name."
            )
        return resp.json() if resp.content else {}

    def _write(self, label: str, method: str, url: str, **kwargs) -> dict:
        if self.dry_run:
            print(f"[dry-run] ADO write skipped: {label}", flush=True)
            return {"dry_run": True, "id": 0, "url": ""}
        print(f"[ado] {label}", flush=True)
        return self._call(method, url, **kwargs)

    # ---------- reads
    def get_work_item(self, wid: int) -> dict:
        raw = self._call("GET", f"{self.api}/workitems/{wid}", params={"api-version": self.version})
        return simplify(raw)

    # ---------- writes (skipped in dry run)
    def _patch(self, label: str, wid: int, ops: list[dict]) -> dict:
        return self._write(label, "PATCH", f"{self.api}/workitems/{wid}",
                           params={"api-version": self.version}, json=ops,
                           headers={"Content-Type": "application/json-patch+json"})

    def set_state(self, wid: int, state: str, extra_fields: dict | None = None) -> dict:
        """extra_fields: fields ADO requires for that state, sent in the same update (e.g. ado.close_fields)."""
        fields = {"System.State": state}
        for name, value in (extra_fields or {}).items():
            fields.setdefault(name, resolve_field_value(value))
        return self._patch(f"set #{wid} state -> {state}", wid, patch_fields(fields))

    def has_link(self, wid: int, url: str) -> bool:
        """True if the work item already links to url (so a re-run doesn't fail on a duplicate link)."""
        if self.dry_run:
            return False
        raw = self._call("GET", f"{self.api}/workitems/{wid}",
                         params={"api-version": self.version, "$expand": "relations"})
        return any(r.get("url") == url for r in raw.get("relations") or [])

    def create_task(self, story: dict, title: str) -> dict:
        cfg = settings().get("ado", {})
        ops = patch_new_task(title, story["url"], story["assigned_to"], story["area_path"],
                             story["iteration_path"], cfg.get("remaining_work_hours", 0),
                             cfg.get("task_fields") or {})
        return self._write(f"create Task '{title}' under #{story['id']}", "POST",
                           f"{self.api}/workitems/$Task", params={"api-version": self.version},
                           json=ops, headers={"Content-Type": "application/json-patch+json"})

    def child_tasks(self, wid: int) -> list[dict]:
        """Child Tasks of a work item: [{"id", "title", "state"}]. A read, so it also runs in dry run."""
        raw = self._call("GET", f"{self.api}/workitems/{wid}",
                         params={"api-version": self.version, "$expand": "relations"})
        ids = [r["url"].rstrip("/").rsplit("/", 1)[-1] for r in raw.get("relations") or []
               if r.get("rel") == "System.LinkTypes.Hierarchy-Forward" and r.get("url")]
        ids = [i for i in ids if i.isdigit()][:200]   # ADO batch limit
        if not ids:
            return []
        items = self._call("GET", f"{self.api}/workitems", params={
            "ids": ",".join(ids), "fields": "System.Title,System.WorkItemType,System.State",
            "api-version": self.version}).get("value") or []
        return [{"id": it.get("id"), "title": (it.get("fields") or {}).get("System.Title", ""),
                 "state": (it.get("fields") or {}).get("System.State", "")}
                for it in items if (it.get("fields") or {}).get("System.WorkItemType") == "Task"]

    def find_or_create_task(self, story: dict, title: str, existing: list[dict]) -> tuple[dict, bool]:
        """Reuses an open child Task with the same title (a re-run of the same story), else creates one.
        Returns (task, created)."""
        done = settings().get("ado", {}).get("states", {}).get("task_done", "Closed")
        found = pick_existing_task(existing, title, closed_states={done, "Closed", "Done", "Removed"})
        if found:
            print(f"[ado] reusing Task #{found['id']} '{title}' under #{story['id']}", flush=True)
            return found, False
        return self.create_task(story, title), True

    def add_hyperlink(self, wid: int, url: str, comment: str) -> dict:
        if self.has_link(wid, url):
            print(f"[ado] #{wid} already links to {url}; skipped", flush=True)
            return {}
        return self._patch(f"link {url} on #{wid}", wid, patch_hyperlink(url, comment))

    def add_comment(self, wid: int, markdown_text: str) -> dict:
        body = "<br>".join(html.escape(line) for line in markdown_text.splitlines())
        return self._write(f"comment on #{wid}", "POST", f"{self.api}/workItems/{wid}/comments",
                           params={"api-version": f"{self.version}-preview.4"}, json={"text": body})
