"""Find which repo and branch a user story belongs to (external mode, Steps 1-2).

Flow:
  0. Manual override: TARGET_REPO ("owner/repo") and optional TARGET_BRANCH skip detection.
  1. Base branches: for each candidate repo (GitHub org listing or discovery.include_repos), make sure its
     base branch is indexed in AAVA, search it with the story, and score it by the best similarity.
     A clear winner above discovery.base_min_similarity is used.
  2. Branch fallback (nothing good on the base branches): for the most likely repos, list the branches
     (GitHub), newest last commit first, at most discovery.max_branches_scanned of them per repo (0 = all),
     make sure each one is indexed in AAVA and search every one of them.
     The branch with the best similarity above discovery.base_min_similarity wins.
GitHub look-ups, AAVA index checks and AAVA searches run discovery.parallel_requests at a time (default 6).
  3. Nothing qualifies: use the most likely repo's base branch with confidence "low" and list the
     branches with their scores for the reviewer to pick at the plan gate, or stop if there is no
     signal at all.
The chosen branch is both where work starts and the PR target (so a PR never drags in someone
else's unmerged work). A human confirms the choice at the plan approval gate (before Step 3).
"""
from __future__ import annotations

import fnmatch
import re
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

from dev_pipe.aava import DONE_STATES, FAILED_STATES, Aava, AavaError
from dev_pipe.github_api import GitHub, GitHubError

STOPWORDS = {
    "the", "and", "that", "this", "with", "from", "into", "when", "then", "should", "must", "will", "have",
    "user", "users", "able", "want", "need", "needs", "given", "story", "acceptance", "criteria", "as", "so",
    "for", "are", "can", "not", "all", "any", "each", "also", "only", "there", "their", "which", "what",
    "where", "while", "after", "before", "using", "used", "new", "add", "added", "update", "updated",
    "make", "display", "show", "shown", "system", "page", "field", "fields", "value", "values", "data",
}


class ResolveError(SystemExit):
    pass


# ---------- pure helpers (unit-tested)
def _stem(token: str) -> str:
    if token.endswith(("ss", "us", "is")):      # status, process, analysis: not plurals
        return token
    for suffix in ("ing", "ies", "es", "ed", "s"):
        if len(token) > len(suffix) + 3 and token.endswith(suffix):
            return token[: -len(suffix)] + ("y" if suffix == "ies" else "")
    return token


def tokens(text: str) -> set[str]:
    return {_stem(t) for t in re.findall(r"[a-z0-9]+", (text or "").lower())}


def story_keywords(story: dict) -> set[str]:
    text = f"{story.get('title', '')} {story.get('acceptance_criteria', '')}"
    return {t for t in tokens(text) if len(t) >= 4 and t not in STOPWORDS and not t.isdigit()}


def story_queries(story: dict, max_queries: int = 3) -> list[str]:
    candidates = [
        story.get("title", ""),
        f"{story.get('title', '')}. {story.get('acceptance_criteria', '')}"[:400],
        (story.get("description", "") or "")[:400],
    ]
    seen, out = set(), []
    for q in (c.strip() for c in candidates):
        if q and q not in seen:
            seen.add(q)
            out.append(q)
    return out[:max(1, max_queries)]


def keyword_hits(text: str, keywords: set[str]) -> int:
    return len(tokens(text) & keywords)


def excluded(name: str, patterns: list[str]) -> bool:
    return any(fnmatch.fnmatch(name, p) for p in patterns or [])


def _words(text: str) -> str:
    return (text or "").replace("/", " ").replace("-", " ").replace("_", " ").replace(".", " ")


def branch_signals(keywords: set[str], branch: str, compare: dict, pulls: list[dict]) -> tuple[int, list[str]]:
    """GitHub-only keyword evidence that `branch` holds the story's code. Returns (score, evidence).
    A score of 0 is normal (generic branch names, short commit messages) and does not exclude the branch."""
    score, ev = 0, []
    hits = keyword_hits(_words(branch), keywords)
    if hits:
        score += 2 * hits
        ev.append(f"{hits} story keyword(s) in branch name")
    for p in (p for p in pulls if p.get("head") == branch):
        text = f"{p.get('title', '')} {p.get('body', '')}"
        h = keyword_hits(text, keywords)
        if h:
            score += 2 * h
            ev.append(f"open PR #{p.get('number')} matches {h} keyword(s)")
    messages = " ".join(compare.get("messages", []))
    h = keyword_hits(messages, keywords)
    if h:
        score += h
        ev.append(f"{h} keyword(s) in commit messages")
    h = keyword_hits(_words(" ".join(compare.get("files", []))), keywords)
    if h:
        score += h
        ev.append(f"{h} keyword(s) in changed file paths")
    return score, ev


def decide(candidates: list[dict], min_similarity: float, margin: float) -> tuple[dict | None, str]:
    """Best candidate by similarity if it clears the threshold; confidence 'high' only with a clear margin."""
    ranked = sorted(candidates, key=lambda c: c.get("similarity", 0), reverse=True)
    if not ranked or ranked[0].get("similarity", 0) < min_similarity:
        return None, "none"
    second = ranked[1].get("similarity", 0) if len(ranked) > 1 else 0.0
    return ranked[0], ("high" if ranked[0]["similarity"] - second >= margin else "low")


# ---------- resolver
class Resolver:
    def __init__(self, gh: GitHub, aava: Aava, cfg: dict, log=print, now: datetime | None = None):
        self.gh, self.aava, self.cfg = gh, aava, cfg
        self.a = cfg.get("aava", {}) or {}
        self.log = log
        self.now = now or datetime.now(timezone.utc)
        self.trace: list[str] = []
        self.workers = max(1, int(cfg.get("parallel_requests", 6) or 1))

    def _parallel(self, fn, items: list) -> list:
        """fn(item) for every item, `parallel_requests` at a time; results in the same order as items."""
        items = list(items)
        if self.workers == 1 or len(items) <= 1:
            return [fn(i) for i in items]
        with ThreadPoolExecutor(max_workers=min(self.workers, len(items))) as pool:
            return list(pool.map(fn, items))

    def _note(self, text: str) -> None:
        self.trace.append(text)
        self.log(f"[resolve] {text}")

    # ----- candidates
    def candidate_repos(self) -> list[dict]:
        owner = self.cfg.get("github_org", "")
        include = self.cfg.get("include_repos") or []
        if include:
            repos = []
            for name in include:
                full = name if "/" in name else f"{owner}/{name}"
                info = self.gh.get_repo(full)
                if info:
                    repos.append(info)
                else:
                    self._note(f"{full}: not found or no access, skipped")
            return repos
        if not owner:
            raise ResolveError("discovery.github_org is empty: set it in config/dev-pipe.yaml or the DISCOVERY_ORG variable.")
        exclude = self.cfg.get("exclude_repos") or []
        repos = []
        for r in self.gh.list_owner_repos(owner, limit=300):
            if self.cfg.get("skip_archived", True) and (r.get("archived") or r.get("disabled")):
                continue
            if self.cfg.get("skip_forks", True) and r.get("fork"):
                continue
            if excluded(r.get("name", ""), exclude) or excluded(r.get("full_name", ""), exclude):
                continue
            repos.append(r)
        return repos[: int(self.cfg.get("max_repos", 30))]

    def _candidate(self, repo: dict, branch: str, kind: str, sha: str = "") -> dict:
        owner, name = repo["full_name"].split("/", 1)
        return {"full_name": repo["full_name"], "owner": owner, "repo": name,
                "default_branch": repo.get("default_branch", "main"), "branch": branch, "sha": sha,
                "kind": kind, "similarity": 0.0, "signal": 0, "last_commit": "", "matches": [], "evidence": [],
                "repo_keywords": 0, "index_state": ""}

    def _base_candidate(self, repo: dict, keywords: set[str]) -> dict | None:
        preferred = self.cfg.get("base_branch") or ""
        info = self.gh.get_branch(repo["full_name"], preferred) if preferred else None
        branch = preferred if info else repo.get("default_branch") or "main"
        info = info or self.gh.get_branch(repo["full_name"], branch)
        if not info:
            self._note(f"{repo['full_name']}: base branch '{branch}' not found, skipped")
            return None
        c = self._candidate(repo, branch, "base", info["sha"])
        c["repo_keywords"] = keyword_hits(
            f"{repo.get('name', '')} {repo.get('description') or ''} {' '.join(repo.get('topics') or [])}"
            .replace("-", " ").replace("_", " "), keywords)
        return c

    # ----- AAVA
    def ensure_indexed(self, cands: list[dict]) -> None:
        def check(c: dict) -> str:
            key = (c["owner"], c["repo"], c["branch"])
            try:
                state = self.aava.state_of(self.aava.progress(*key))
                if state == "NOT_INDEXED" and self.a.get("index_missing", True):
                    status = self.aava.trigger_index(*key)
                    self._note(f"{c['full_name']}@{c['branch']}: not indexed, indexing triggered ({status or 'ok'})")
                    state = "RUNNING"
            except AavaError as err:
                state = f"ERROR({err})"
            return state

        pending = []
        for c, state in zip(cands, self._parallel(check, cands)):
            c["index_state"] = state
            if state not in DONE_STATES | FAILED_STATES and not state.startswith("ERROR") and state != "NOT_INDEXED":
                pending.append((c["owner"], c["repo"], c["branch"]))
        if pending:
            final = self.aava.wait_until_done(pending, float(self.a.get("index_wait_seconds", 900)),
                                              float(self.a.get("poll_seconds", 15)))
            for c in cands:
                c["index_state"] = final.get((c["owner"], c["repo"], c["branch"]), c["index_state"])

    def search(self, c: dict, queries: list[str]) -> None:
        if c["index_state"] == "NOT_INDEXED" or c["index_state"].startswith("ERROR"):
            return
        found: dict = {}
        for q in queries:
            try:
                for m in self.aava.search(c["owner"], c["repo"], c["branch"], q,
                                          self.a.get("intent", "feature_flow"), int(self.a.get("limit", 5))):
                    key = (m["filePath"], m["startLine"])
                    if key not in found or m["similarity"] > found[key]["similarity"]:
                        found[key] = m
            except AavaError as err:
                self._note(f"{c['full_name']}@{c['branch']}: search failed ({err})")
        c["matches"] = sorted(found.values(), key=lambda m: m["similarity"], reverse=True)[:10]
        c["similarity"] = c["matches"][0]["similarity"] if c["matches"] else 0.0

    # ----- branch fallback
    def _branch_infos(self, full: str) -> list[dict]:
        """[{name, sha, date}] for every branch, newest last commit first. One GitHub GraphQL call per 100
        branches when available; otherwise one REST call per branch (run in parallel)."""
        bulk = getattr(self.gh, "branches_with_dates", None)
        if bulk:
            try:
                infos = bulk(full)
                return sorted(infos, key=lambda i: i.get("date") or "", reverse=True)
            except GitHubError as err:
                self._note(f"{full}: branch list with dates failed ({err}); listing branches one by one")
        names = self.gh.list_branches(full, limit=100_000)
        infos = [i for i in self._parallel(lambda n: self.gh.get_branch(full, n), names) if i]
        return sorted(infos, key=lambda i: i.get("date") or "", reverse=True)

    def scan_branches(self, base: dict, keywords: set[str]) -> list[dict]:
        """The branches of base's repo except the base branch itself, newest last commit first, at most
        discovery.max_branches_scanned (0 = all). They are indexed and searched in AAVA. The keyword score
        (branch name + open PR) is only shown as evidence and used to break ties."""
        full = base["full_name"]
        pulls = self.gh.open_pulls(full)
        repo = {"full_name": full, "default_branch": base["default_branch"]}
        infos = [i for i in self._branch_infos(full) if i["name"] != base["branch"]]
        cap = int(self.cfg.get("max_branches_scanned", 0) or 0)
        if cap and len(infos) > cap:
            self._note(f"{full}: {len(infos)} branches; only the {cap} with the most recent commits are scanned "
                       f"(discovery.max_branches_scanned). Use target_branch to pick an older one.")
            infos = infos[:cap]
        out = []
        for info in infos:
            name = info["name"]
            score, ev = branch_signals(keywords, name, {}, pulls)
            c = self._candidate(repo, name, "branch", info["sha"])
            c.update({"signal": score, "last_commit": info["date"], "base_of": base["branch"],
                      "evidence": ev or [f"last commit {info['date'][:10] or '?'}"]})
            out.append(c)
        self._note(f"{full}: {len(out)} branch(es) besides '{base['branch']}' will be indexed + searched")
        return out

    # ----- main entry
    def resolve(self, story: dict, override_repo: str = "", override_branch: str = "") -> dict:
        queries = story_queries(story, int(self.a.get("max_queries", 3)))
        self.last_queries = queries
        keywords = story_keywords(story)
        min_sim = float(self.cfg.get("base_min_similarity", 0.75))
        margin = float(self.cfg.get("min_margin", 0.05))

        if override_repo:
            return self._manual(override_repo, override_branch, queries)

        repos = self.candidate_repos()
        if not repos:
            raise ResolveError("No candidate repositories found (check discovery settings and token access).")
        self._note(f"{len(repos)} candidate repo(s); queries: {queries}")

        # Phase 1: base branches
        bases = [c for c in self._parallel(lambda r: self._base_candidate(r, keywords), repos) if c]
        self.ensure_indexed(bases)
        self._parallel(lambda c: self.search(c, queries), bases)
        for c in bases:
            self._note(f"{c['full_name']}@{c['branch']}: top similarity {c['similarity']:.2f} "
                       f"(index {c['index_state']}, repo keywords {c['repo_keywords']})")
        ranked = sorted(bases, key=lambda c: (c["similarity"], c["repo_keywords"]), reverse=True)
        best, confidence = decide(ranked, min_sim, margin)
        if best:
            return self._result(best, "base", confidence,
                                f"found on base branch '{best['branch']}' (similarity {best['similarity']:.2f})", ranked)

        # Phase 2: other branches of the most likely repos
        self._note(f"nothing above {min_sim} on base branches; scanning other branches")
        branch_cands = []
        for base in ranked[: int(self.cfg.get("repos_for_branch_scan", 3))]:
            try:
                branch_cands += self.scan_branches(base, keywords)
            except GitHubError as err:
                self._note(f"{base['full_name']}: branch scan failed ({err})")
        # All branches are searched; this order only decides ties and the order of the log.
        shortlist = sorted(branch_cands, key=lambda c: (c["signal"], c["last_commit"]), reverse=True)
        if shortlist:
            self.ensure_indexed(shortlist)
            self._parallel(lambda c: self.search(c, queries), shortlist)
            for c in shortlist:
                self._note(f"{c['full_name']}@{c['branch']}: top similarity {c['similarity']:.2f}")
        shortlist.sort(key=lambda c: (c["similarity"], c["signal"], c["last_commit"]), reverse=True)
        best, confidence = decide(shortlist, min_sim, margin)
        if best:
            why = f"similarity {best['similarity']:.2f}; " + "; ".join(best["evidence"])
            others = sorted(shortlist, key=lambda c: c["similarity"], reverse=True)
            return self._result(best, "branch", confidence,
                                f"not found on base branches; found on branch '{best['branch']}' ({why})",
                                others + ranked)

        # Phase 3: fall back to the most likely repo (could be brand-new work), or stop.
        top = ranked[0]
        if top["similarity"] > 0 or top["repo_keywords"] > 0 or len(ranked) == 1 or shortlist:
            others = sorted(shortlist, key=lambda c: c["similarity"], reverse=True) + ranked
            return self._result(top, "base", "low",
                                "no strong match anywhere; using the most likely repo's base branch "
                                "(the story may be new work). If the code is on one of the candidate branches "
                                "listed below, reject and re-run with target_repo / target_branch.", others)
        raise ResolveError(
            "Could not decide the target repository for this story. Re-run with the `target_repo` input "
            "(owner/repo) and optionally `target_branch`.\n" + "\n".join(self.trace[-30:]))

    def _manual(self, full: str, branch: str, queries: list[str]) -> dict:
        repo = self.gh.get_repo(full)
        if not repo:
            raise ResolveError(f"TARGET_REPO '{full}' not found or the token has no access to it.")
        branch = branch or self.cfg.get("base_branch") or repo.get("default_branch") or "main"
        info = self.gh.get_branch(full, branch)
        if not info:
            raise ResolveError(f"Branch '{branch}' not found in {full}.")
        c = self._candidate(repo, branch, "manual", info["sha"])
        self.ensure_indexed([c])
        self.search(c, queries)
        return self._result(c, "manual", "manual", f"set manually: {full}@{branch}", [c])

    def _result(self, c: dict, found_on: str, confidence: str, reason: str, others: list[dict]) -> dict:
        alts, seen = [], {(c["full_name"], c["branch"])}
        for o in others:
            if (o["full_name"], o["branch"]) in seen:
                continue
            seen.add((o["full_name"], o["branch"]))
            alts.append({"full_name": o["full_name"], "branch": o["branch"],
                         "similarity": round(o["similarity"], 3), "signal": o["signal"],
                         "last_commit": o.get("last_commit", ""), "evidence": "; ".join(o.get("evidence", []))})
        alts = alts[:15]
        self._note(f"chosen {c['full_name']}@{c['branch']} ({confidence}): {reason}")
        return {
            "full_name": c["full_name"], "owner": c["owner"], "repo": c["repo"],
            "default_branch": c["default_branch"],
            "base_branch": c["branch"],          # work starts here and the PR targets it
            "base_sha": c["sha"],
            "found_on": found_on, "confidence": confidence, "reason": reason,
            "similarity": round(c["similarity"], 3), "evidence": c["evidence"],
            "matches": c["matches"], "alternatives": alts, "trace": self.trace[-50:],
            "index_state": c.get("index_state", ""), "queries": len(getattr(self, "last_queries", []) or []),
        }


def code_context(target: dict, limit: int = 8) -> str:
    """AAVA matches for the chosen repo/branch, as a prompt section."""
    rows = []
    for m in (target.get("matches") or [])[:limit]:
        loc = f"{m['filePath']}:{m.get('startLine') or '?'}-{m.get('endLine') or '?'}"
        preview = (m.get("contentPreview") or "").strip()[:600]
        rows.append(f"### {loc} ({m.get('name') or ''}, similarity {m['similarity']:.2f})\n```\n{preview}\n```")
    return "\n\n".join(rows) or "(no matches from the code context service; explore the repo with Grep/Glob)"
