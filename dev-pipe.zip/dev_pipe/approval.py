"""Human approval through a GitHub Issue (works on any GitHub plan, no Environments needed).

The pipeline opens an issue describing what needs approval, then polls its comments until an
allowed approver comments `approve` or `reject: <reason>`, or the timeout is reached.

Standard library only, so approval jobs start in seconds without installing dependencies.
Comment text is untrusted input: it is only matched against two keywords, never executed.
"""
from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request

APPROVE_RE = re.compile(r"^\s*/?approved?\b", re.I)
REJECT_RE = re.compile(r"^\s*/?reject(?:ed)?\b[\s:,\-]*(.*)", re.I | re.S)
BOT_LOGINS = {"github-actions[bot]"}


def parse_approvers(raw: str) -> set[str]:
    """'alice, @Bob  carol' -> {'alice', 'bob', 'carol'} (GitHub logins are case-insensitive)."""
    return {a.strip().lstrip("@").lower() for a in re.split(r"[,\s]+", raw or "") if a.strip()}


def decide(comments: list[dict], approvers: set[str]) -> tuple[str, str, str] | None:
    """First decision by an allowed approver, oldest comment first.
    Returns (decision, reason, login) with decision 'approve' or 'reject', or None if undecided.
    Comments from anyone not in `approvers` (and the bot itself) are ignored."""
    for c in comments:
        login = (c.get("user") or {}).get("login", "")
        if not login or login in BOT_LOGINS or login.lower() not in approvers:
            continue
        body = (c.get("body") or "").strip()
        if APPROVE_RE.match(body):
            return "approve", "", login
        match = REJECT_RE.match(body)
        if match:
            return "reject", match.group(1).strip() or "(no reason given)", login
    return None


class GitHubIssues:
    """Minimal GitHub REST client for one repository's issues."""

    def __init__(self, token: str, repo: str, api: str = "https://api.github.com"):
        if not token or not repo:
            raise SystemExit("GITHUB_TOKEN and GITHUB_REPOSITORY are required for approval gates.")
        self.base = f"{api.rstrip('/')}/repos/{repo}"
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "dev-pipe-approval",
        }

    def _request(self, method: str, path: str, data: dict | None = None, params: dict | None = None):
        url = self.base + path + (f"?{urllib.parse.urlencode(params)}" if params else "")
        body = json.dumps(data).encode() if data is not None else None
        req = urllib.request.Request(url, data=body, method=method,
                                     headers={**self.headers, "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = resp.read()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as err:
            detail = err.read().decode(errors="replace")[:300]
            hint = (" Are Issues enabled on the repo (Settings > General > Features > Issues), and does "
                    "the job have 'issues: write' permission?") if err.code in (403, 404, 410) else ""
            raise SystemExit(f"GitHub {method} {path} -> HTTP {err.code}: {detail}{hint}") from None

    def create_issue(self, title: str, body: str) -> dict:
        return self._request("POST", "/issues", {"title": title, "body": body})

    def list_comments(self, number: int) -> list[dict]:
        comments, page = [], 1
        while True:
            batch = self._request("GET", f"/issues/{number}/comments", params={"per_page": 100, "page": page})
            comments.extend(batch)
            if len(batch) < 100:
                return comments
            page += 1

    def comment(self, number: int, body: str) -> None:
        self._request("POST", f"/issues/{number}/comments", {"body": body})

    def close(self, number: int, completed: bool) -> None:
        self._request("PATCH", f"/issues/{number}",
                      {"state": "closed", "state_reason": "completed" if completed else "not_planned"})

    def get_run(self, run_id: int) -> dict:
        """A GitHub Actions workflow run of this repository (comment-triggered approval)."""
        return self._request("GET", f"/actions/runs/{int(run_id)}")


def wait_for_decision(gh: GitHubIssues, number: int, approvers: set[str], timeout_s: float,
                      poll_s: float = 30, sleep=time.sleep, now=time.monotonic):
    """Poll the issue's comments until a decision or the timeout. Returns decide()'s result or None."""
    deadline = now() + timeout_s
    while True:
        decision = decide(gh.list_comments(number), approvers)
        if decision or now() >= deadline:
            return decision
        sleep(poll_s)
