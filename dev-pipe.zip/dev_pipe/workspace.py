"""External mode: GitHub token handling and the target repo checkout (target-checkout/).

Security:
- The token is read once from TARGET_GITHUB_TOKEN (or GH_PAT) and REMOVED from os.environ, so the
  agent (which inherits the environment) never sees it.
- Git authenticates through per-command environment config (GIT_CONFIG_*), never through the
  remote URL or .git/config, so nothing on disk holds the token.
"""
from __future__ import annotations

import base64
import os
import shutil
import subprocess

from dev_pipe.config import ROOT, TARGET_CHECKOUT, is_external, resolved_target, settings

_TOKEN_VARS = ("TARGET_GITHUB_TOKEN", "GH_PAT")
_token: str | None = None


def take_token() -> str:
    """GitHub token for the target repos. Removed from the environment on first call."""
    global _token
    if _token is None:
        _token = ""
        for name in _TOKEN_VARS:
            value = os.environ.pop(name, "").strip()
            _token = _token or value
    return _token


def git_auth_env(token: str | None = None) -> dict:
    token = take_token() if token is None else token
    if not token:
        return {}
    basic = base64.b64encode(f"x-access-token:{token}".encode()).decode()
    server = os.environ.get("GITHUB_SERVER_URL", "https://github.com").rstrip("/")   # GitHub Enterprise Server too
    return {"GIT_CONFIG_COUNT": "1", "GIT_CONFIG_KEY_0": f"http.{server}/.extraheader",
            "GIT_CONFIG_VALUE_0": f"AUTHORIZATION: basic {basic}", "GIT_TERMINAL_PROMPT": "0"}


_local_token: str | None = None


def take_local_token() -> str:
    """Local mode: token for the pipeline's own git remote commands (Step 7 pushes the AI's fixes). The AI jobs
    check out with persist-credentials: false, so no token is stored in .git/config; this one is passed per
    command instead. Removed from the environment on first call."""
    global _local_token
    if _local_token is None:
        _local_token = os.environ.pop("LOCAL_GIT_TOKEN", "").strip()
    return _local_token


def _git(*args: str, cwd=TARGET_CHECKOUT, auth: bool = False) -> str:
    env = {**os.environ, **(git_auth_env() if auth else {})}
    proc = subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, env=env)
    if proc.returncode != 0:
        raise SystemExit(f"git {' '.join(args[:2])} (target repo) failed: {proc.stderr.strip()[:500]}")
    return proc.stdout.strip()


def prepare_checkout(target: dict | None = None) -> None:
    """Checks out the resolved repo at its base commit in target-checkout/ (no-op in local mode or if already there)."""
    if not is_external():
        return
    target = target or resolved_target()
    if not target.get("full_name") or not target.get("base_sha"):
        raise SystemExit("Missing out/target.json (repo + base commit). Did Steps 1-2 finish?")
    if (TARGET_CHECKOUT / ".git").exists():
        try:
            if _git("rev-parse", "HEAD") == target["base_sha"]:
                return
        except SystemExit:
            pass
        shutil.rmtree(TARGET_CHECKOUT)
    TARGET_CHECKOUT.mkdir(parents=True, exist_ok=True)
    server = os.environ.get("GITHUB_SERVER_URL", "https://github.com").rstrip("/")
    _git("init", "-q")
    _git("remote", "add", "origin", f"{server}/{target['full_name']}.git")
    _git("fetch", "-q", "--depth", "1", "origin", target["base_sha"], auth=True)
    _git("checkout", "-q", "--detach", "FETCH_HEAD")
    install_skills()
    print(f"[workspace] {target['full_name']}@{target['base_branch']} ({target['base_sha'][:10]}) -> target-checkout/",
          flush=True)


def fetch_base_ref(branch: str) -> None:
    """Adds origin/<branch> to the depth-1 checkout (external mode), so the Sonar scanner finds the
    reference branch ("Could not find ref 'main'" warning otherwise). Never fails the step."""
    if not is_external() or not branch:
        return
    try:
        _git("fetch", "-q", "--depth", "1", "origin", f"+refs/heads/{branch}:refs/remotes/origin/{branch}", auth=True)
    except SystemExit as err:
        print(f"[workspace] could not fetch origin/{branch}: {err}", flush=True)


def prepare_full_clone(target: dict | None = None) -> None:
    """Replaces target-checkout/ with a regular, full `git clone` of the target repo (all history, normal
    remote-tracking refs). Used by Step 7: the SonarQube scanner could not compute a PR's changed
    lines in the init + depth-1 fetch + unshallow checkout that prepare_checkout builds
    ("SCM reported changed lines for 0 files" -> "0 New lines of code"), while the same commit
    scanned from a normal clone worked. Auth works as in prepare_checkout: the token goes in a
    per-command header, never into the remote URL or .git/config. No-op in local mode."""
    if not is_external():
        return
    target = target or resolved_target()
    if not target.get("full_name"):
        raise SystemExit("Missing out/target.json (repo + base commit). Did Steps 1-2 finish?")
    if TARGET_CHECKOUT.exists():
        shutil.rmtree(TARGET_CHECKOUT)
    TARGET_CHECKOUT.parent.mkdir(parents=True, exist_ok=True)
    server = os.environ.get("GITHUB_SERVER_URL", "https://github.com").rstrip("/")
    _git("clone", "-q", "--no-tags", f"{server}/{target['full_name']}.git", str(TARGET_CHECKOUT),
         cwd=TARGET_CHECKOUT.parent, auth=True)
    install_skills()
    print(f"[workspace] {target['full_name']} full clone -> target-checkout/ (for the SonarQube scan)", flush=True)


def install_skills() -> None:
    """Copies this repo's agent skills into the checkout so the agent can load them there,
    and hides them from git so they never end up in the change set or PR."""
    names = settings().get("agent", {}).get("skills") or []
    src_root = ROOT / ".claude" / "skills"
    dst_root = TARGET_CHECKOUT / ".claude" / "skills"
    exclude = TARGET_CHECKOUT / ".git" / "info" / "exclude"
    exclude.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    for name in names:
        src, dst = src_root / name, dst_root / name
        if src.is_dir() and not dst.exists():
            shutil.copytree(src, dst)
            lines.append(f"/.claude/skills/{name}/")
    if lines:
        with open(exclude, "a", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
