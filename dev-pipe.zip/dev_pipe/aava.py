"""Client for the AAVA Code Context Service (see USAGE_GUIDE.md).

Endpoints: POST /api/index, GET /api/index/progress, POST /api/search.
Behaviour taken from the guide:
- Look at data.status (not the outer status) after POST /api/index: TRIGGERED or SKIPPED_RUNNING.
- Progress 404 = never indexed (or deleted). FAILED may still leave partial chunks searchable.
- Zero matches is not an error. Only .md and .json files are indexed.
- `query` must always be a string.

The exact JSON nesting of progress/search responses is not fully specified in the guide, so the
parsers below accept the fields either at the top level or under `data`, and the match list under
`matches`, `results`, `items` or `chunks`.
"""
from __future__ import annotations

import time

import requests

DEFAULT_BASE_URL = "https://aava-code-indexer.redbush-6668be79.eastus2.azurecontainerapps.io"
DONE_STATES = {"COMPLETED", "DONE"}
FAILED_STATES = {"FAILED", "ERROR"}


class AavaError(RuntimeError):
    pass


def _data(payload):
    if isinstance(payload, dict) and isinstance(payload.get("data"), (dict, list)):
        return payload["data"]
    return payload


def normalize_matches(payload) -> list[dict]:
    """Search response -> [{filePath, name, startLine, endLine, contentPreview, similarity}]."""
    data = _data(payload)
    items = data
    if isinstance(data, dict):
        items = next((data[k] for k in ("matches", "results", "items", "chunks") if isinstance(data.get(k), list)), [])
    out = []
    for m in items or []:
        if not isinstance(m, dict):
            continue
        try:
            sim = float(m.get("similarity", m.get("score", 0)) or 0)
        except (TypeError, ValueError):
            sim = 0.0
        out.append({
            "filePath": m.get("filePath") or m.get("path") or "",
            "name": m.get("name") or "",
            "startLine": m.get("startLine"),
            "endLine": m.get("endLine"),
            "contentPreview": (m.get("contentPreview") or m.get("content") or "")[:1200],
            "similarity": sim,
        })
    return sorted(out, key=lambda x: x["similarity"], reverse=True)


class Aava:
    def __init__(self, base_url: str = "", github_token: str = "", session: requests.Session | None = None,
                 sleep=time.sleep, clock=time.monotonic):
        self.base = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.github_token = github_token
        self.session = session or requests.Session()
        self._sleep, self._clock = sleep, clock

    def _body(self, owner: str, repo: str, branch: str, **extra) -> dict:
        body = {"owner": owner, "repo": repo, "branch": branch, **extra}
        if self.github_token:
            body["githubToken"] = self.github_token
        return body

    def trigger_index(self, owner: str, repo: str, branch: str) -> str:
        resp = self.session.post(f"{self.base}/api/index", timeout=60,
                                 json=self._body(owner, repo, branch, source="github"))
        if resp.status_code >= 400:
            raise AavaError(f"AAVA index {owner}/{repo}@{branch} -> HTTP {resp.status_code}: {resp.text[:300]}")
        data = _data(resp.json() if resp.content else {})
        return str((data or {}).get("status", "")) if isinstance(data, dict) else ""

    def progress(self, owner: str, repo: str, branch: str) -> dict | None:
        """Progress dict ({state, percentComplete, chunksProduced, errorMessage...}) or None if never indexed."""
        resp = self.session.get(f"{self.base}/api/index/progress", timeout=30,
                                params={"owner": owner, "repo": repo, "branch": branch})
        if resp.status_code == 404:
            return None
        if resp.status_code >= 400:
            raise AavaError(f"AAVA progress {owner}/{repo}@{branch} -> HTTP {resp.status_code}: {resp.text[:300]}")
        data = _data(resp.json() if resp.content else {})
        return data if isinstance(data, dict) else {}

    @staticmethod
    def state_of(progress: dict | None) -> str:
        if progress is None:
            return "NOT_INDEXED"
        return str(progress.get("state") or progress.get("status") or "").upper()

    def wait_until_done(self, targets: list[tuple[str, str, str]], timeout: float, poll: float) -> dict:
        """Polls several (owner, repo, branch) until each is done/failed or the shared deadline passes.
        Returns {(owner, repo, branch): final state}."""
        deadline = self._clock() + max(0.0, timeout)
        states = {t: "PENDING" for t in targets}
        while True:
            for t in [t for t, s in states.items() if s not in DONE_STATES | FAILED_STATES]:
                states[t] = self.state_of(self.progress(*t)) or "RUNNING"
            pending = [t for t, s in states.items() if s not in DONE_STATES | FAILED_STATES]
            if not pending or self._clock() >= deadline:
                for t in pending:
                    states[t] = f"TIMEOUT({states[t]})"
                return states
            self._sleep(poll)

    def search(self, owner: str, repo: str, branch: str, query: str, intent: str = "feature_flow",
               limit: int = 5) -> list[dict]:
        resp = self.session.post(f"{self.base}/api/search", timeout=60,
                                 json=self._body(owner, repo, branch, query=query or "", intent=intent,
                                                 limit=int(limit)))
        if resp.status_code >= 400:
            raise AavaError(f"AAVA search {owner}/{repo}@{branch} -> HTTP {resp.status_code}: {resp.text[:300]}")
        return normalize_matches(resp.json() if resp.content else {})
