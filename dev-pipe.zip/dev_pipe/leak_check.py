"""Last check before anything the AI wrote leaves the runner: no credentials in the change set or the plan.

Story text and repository content are untrusted: a hidden instruction could try to make the AI copy a secret
into the code, a comment or its notes. The other layers (secrets hidden from the AI, no network) make that very
hard; this one makes sure nothing that looks like a credential is pushed or posted.

Checks only ADDED lines of the patch, plus the plan / AI notes that go into the PR and ADO:
  - the exact values (and their base64 forms) of the secrets this step holds, and
  - well-known credential formats (GitHub, Azure, AWS, Slack, Anthropic/OpenAI keys, private keys, JWTs, ...).
Values are never printed: findings name the file, the line number and the kind of secret only.
security.leak_check in config/dev-pipe.yaml: block (default) | warn | off.
"""
from __future__ import annotations

import base64
import os
import re
from dataclasses import dataclass

PATTERNS: dict[str, re.Pattern] = {
    "GitHub token": re.compile(r"\b(gh[pousr]_[A-Za-z0-9]{36,}|github_pat_[A-Za-z0-9_]{60,})\b"),
    "private key": re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY-----"),
    "AWS access key": re.compile(r"\b(AKIA|ASIA)[0-9A-Z]{16}\b"),
    "Azure storage key": re.compile(r"AccountKey=[A-Za-z0-9+/]{80,}={0,2}"),
    "Slack token": re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}\b"),
    "Anthropic key": re.compile(r"\bsk-ant-[A-Za-z0-9_-]{20,}\b"),
    "OpenAI key": re.compile(r"\bsk-(?:proj-)?[A-Za-z0-9_-]{32,}\b"),
    "SonarQube token": re.compile(r"\b(squ|sqp|sqa)_[a-f0-9]{40}\b"),
    "JSON web token": re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"),
    "basic/bearer credential": re.compile(r"(?i)authorization:\s*(basic|bearer)\s+[A-Za-z0-9+/=._-]{20,}"),
}
# Environment variables whose values must never appear in the AI's output.
SECRET_VARS = ("ADO_PAT", "GH_PAT", "TARGET_GITHUB_TOKEN", "GITHUB_TOKEN", "LOCAL_GIT_TOKEN", "SONAR_TOKEN",
               "ANTHROPIC_API_KEY", "AZURE_OPENAI_API_KEY", "NPM_TOKEN", "NODE_AUTH_TOKEN")


@dataclass
class Finding:
    where: str      # file path (or "plan.md") and line number
    kind: str       # what was found, never the value

    def __str__(self) -> str:
        return f"{self.where}: {self.kind}"


def _known_values(extra: dict[str, str] | None = None) -> dict[str, str]:
    values = {n: os.environ.get(n, "") for n in SECRET_VARS}
    values.update(extra or {})
    out: dict[str, str] = {}
    for name, value in values.items():
        value = (value or "").strip()
        if len(value) < 12:
            continue   # too short to search for safely
        out[value] = f"the value of {name}"
        out[base64.b64encode(value.encode()).decode().rstrip("=")] = f"the value of {name} (base64)"
        out[base64.b64encode(f"x-access-token:{value}".encode()).decode().rstrip("=")] = f"the value of {name} (git auth header)"
    return out


def _scan_line(line: str, where: str, known: dict[str, str]) -> list[Finding]:
    found = [Finding(where, kind) for value, kind in known.items() if value and value in line]
    found += [Finding(where, kind) for kind, pattern in PATTERNS.items() if pattern.search(line)]
    return found


def scan_text(text: str, where: str, known: dict[str, str] | None = None) -> list[Finding]:
    known = known if known is not None else _known_values()
    found: list[Finding] = []
    for n, line in enumerate((text or "").splitlines(), 1):
        found += _scan_line(line, f"{where}, line {n}", known)
    return found


def scan_patch(patch: str | bytes, known: dict[str, str] | None = None) -> list[Finding]:
    """Only lines the change ADDS (old content that was already in the repo is not the AI's doing)."""
    text = patch.decode("utf-8", errors="replace") if isinstance(patch, bytes) else (patch or "")
    known = known if known is not None else _known_values()
    found: list[Finding] = []
    path, new_line = "?", 0
    for line in text.splitlines():
        if line.startswith("+++ "):
            path = line[4:].strip()
            path = path[2:] if path.startswith("b/") else path
            continue
        if line.startswith("--- ") or line.startswith("diff --git") or line.startswith("index "):
            continue
        m = re.match(r"^@@ -\d+(?:,\d+)? \+(\d+)", line)
        if m:
            new_line = int(m.group(1))
            continue
        if line.startswith("+"):
            found += _scan_line(line[1:], f"{path}, line {new_line}", known)
            new_line += 1
        elif not line.startswith("-"):
            new_line += 1
    return found


def mode() -> str:
    from dev_pipe.config import settings
    value = str(((settings().get("security") or {}).get("leak_check", "block"))).strip().lower()
    return value if value in ("block", "warn", "off") else "block"


def enforce(findings: list[Finding], what: str) -> None:
    """block: stop the step (nothing is pushed/posted). warn: print and continue. off: nothing."""
    m = mode()
    if m == "off" or not findings:
        return
    lines = "\n".join(f"  - {f}" for f in findings[:20])
    message = (f"Possible credential(s) in {what} (values not shown):\n{lines}\n"
               "Nothing was pushed. Check these lines; if they are harmless (e.g. a fake key in a test), "
               "change them, or set security.leak_check: warn in config/dev-pipe.yaml.")
    if m == "warn":
        print(f"[leak-check] WARNING: {message}", flush=True)
        return
    raise SystemExit(message)
