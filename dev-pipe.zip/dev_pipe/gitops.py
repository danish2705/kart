"""Git + GitHub helpers. The agent never commits, pushes or opens PRs; these do, after approval.

Local mode: runs in this repo (ROOT). External mode: runs in the target repo checkout (target-checkout/),
authenticating fetch/push with the target-repo token (see dev_pipe/workspace.py).
"""
from __future__ import annotations

import os
import subprocess

import requests

from dev_pipe.config import ROOT, TARGET_CHECKOUT, is_external, secret

BOT_EMAIL = "dev-agent" + "@" + "users.noreply.github.com"

# Never part of a change set: pipeline hand-off files and tool output.
EXCLUDES = [":(exclude)out", ":(exclude,glob)**/.scannerwork/**", ":(exclude,glob)**/.sonarqube/**",
            ":(exclude,glob)**/coverage.xml", ":(exclude,glob)**/.coverage",
            # LCOV output of JS/TS test runs (Vitest/Jest `lcov` reporter):
            ":(exclude,glob)**/coverage/lcov.info", ":(exclude,glob)**/coverage/lcov-report/**",
            # Left behind by the build check (installs, compileall, pytest, pip install -e), never part of a change:
            ":(exclude,glob)**/node_modules/**", ":(exclude,glob)**/__pycache__/**",
            ":(exclude,glob)**/*.egg-info/**", ":(exclude,glob)**/.pytest_cache/**"]

# Commands that talk to the remote and need the target-repo token in external mode.
_REMOTE_COMMANDS = {"push", "fetch", "pull", "ls-remote"}


def _cwd():
    return TARGET_CHECKOUT if is_external() else ROOT


def _env(args: tuple[str, ...]) -> dict | None:
    if not (args and args[0] in _REMOTE_COMMANDS):
        return None
    from dev_pipe.workspace import git_auth_env, take_local_token
    if is_external():
        return {**os.environ, **git_auth_env()}
    local = take_local_token()   # local mode, jobs checked out without stored credentials (Step 7)
    return {**os.environ, **git_auth_env(local)} if local else None


def git(*args: str, check: bool = True) -> str:
    proc = subprocess.run(["git", *args], cwd=_cwd(), capture_output=True, text=True, env=_env(args))
    if check and proc.returncode != 0:
        raise SystemExit(f"git {' '.join(args[:2])} failed: {proc.stderr.strip()[:500]}")
    return proc.stdout.strip()


def git_bytes(*args: str) -> bytes:
    """Binary-safe variant: patches must keep CRLF line endings byte-for-byte."""
    proc = subprocess.run(["git", *args], cwd=_cwd(), capture_output=True)
    if proc.returncode != 0:
        raise SystemExit(f"git {' '.join(args[:2])} failed: {proc.stderr.decode(errors='replace').strip()[:500]}")
    return proc.stdout


def configure_identity() -> None:
    git("config", "user.name", os.environ.get("GIT_AUTHOR_NAME", "dev-agent[bot]"))
    git("config", "user.email", os.environ.get("GIT_AUTHOR_EMAIL") or BOT_EMAIL)


def head_sha() -> str:
    return git("rev-parse", "HEAD")


def snapshot_patch(base: str) -> bytes:
    """Everything changed since `base` (tracked + new files, even if the agent committed)
    as one binary-safe patch."""
    git("add", "-A", "--", ".", *EXCLUDES)
    return git_bytes("diff", "--cached", "--binary", base, "--", ".", *EXCLUDES)


def apply_patch(patch_path) -> None:
    if os.path.getsize(patch_path) == 0:
        return
    git("apply", "--index", "--whitespace=nowarn", str(patch_path))


def changed_files_stats(base: str) -> list[dict]:
    """Changed files since `base` with added/removed line counts (call after snapshot_patch)."""
    rows = []
    for line in git("diff", "--cached", "--numstat", base, "--", ".", *EXCLUDES).splitlines():
        added, removed, path = line.split("\t", 2)
        rows.append({"path": path, "added": added, "removed": removed})
    new_files = set(git("diff", "--cached", "--name-only", "--diff-filter=A", base, "--", ".", *EXCLUDES).splitlines())
    for r in rows:
        r["new"] = r["path"] in new_files
    return rows


def changed_paths(base: str) -> list[str]:
    """Paths changed since `base` (tracked edits + new untracked files), without staging anything."""
    tracked = git("diff", "--name-only", base, "--", ".", *EXCLUDES).splitlines()
    untracked = git("ls-files", "--others", "--exclude-standard", "--", ".", *EXCLUDES).splitlines()
    return sorted({p for p in tracked + untracked if p.strip()})


def change_diff(base: str) -> str:
    """Zero-context diff of everything changed since `base` (tracked edits + new files), used to find
    the exact lines the agent added or changed. Stages like snapshot_patch does; nothing is committed."""
    git("add", "-A", "--", ".", *EXCLUDES)
    return git("-c", "core.quotepath=false", "diff", "--cached", "-U0", "--no-color", "--no-ext-diff",
               base, "--", ".", *EXCLUDES)


_SKIP_FIND = {".git", "node_modules", "__pycache__", ".venv", "venv", ".scannerwork", ".sonarqube"}


def fix_architecture_file(base: str, rel_path: str) -> list[str]:
    """The architecture context file must live at the repo root (target.architecture_file), where Steps 1-2
    look for it. The agent sometimes writes it inside a sub-folder (e.g. backend/.github/...). Copies the
    agent CREATED in this run (not in `base`) are moved to the root path, or removed if the root file already
    exists. Files that were already in the repository are never touched. Returns log lines."""
    import shutil
    from pathlib import Path
    root = Path(_cwd())
    target = root / rel_path
    name = Path(rel_path).name
    tail = Path(rel_path).parts
    found = []
    for d, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if x not in _SKIP_FIND]
        if name in files:
            p = Path(d) / name
            if p.resolve() != target.resolve() and p.parts[-len(tail):] == tail:
                found.append(p)
    notes = []
    for p in sorted(found):
        rel = p.relative_to(root).as_posix()
        existed = subprocess.run(["git", "cat-file", "-e", f"{base}:{rel}"], cwd=root,
                                 capture_output=True).returncode == 0
        if existed:
            continue   # part of the repository already: not ours to move
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(p), str(target))
            notes.append(f"moved {rel} -> {rel_path}")
        else:
            p.unlink()
            notes.append(f"removed duplicate {rel} ({rel_path} already exists)")
        try:   # drop folders left empty by the move (e.g. backend/.github/)
            p.parent.rmdir()
        except OSError:
            pass
    for n in notes:
        print(f"[workspace] architecture file: {n}", flush=True)
    return notes


def risky_changes(stats: list[dict]) -> list[dict]:
    """Edits that remove or rewrite existing code -- the meeting's 'ask before changing existing blocks'."""
    out = []
    for r in stats:
        removed = int(r["removed"]) if r["removed"].isdigit() else 0
        if not r["new"] and removed > 0:
            out.append(r)
    return out


def push_branch(branch: str, base_branch: str = "") -> bool:
    """Pushes `branch`. If it already exists on the remote (a re-run of the same story), it is replaced
    only when every commit on it that the new commit lacks was made by the pipeline itself, so a
    developer's commits are never overwritten. Returns True if an existing branch was replaced.

    External mode checks the target repo out with only its latest commit (shallow). If the base branch moved
    since the earlier run, git could then not see that the old branch's history is part of the base, and listed
    every older base commit as "someone else's work", wrongly blocking the re-run. So before that check a
    shallow checkout fetches the base branch's full history (only on a re-run, when the branch already exists)."""
    remote = git("ls-remote", "origin", f"refs/heads/{branch}")
    if not remote:
        git("push", "--set-upstream", "origin", branch)
        return False
    remote_sha = remote.split()[0]
    git("fetch", "-q", "origin", f"+refs/heads/{branch}:refs/remotes/origin/{branch}")
    if git("rev-parse", "--is-shallow-repository", check=False) == "true":
        refspec = [f"+refs/heads/{base_branch}:refs/remotes/origin/{base_branch}"] if base_branch else []
        print(f"[git] '{branch}' exists from an earlier run; fetching full history of "
              f"'{base_branch or 'the remote'}' to check who made its commits", flush=True)
        git("fetch", "-q", "--unshallow", "origin", *refspec)
    me = git("config", "user.email")
    authors = set(git("log", "--format=%ae", f"origin/{branch}", "--not", "HEAD~1").splitlines())
    others = sorted(a for a in authors if a and a != me)
    if others:
        raise SystemExit(
            f"Branch '{branch}' already exists on the remote with commits by {', '.join(others)}. Not overwriting "
            "someone else's work: merge or close that PR and delete the branch, then re-run this step.")
    print(f"[git] '{branch}' exists from an earlier pipeline run (only pipeline commits); replacing it", flush=True)
    git("push", "--set-upstream", f"--force-with-lease={branch}:{remote_sha}", "origin", branch)
    return True


def create_pull_request(head: str, base: str, title: str, body: str) -> dict:
    if is_external():
        from dev_pipe.config import resolved_target
        from dev_pipe.github_api import GitHub, GitHubError
        from dev_pipe.workspace import take_token
        token = take_token()
        if not token:
            raise SystemExit("Missing TARGET_GITHUB_TOKEN (GH_PAT secret) to open a PR on the target repo.")
        try:
            return GitHub(token).create_pull_request(resolved_target()["full_name"], head, base, title, body)
        except GitHubError as err:
            raise SystemExit(f"GitHub PR creation failed: {err}")
    api = os.environ.get("GITHUB_API_URL", "https://api.github.com")
    repo = os.environ.get("GITHUB_REPOSITORY", "")
    if not repo:
        raise SystemExit("GITHUB_REPOSITORY is not set (this step is meant to run in GitHub Actions).")
    from dev_pipe.github_api import GitHub, GitHubError
    try:
        existing = GitHub(secret("GITHUB_TOKEN"), api).find_open_pull(repo, head, base)
        if existing:
            GitHub(secret("GITHUB_TOKEN"), api).update_pull_request(repo, existing["number"], title, body)
            print(f"[github] PR #{existing['number']} already open for {head} -> {base}; updated it", flush=True)
            return {**existing, "reused": True}
    except GitHubError as err:
        raise SystemExit(f"GitHub PR lookup failed: {err}")
    resp = requests.post(
        f"{api}/repos/{repo}/pulls",
        headers={"Authorization": f"Bearer {secret('GITHUB_TOKEN')}", "Accept": "application/vnd.github+json"},
        json={"title": title, "head": head, "base": base, "body": body},
        timeout=30,
    )
    if resp.status_code >= 400:
        raise SystemExit(f"GitHub PR creation failed: HTTP {resp.status_code}: {resp.text[:400]}")
    data = resp.json()
    return {"number": data["number"], "url": data["html_url"], "head": head, "base": base}
