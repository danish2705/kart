"""Runs one Claude Agent SDK conversation for a pipeline step.

Two tool profiles:
- read_only: Read/Grep/Glob -- used for Step 2 (Development Planning), can't change anything.
- edit: adds Write/Edit/Bash -- used for implementation and fixes. git commit/push and
  network tools are blocked; the pipeline does those itself after approval.

Isolation (dev_pipe/agent_isolation.py): secrets are removed from the environment while the agent runs, the
pipeline process is made unreadable to it, and its shell commands run in a sandbox with no network (the
pipeline installs the project's dependencies first).
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import time
from contextlib import contextmanager
from typing import Callable

from claude_agent_sdk import (
    AssistantMessage,
    ClaudeAgentOptions,
    ClaudeSDKClient,
    ResultMessage,
    TextBlock,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)

from dev_pipe import agent_isolation
from dev_pipe.config import settings, work_root
from dev_pipe.report_data import is_test_path  # noqa: F401  (one shared rule; used below, re-exported)

# A completion check: given the agent's final message, returns None when the work is complete,
# otherwise the follow-up message to send (first line = short reason for the log).
Check = Callable[[str], "str | None"]
MAX_FOLLOWUPS = 2

READ_ONLY_TOOLS = ["Read", "Grep", "Glob"]
EDIT_TOOLS = READ_ONLY_TOOLS + ["Write", "Edit", "Bash"]
BLOCKED_TOOLS = [
    "WebFetch", "WebSearch",
    # Other processes' environment/memory (defence in depth; the pipeline process is also made non-dumpable).
    "Read(//proc/**)",
    "Bash(git push:*)", "Bash(git commit:*)", "Bash(git checkout:*)", "Bash(git reset:*)",
    "Bash(curl:*)", "Bash(wget:*)",
]


class MaxTurnsReached(Exception):
    """The agent used up agent.max_turns for one message before finishing."""


MAX_TURNS_FOLLOWUP = (
    "the agent ran out of turns before finishing\n\nYou ran out of turns before finishing. Do not start over and do "
    "not re-read files you already read. Check what is still missing against the plan, make only the remaining "
    "changes now (use Write to rewrite a whole file if an Edit keeps failing), then give your final summary."
)


def _truncate(text: str, limit: int = 300) -> str:
    text = str(text).strip()
    return text if len(text) <= limit else text[:limit] + "... [truncated]"


@contextmanager
def _backend_env():
    """Yields (model, env) for the configured LLM backend."""
    cfg = settings()["agent"]
    backend = cfg.get("backend", "anthropic")
    model = cfg.get("model") or None
    if backend == "anthropic":
        if not os.environ.get("ANTHROPIC_API_KEY"):
            raise SystemExit("Missing 'ANTHROPIC_API_KEY' secret (agent.backend = anthropic).")
        # The CLI itself needs this key, so it is passed to it explicitly (all other secrets are hidden while the
        # agent runs). The azure_openai backend avoids even this: the key stays in the local proxy.
        yield model, {"ANTHROPIC_API_KEY": os.environ["ANTHROPIC_API_KEY"]}
    elif backend == "azure_openai":
        from azure_openai_proxy import DEFAULT_API_VERSION, start_proxy, stop_proxy
        for name in ("AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_DEPLOYMENT"):
            if not os.environ.get(name):
                raise SystemExit(f"Missing '{name}' (agent.backend = azure_openai).")
        proxy = start_proxy(
            endpoint=os.environ["AZURE_OPENAI_ENDPOINT"], api_key=os.environ["AZURE_OPENAI_API_KEY"],
            deployment=os.environ["AZURE_OPENAI_DEPLOYMENT"],
            api_version=os.environ.get("AZURE_OPENAI_API_VERSION", DEFAULT_API_VERSION),
        )
        try:
            port = proxy[2]
            yield (model or os.environ["AZURE_OPENAI_DEPLOYMENT"]), {
                "ANTHROPIC_BASE_URL": f"http://127.0.0.1:{port}",
                "ANTHROPIC_AUTH_TOKEN": "azure-openai-proxy",
                "ANTHROPIC_API_KEY": "azure-openai-proxy",
            }
        finally:
            stop_proxy(proxy[0], proxy[1])
    else:
        raise SystemExit(f"Unknown agent.backend '{backend}' in config/dev-pipe.yaml")


def skills_for(step: str | None) -> list[str] | None:
    """Skills an agent call may load: agent.step_skills[step] (limited to the installed agent.skills), else all
    installed skills. None = no filter (SDK default)."""
    cfg = settings()["agent"]
    installed = list(cfg.get("skills") or [])
    per_step = cfg.get("step_skills") or {}
    if step and step in per_step:
        return [s for s in (per_step[step] or []) if s in installed]
    return installed or None


async def _run(prompts: list[str], system_prompt: str, edit: bool, model, env,
               check: Check | None = None, max_followups: int = 0, on_incomplete: str = "fail",
               step: str | None = None, sandbox: dict | None = None) -> str:
    cfg = settings()["agent"]
    if sandbox:
        system_prompt = system_prompt + agent_isolation.SANDBOX_NOTE
    options = ClaudeAgentOptions(
        cwd=str(work_root()),  # this repo (local mode) or the target repo checkout (external mode)
        system_prompt=system_prompt,
        allowed_tools=EDIT_TOOLS if edit else READ_ONLY_TOOLS,
        disallowed_tools=BLOCKED_TOOLS,
        permission_mode="bypassPermissions",  # headless; human gates are the GitHub Environments
        setting_sources=["project"],
        skills=skills_for(step),
        model=model,
        max_turns=int(cfg.get("max_turns", 40)),
        env=env or {},
        sandbox=sandbox,
    )
    async with ClaudeSDKClient(options=options) as client:
        return await _converse(client, prompts, check, max_followups, on_incomplete)


# Numbers about the last run_agent() call, for the step logs (dev_pipe/steplog.py).
LAST_RUN: dict = {"turns": 0, "tool_calls": 0, "followups": 0, "seconds": 0.0, "reads": 0, "edits": 0}


async def _ask(client, prompt: str) -> str:
    """Sends one message and streams the agent's work to the log. Returns its final message."""
    final_text = ""
    await client.query(prompt)
    async for message in client.receive_response():
        if isinstance(message, AssistantMessage):
            LAST_RUN["turns"] += 1
            LAST_RUN["tool_calls"] += sum(isinstance(b, ToolUseBlock) for b in message.content)
            LAST_RUN["reads"] += sum(isinstance(b, ToolUseBlock) and b.name == "Read" for b in message.content)
            LAST_RUN["edits"] += sum(isinstance(b, ToolUseBlock) and b.name in ("Edit", "Write", "MultiEdit")
                                     for b in message.content)
            for block in message.content:
                if isinstance(block, TextBlock):
                    print(f"[agent] {_truncate(block.text)}", flush=True)
                elif isinstance(block, ToolUseBlock):
                    print(f"[tool-call] {block.name} {_truncate(block.input, 200)}", flush=True)
        elif isinstance(message, UserMessage) and isinstance(message.content, list):
            for block in message.content:
                if isinstance(block, ToolResultBlock):
                    print(f"[tool-result] {_truncate(block.content, 200)}", flush=True)
        elif isinstance(message, ResultMessage):
            if message.is_error and message.subtype == "error_max_turns":
                print(f"[agent] reached the turn limit (agent.max_turns = {settings()['agent'].get('max_turns', 40)})",
                      flush=True)
                raise MaxTurnsReached()
            if message.is_error:
                raise SystemExit(f"Agent run failed: {_truncate(message.result or message.subtype, 500)}")
            final_text = message.result or ""
    return final_text


async def _converse(client, prompts: list[str], check: Check | None, max_followups: int,
                    on_incomplete: str) -> str:
    """Runs the prompts, then -- if `check` says the work is incomplete -- asks the agent to finish, in the
    same conversation (it keeps everything it already read), up to `max_followups` times.

    Some models end their turn after announcing what they will do ("I'll read these files...") without
    calling a tool; the SDK treats that as the final answer. The follow-up catches it."""
    final_text, out_of_turns = "", False
    for prompt in prompts:
        try:
            final_text = await _ask(client, prompt)
        except MaxTurnsReached:
            out_of_turns = True
            break  # the remaining prompts would start before this one finished
    if check is None:
        if out_of_turns:
            raise SystemExit("Agent run failed: reached agent.max_turns before finishing (config/dev-pipe.yaml).")
        return final_text
    for attempt in range(1, max_followups + 2):
        # Out of turns: ask it to finish first. Otherwise run the step's check in a thread: it may run a full
        # build (minutes) and must not block the SDK's event loop.
        followup = MAX_TURNS_FOLLOWUP if out_of_turns else await asyncio.to_thread(check, final_text)
        if not followup:
            return final_text
        reason = followup.splitlines()[0]
        if attempt > max_followups:
            message = (f"The agent stopped {attempt} time(s) without finishing ({reason}). Re-run the step; "
                       "if this keeps happening, consider a stronger model (AZURE_OPENAI_DEPLOYMENT).")
            if on_incomplete == "warn":
                print(f"[agent] WARNING: {message}", flush=True)
                return final_text
            raise SystemExit(message)
        print(f"[agent] incomplete output ({reason}); asking it to continue ({attempt}/{max_followups})",
              flush=True)
        LAST_RUN["followups"] += 1
        try:
            final_text, out_of_turns = await _ask(client, followup), False
        except MaxTurnsReached:
            out_of_turns = True
    return final_text


def run_agent(prompts: str | list[str], system_prompt: str, edit: bool, check: Check | None = None,
              max_followups: int = MAX_FOLLOWUPS, on_incomplete: str = "fail", step: str | None = None) -> str:
    """Runs the prompts in one conversation and returns the agent's final message.

    step: name used to pick the skills this call may load (agent.step_skills in config/dev-pipe.yaml).

    check(final_text) -> None when the work is complete, else the follow-up message to send (its first line
    is the reason, used in the log). After `max_followups` follow-ups the step fails (on_incomplete="fail")
    or carries on with a warning (on_incomplete="warn")."""
    if isinstance(prompts, str):
        prompts = [prompts]
    LAST_RUN.update(turns=0, tool_calls=0, followups=0, seconds=0.0, reads=0, edits=0)
    started = time.time()
    try:
        with _backend_env() as (model, env):
            agent_isolation.harden_process()
            sandbox = agent_isolation.sandbox_options(settings()["agent"], edit)
            if sandbox:
                # Install first (outside the sandbox, with registry tokens), then the agent runs without network.
                from dev_pipe.build import install_for_agent
                install_for_agent()
            with agent_isolation.hidden_secrets():
                return asyncio.run(_run(prompts, system_prompt, edit, model, env, check, max_followups,
                                        on_incomplete, step, sandbox))
    finally:
        LAST_RUN["seconds"] = round(time.time() - started, 1)
        from dev_pipe.steplog import AI_TOTALS
        AI_TOTALS["sessions"] += 1
        AI_TOTALS["seconds"] += LAST_RUN["seconds"]


def agent_brief() -> str:
    """'in 2m 05s (14 steps, 11 files read, 2 edits)' for the plain-English step logs."""
    from dev_pipe.steplog import fmt_duration
    parts = [f"{LAST_RUN['turns']} steps", f"{LAST_RUN['reads']} files read"]
    if LAST_RUN["edits"]:
        parts.append(f"{LAST_RUN['edits']} edits")
    if LAST_RUN["followups"]:
        parts.append(f"{LAST_RUN['followups']} follow-up(s)")
    return f"in {fmt_duration(LAST_RUN['seconds'])} ({', '.join(parts)})"


def agent_stats() -> str:
    """'14 turns, 23 tool calls, 2m 05s' for the step logs."""
    from dev_pipe.steplog import fmt_duration
    extra = f", {LAST_RUN['followups']} follow-up(s)" if LAST_RUN["followups"] else ""
    return (f"{LAST_RUN['turns']} turns, {LAST_RUN['tool_calls']} tool calls, "
            f"{fmt_duration(LAST_RUN['seconds'])}{extra}")


# ---------------------------------------------------------------- completion checks used by the steps
_JSON_BLOCK = re.compile(r"```json\s*(\{.*?\})\s*```", re.S)


def json_blocks(text: str) -> list[str]:
    """The ```json {...} ``` blocks in the agent's answer (plan metadata), in order."""
    return _JSON_BLOCK.findall(text or "")


def plan_followup(text: str) -> str | None:
    """Steps 1-2: the plan must end with a valid ```json block that lists the files."""
    blocks = json_blocks(text)
    if not blocks:
        reason = "no ```json metadata block in the plan"
    else:
        try:
            meta = json.loads(blocks[-1])
        except ValueError as exc:
            meta, reason = None, f"the ```json block is not valid JSON ({exc.msg})"
        else:
            reason = "" if isinstance(meta.get("files"), list) and meta["files"] else \
                "the ```json block has no `files` list"
        if not reason:
            return None
    return (f"{reason}\n\nYou stopped before finishing. Do not describe what you will do: use your tools now to "
            "read what you still need, then reply with the COMPLETE development plan (all the required headings) "
            "ending with exactly one ```json block in the required format, including the `files` list.")


def changes_followup(changed: Callable[[], list[str]], what: str = "implementation") -> Check:
    """Step 3: the agent must have changed at least one file."""
    def check(_text: str) -> str | None:
        if changed():
            return None
        return (f"no files were changed\n\nNo files have been changed yet. Do not describe what you will do: "
                f"carry out the {what} now with Edit/Write, run the build check, then give your final summary.")
    return check


_ASKS_PERMISSION = re.compile(
    r"\b(let me know if|would you like( me)? to|should I\b|shall I\b|do you want me to|want me to|"
    r"please confirm|if you(?:'d| would) like me to|awaiting (your )?(confirmation|approval)|"
    r"before I proceed|let me know how you(?:'d| would) like)", re.I)


def question_followup(text: str) -> str | None:
    """The agent ended by asking for permission or a decision. Nobody can answer in an unattended run."""
    if not _ASKS_PERMISSION.search(text or ""):
        return None
    return ("the agent asked a question instead of finishing\n\nNobody can answer questions in this automated run. "
            "Decide yourself, following the approved plan, and finish the work now with your tools. "
            "If the work is already complete, reply with your final summary only, without questions.")


def first_of(*checks: Check) -> Check:
    """Combines checks: the first one that finds a problem decides the follow-up."""
    def check(text: str) -> str | None:
        for c in checks:
            followup = c(text)
            if followup:
                return followup
        return None
    return check


def tests_followup(changed: Callable[[], list[str]]) -> Check:
    """Step 4: the agent must have added or changed test files."""
    def check(_text: str) -> str | None:
        if any(is_test_path(p) for p in changed()):
            return None
        return ("no test files were added or changed\n\nNo test files have been written yet. Do not describe "
                "what you will do: write the unit tests now with Edit/Write, run them, then give your final summary. "
                "If the project has no test setup and you cannot add one within the plan, say so explicitly.")
    return check


def extract_json_block(text: str) -> dict:
    """Last ```json ... ``` block in the agent's answer (plan metadata)."""
    blocks = json_blocks(text)
    if not blocks:
        raise SystemExit("The agent's plan did not include the required ```json``` metadata block.")
    return json.loads(blocks[-1])


def strip_json_block(text: str) -> str:
    return _JSON_BLOCK.sub("", text).strip()
