"""Keeps the pipeline's secrets and the network away from the AI agent.

The AI runs as a child process of the pipeline step and has a shell (Bash). A child process gets a copy of its
parent's environment, so every secret the workflow gave the step (ADO_PAT, SONAR_TOKEN, GH_PAT, AI keys, ...)
was readable with one `printenv`. Three layers close that:

1. hidden_secrets(): every secret-looking variable is REMOVED from the environment while the AI runs and put
   back afterwards, for the pipeline's own commands (ADO, Sonar, git push). The AI process starts without them.
2. harden_process(): the pipeline's own process is marked "not dumpable" (Linux), so another process of the
   same user (the AI, its shell) can no longer read /proc/<pipeline pid>/environ or its memory, where the
   original values still sit. The workflow runs the step with `exec python ...`, so no parent shell process
   holding the secrets remains either.
3. sandbox_options(): the AI's shell commands run in Claude Code's sandbox (bubblewrap on Linux) with NO
   network ("install first, then no network": the pipeline installs dependencies before the AI starts).
   The AI's own API traffic goes through the CLI, not through its shell; WebFetch/WebSearch are blocked.
"""
from __future__ import annotations

import os
import platform
import re
import shutil
import subprocess
from contextlib import contextmanager

# Same rule as the build commands' secret filter (dev_pipe/build.py), plus GitHub's own job tokens.
SECRET_NAME = re.compile(r"(TOKEN|_KEY|_PAT|SECRET|PASSWORD)$|^(ADO_PAT|GH_PAT|ANTHROPIC_|AZURE_OPENAI_API)", re.I)
ALWAYS_HIDE = {"GITHUB_TOKEN", "TARGET_GITHUB_TOKEN", "LOCAL_GIT_TOKEN", "ACTIONS_RUNTIME_TOKEN",
               "ACTIONS_ID_TOKEN_REQUEST_TOKEN", "ACTIONS_ID_TOKEN_REQUEST_URL"}

_HELD: dict[str, str] = {}   # values removed while the AI runs (read by the pipeline's own commands, never the AI)


def is_secret_name(name: str) -> bool:
    return name in ALWAYS_HIDE or bool(SECRET_NAME.search(name))


def held(name: str) -> str:
    """A secret's value while it is hidden from the AI (for the pipeline's own build checks)."""
    return _HELD.get(name, "")


@contextmanager
def hidden_secrets():
    """Removes every secret-looking variable from os.environ for the duration (the AI run), then restores it."""
    removed = {k: v for k, v in os.environ.items() if is_secret_name(k)}
    for k in removed:
        os.environ.pop(k, None)
    _HELD.update(removed)
    if removed:
        print(f"[isolation] {len(removed)} secret(s) removed from the environment while the AI runs "
              f"({', '.join(sorted(removed))})", flush=True)
    try:
        yield removed
    finally:
        for k in removed:
            _HELD.pop(k, None)
        os.environ.update(removed)


_HARDENED = False


def harden_process() -> bool:
    """Marks this process non-dumpable (Linux prctl PR_SET_DUMPABLE=0): /proc/<pid>/environ and memory become
    unreadable to other processes of the same user. Returns True if applied. Safe to call more than once."""
    global _HARDENED
    if _HARDENED:
        return True
    if platform.system() != "Linux":
        return False
    try:
        import ctypes
        libc = ctypes.CDLL(None, use_errno=True)
        pr_set_dumpable = 4
        if libc.prctl(pr_set_dumpable, 0, 0, 0, 0) != 0:
            return False
    except (OSError, AttributeError):
        return False
    _HARDENED = True
    return True


# ---------------------------------------------------------------- sandbox (no network for the AI's shell)
SANDBOX_MODES = ("required", "best_effort", "off")


def sandbox_mode(cfg: dict) -> str:
    """agent.sandbox in config/dev-pipe.yaml: required (default) | best_effort | off."""
    mode = str(cfg.get("sandbox", "required")).strip().lower()
    return mode if mode in SANDBOX_MODES else "required"


def sandbox_available() -> tuple[bool, str]:
    """Linux + bubblewrap + socat installed, and bubblewrap can create a network-less sandbox here."""
    if platform.system() != "Linux":
        return False, f"sandboxing needs Linux (this is {platform.system()})"
    missing = [t for t in ("bwrap", "socat") if not shutil.which(t)]
    if missing:
        return False, f"missing {', '.join(missing)} (apt-get install bubblewrap socat)"
    try:
        probe = subprocess.run(["bwrap", "--ro-bind", "/", "/", "--dev", "/dev", "--proc", "/proc",
                                "--unshare-net", "--unshare-pid", "true"], capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired) as err:
        return False, f"bubblewrap could not start ({err})"
    if probe.returncode != 0:
        return False, ("bubblewrap is blocked on this machine (" + (probe.stderr.strip()[:160] or f"exit {probe.returncode}")
                       + "). On Ubuntu 24.04: sudo sysctl -w kernel.apparmor_restrict_unprivileged_userns=0")
    return True, "available"


def sandbox_options(cfg: dict, edit: bool) -> dict | None:
    """SandboxSettings for the agent, or None (no sandbox). Read-only agents have no shell, so no sandbox.
    required + unavailable = the step stops with a clear message (never silently runs without it)."""
    mode = sandbox_mode(cfg)
    if not edit or mode == "off":
        return None
    ok, why = sandbox_available()
    if not ok:
        if mode == "required":
            raise SystemExit(f"The AI's shell sandbox (no network) is required but not available: {why}. "
                             "Fix the runner, or set agent.sandbox: best_effort / off in config/dev-pipe.yaml "
                             "(only with a security sign-off).")
        print(f"[isolation] WARNING: AI shell sandbox not available ({why}); running WITHOUT network isolation "
              "(agent.sandbox: best_effort)", flush=True)
        return None
    return {
        "enabled": True,
        "autoAllowBashIfSandboxed": True,
        "allowUnsandboxedCommands": False,          # the AI cannot opt a command out of the sandbox
        "network": {"allowedDomains": []},           # no network at all for shell commands
    }


SANDBOX_NOTE = (
    "\n\nEnvironment: your shell commands run in a sandbox WITHOUT network access. The project's dependencies "
    "are already installed. Do not run install commands (npm install/ci, pip install, mvn without -o, "
    "dotnet restore, go get ...); run only build and test commands, offline (`mvn -o`, `gradle --offline`). "
    "If something truly needs a new package, say so in your final message instead of installing it.")
