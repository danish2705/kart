"""Hands the test run's coverage files from one job to the next, so the next job does not run the same tests
again on the same code just to recreate them.

    Step 4 (Build + Test + Coverage) --save--> Step 5 (Sonar Pre-check): first scan uses Step 4's files
    Step 5 --save--> Step 6 (passes out/ through) --> Step 7 (Quality gate): first PR scan uses Step 5's files

The files travel inside out/ (the stage artifact) with a manifest holding a FINGERPRINT of the code they were
made from: the starting commit + the exact change set (changes.patch). A job only reuses them when its code has
the same fingerprint; otherwise (or after any AI fix in that job) it runs the tests as before.

Not reused when the repo has Java/Kotlin code: Sonar needs the compiled classes, so that build runs anyway.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
from pathlib import Path

from dev_pipe.config import OUT

FILES_DIR = "coverage-files"            # out/coverage-files/<path relative to the repo root>
MANIFEST = "coverage-files.json"


def code_fingerprint(base: str, patch: bytes) -> str:
    """Identifies the code: starting commit + change set."""
    return hashlib.sha256(base.encode() + b"\0" + (patch or b"")).hexdigest()


def has_java(scan_dir: Path) -> bool:
    from dev_pipe.sonar_precheck import java_args
    return bool(java_args(Path(scan_dir)))


def save(scan_dir: Path, root: Path, fingerprint: str, newer_than: float | None, out: Path | None = None) -> int:
    """Copies the coverage reports written after newer_than (under scan_dir) into out/coverage-files/.
    Returns the number of files saved (0 = nothing to hand over; the manifest is then removed)."""
    from dev_pipe.sonar_precheck import coverage_reports
    out = out or OUT
    dest = out / FILES_DIR
    shutil.rmtree(dest, ignore_errors=True)
    (out / MANIFEST).unlink(missing_ok=True)
    lcov, py, jacoco = coverage_reports(Path(scan_dir), newer_than)
    root = Path(root).resolve()
    rels: list[str] = []
    out_resolved = out.resolve()
    for f in [*lcov, *py, *jacoco]:
        if out_resolved in Path(f).resolve().parents:
            continue   # our own hand-over copies, never a test run's report
        try:
            rel = Path(f).resolve().relative_to(root).as_posix()
        except ValueError:
            continue
        target = dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(f, target)
        rels.append(rel)
    if rels:
        out.mkdir(parents=True, exist_ok=True)
        (out / MANIFEST).write_text(json.dumps({"fingerprint": fingerprint, "files": rels, "saved_at": time.time()},
                                               indent=2), encoding="utf-8")
    print(f"[coverage] handed over {len(rels)} coverage file(s) to the next step", flush=True)
    return len(rels)


def restore(root: Path, fingerprint: str, out: Path | None = None) -> list[str]:
    """Puts the saved coverage files back under root if they were made from the same code. Their timestamps are
    set to now, so the Sonar step treats them as this run's reports. Returns the restored paths ([] = not
    reusable: run the tests as before)."""
    out = out or OUT
    manifest_path = out / MANIFEST
    if not manifest_path.exists():
        print("[coverage] no coverage files from the previous step: tests run as usual", flush=True)
        return []
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("fingerprint") != fingerprint:
        print("[coverage] the previous step's coverage files are for different code: tests run as usual", flush=True)
        return []
    src_root = out / FILES_DIR
    rels = [r for r in manifest.get("files") or [] if (src_root / r).is_file()]
    if not rels or len(rels) != len(manifest.get("files") or []):
        print("[coverage] the previous step's coverage files are incomplete: tests run as usual", flush=True)
        return []
    now = time.time()
    root = Path(root)
    for rel in rels:
        target = root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_root / rel, target)
        os.utime(target, (now, now))
    print(f"[coverage] reused {len(rels)} coverage file(s) from the previous step (same code): "
          + ", ".join(rels[:5]), flush=True)
    return rels
