"""Security: secrets hidden from the AI, pipeline process unreadable, no network for the AI's shell (install
first), no stored git token in AI jobs, and the leak check before anything is pushed. No network."""
from __future__ import annotations

import base64
import os
import pathlib
import platform
import subprocess
import sys
import textwrap

import pytest
import yaml

from dev_pipe import agent_isolation as iso
from dev_pipe import agent_runner, build, gitops, leak_check
from dev_pipe.stack import Command, Project


# ---------- 1. secrets out of the AI's environment
def test_secret_names():
    for name in ("ADO_PAT", "GH_PAT", "SONAR_TOKEN", "AZURE_OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GITHUB_TOKEN",
                 "TARGET_GITHUB_TOKEN", "LOCAL_GIT_TOKEN", "ACTIONS_ID_TOKEN_REQUEST_TOKEN", "NPM_TOKEN"):
        assert iso.is_secret_name(name), name
    for name in ("PATH", "HOME", "ADO_ORG_URL", "SONAR_HOST_URL", "AZURE_OPENAI_ENDPOINT", "WORK_ITEM_ID"):
        assert not iso.is_secret_name(name), name


def test_hidden_while_inside_and_restored_after(monkeypatch):
    monkeypatch.setenv("ADO_PAT", "ado-secret-value-123")
    monkeypatch.setenv("NPM_TOKEN", "npm-secret-value-123")
    with iso.hidden_secrets():
        assert "ADO_PAT" not in os.environ and "NPM_TOKEN" not in os.environ
        assert iso.held("NPM_TOKEN") == "npm-secret-value-123"
        # a child process (like the AI and its shell) does not get them
        out = subprocess.run([sys.executable, "-c", "import os; print(os.environ.get('ADO_PAT', 'none'))"],
                             capture_output=True, text=True).stdout.strip()
        assert out == "none"
        # the pipeline's own build checks still get the private-registry token
        assert build._build_env().get("NPM_TOKEN") == "npm-secret-value-123"
        assert "ADO_PAT" not in build._build_env()
    assert os.environ["ADO_PAT"] == "ado-secret-value-123" and iso.held("NPM_TOKEN") == ""


def test_run_agent_starts_the_ai_without_secrets(monkeypatch):
    from contextlib import contextmanager
    monkeypatch.setenv("ADO_PAT", "ado-secret-value-123")
    monkeypatch.setenv("SONAR_TOKEN", "sonar-secret-value-123")
    seen = {}

    @contextmanager
    def backend():
        yield "model", {}
    monkeypatch.setattr(agent_runner, "_backend_env", backend)
    monkeypatch.setattr(iso, "harden_process", lambda: True)
    monkeypatch.setattr(iso, "sandbox_options", lambda cfg, edit: {"enabled": True})
    monkeypatch.setattr(build, "install_for_agent", lambda: seen.setdefault("installed", True))

    async def fake_run(prompts, system_prompt, edit, model, env, check, max_followups, on_incomplete, step, sandbox):
        seen.update(ado=os.environ.get("ADO_PAT"), sonar=os.environ.get("SONAR_TOKEN"), sandbox=sandbox)
        return "done"
    monkeypatch.setattr(agent_runner, "_run", fake_run)
    assert agent_runner.run_agent("p", "s", edit=True) == "done"
    assert seen == {"installed": True, "ado": None, "sonar": None, "sandbox": {"enabled": True}}
    assert os.environ["ADO_PAT"] == "ado-secret-value-123"   # back for the pipeline's own ADO/Sonar calls


def test_proc_is_blocked_for_the_ai_tools():
    assert "Read(//proc/**)" in agent_runner.BLOCKED_TOOLS


@pytest.mark.skipif(platform.system() != "Linux", reason="prctl is Linux only")
def test_hardened_process_environment_is_unreadable_to_children(tmp_path):
    """A non-dumpable pipeline process: its child (the AI) cannot read /proc/<pipeline pid>/environ."""
    script = textwrap.dedent("""
        import os, subprocess, sys
        from dev_pipe import agent_isolation as iso
        os.environ["ADO_PAT"] = "x"
        print("hardened", iso.harden_process())
        child = "import sys; open('/proc/%d/environ' % int(sys.argv[1]), 'rb').read(); print('READABLE')"
        r = subprocess.run([sys.executable, "-c", child, str(os.getpid())], capture_output=True, text=True)
        print("child:", r.stdout.strip() or ("blocked" if "Permission" in r.stderr else r.stderr.strip()[-80:]))
    """)
    out = subprocess.run([sys.executable, "-c", script], capture_output=True, text=True,
                         cwd=pathlib.Path(__file__).resolve().parent.parent).stdout
    assert "hardened True" in out and "child: blocked" in out, out


# ---------- 2. no network for the AI's shell
def test_sandbox_settings(monkeypatch):
    monkeypatch.setattr(iso, "sandbox_available", lambda: (True, "available"))
    opts = iso.sandbox_options({"sandbox": "required"}, edit=True)
    assert opts["enabled"] and opts["allowUnsandboxedCommands"] is False and opts["network"]["allowedDomains"] == []
    assert iso.sandbox_options({"sandbox": "required"}, edit=False) is None     # read-only agent: no shell
    assert iso.sandbox_options({"sandbox": "off"}, edit=True) is None


def test_required_sandbox_never_silently_skipped(monkeypatch):
    monkeypatch.setattr(iso, "sandbox_available", lambda: (False, "missing bwrap"))
    with pytest.raises(SystemExit, match="required but not available"):
        iso.sandbox_options({"sandbox": "required"}, edit=True)
    assert iso.sandbox_options({"sandbox": "best_effort"}, edit=True) is None


def test_install_first_and_offline_commands_for_the_ai():
    node = Project(pathlib.Path("/x"), "node", [Command("npm ci", install=True), Command("npm run build"),
                                                Command("npm run test")])
    assert [c.cmd for c in node.agent_commands()] == ["npm run build", "npm run test"]
    assert [c.cmd for c in node.install_commands()] == ["npm ci"]
    from dev_pipe.stack import _maven_project
    mvn = _maven_project(pathlib.Path("/repo"))
    assert [c.cmd for c in mvn.agent_commands()] == ["mvn -o -B -q verify"]
    assert "dependency:go-offline" in mvn.install_commands()[0].cmd


def test_install_for_agent_runs_install_commands_once(monkeypatch, tmp_path):
    unit = build.BuildUnit("app (node)", tmp_path, [], [], [Command("npm ci", install=True)])
    runs = []
    monkeypatch.setattr(build, "_INSTALLED", False)
    monkeypatch.setattr(build, "plan_build", lambda t, a, changed=None: build.BuildPlan([unit]))
    monkeypatch.setattr(build, "_run_commands", lambda cwd, cmds: runs.append([c.cmd for c in cmds]) or (True, ""))
    monkeypatch.setattr("dev_pipe.config.target_settings", lambda: {"app_dir": "app"})
    monkeypatch.setattr("dev_pipe.config.app_dir", lambda: tmp_path)
    build.install_for_agent()
    build.install_for_agent()
    assert runs == [["npm ci"]]


# ---------- 3. no stored git token in AI jobs; Step 7 passes it per command
def test_local_mode_remote_commands_get_a_per_command_token(monkeypatch):
    from dev_pipe import workspace
    monkeypatch.setattr(gitops, "is_external", lambda: False)
    monkeypatch.setattr(workspace, "_local_token", None)
    monkeypatch.setenv("LOCAL_GIT_TOKEN", "local-token-123")
    env = gitops._env(("push", "origin", "b"))
    assert "LOCAL_GIT_TOKEN" not in os.environ   # taken out of the environment on first use
    expected = base64.b64encode(b"x-access-token:local-token-123").decode()
    assert env["GIT_CONFIG_VALUE_0"].endswith(expected)
    assert gitops._env(("status",)) is None


def test_workflow_ai_jobs_have_no_stored_token_and_use_exec():
    wf = yaml.safe_load(pathlib.Path(".github/workflows/dev-pipe.yml").read_text())["jobs"]
    for job in ("plan", "implement", "test-gates", "sonar-precheck", "quality-gate"):
        steps = wf[job]["steps"]
        checkout = next(s for s in steps if s.get("uses") == "actions/checkout@v4")
        assert checkout["with"]["persist-credentials"] is False, job
        assert any(str(s.get("run", "")).startswith("exec python -m dev_pipe.steps.") for s in steps), job
    step7 = next(s for s in wf["quality-gate"]["steps"] if "s8_sonarqube" in str(s.get("run", "")))
    assert "LOCAL_GIT_TOKEN" in step7["env"]


# ---------- 4. leak check before anything leaves the runner
GH = "ghp_" + "A" * 36


def patch_with(added: str, removed: str = "old line") -> str:
    return ("diff --git a/app/x.py b/app/x.py\n--- a/app/x.py\n+++ b/app/x.py\n@@ -10,2 +10,3 @@\n"
            f" context\n-{removed}\n+{added}\n+print('ok')\n")


def test_finds_token_on_added_line_with_line_number():
    found = leak_check.scan_patch(patch_with(f"TOKEN = '{GH}'"), known={})
    assert [str(f) for f in found] == ["app/x.py, line 11: GitHub token"]


def test_removed_lines_and_normal_code_are_not_flagged():
    assert leak_check.scan_patch(patch_with("x = compute_task_status(order)", removed=f"T='{GH}'"), known={}) == []


def test_finds_known_secret_values_even_base64(monkeypatch):
    monkeypatch.setenv("ADO_PAT", "abcdefghijklmnopqrstuvwxyz012345")
    b64 = base64.b64encode(b"abcdefghijklmnopqrstuvwxyz012345").decode()
    kinds = [f.kind for f in leak_check.scan_text(f"note: {b64}", "notes")]
    assert kinds == ["the value of ADO_PAT (base64)"]


def test_enforce_blocks_or_warns(monkeypatch, capsys):
    findings = [leak_check.Finding("app/x.py, line 3", "GitHub token")]
    monkeypatch.setattr(leak_check, "mode", lambda: "block")
    with pytest.raises(SystemExit, match="Nothing was pushed"):
        leak_check.enforce(findings, "the change")
    monkeypatch.setattr(leak_check, "mode", lambda: "warn")
    leak_check.enforce(findings, "the change")
    assert "WARNING" in capsys.readouterr().out
    leak_check.enforce([], "the change")   # nothing found: nothing happens


def test_prompt_treats_story_and_repo_as_data():
    system = pathlib.Path("prompts/dev/system.md").read_text()
    assert "DATA" in system and "Suspicious content" in system
