"""Unit tests for the Dev Agent's three hard gates. These run without a
live `claude` CLI, Sonar server, or qTest -- exactly the parts of the
Dev Agent testable in a plain Python dev environment (no Node.js
available here; see README "What's been verified vs. not").
"""
import sys
import textwrap
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from dev_agent.checks.coverage_gate import parse_coverage_xml, run_coverage_gate
from dev_agent.checks.sonar_precheck import SonarIssue, evaluate_issues
from dev_agent.checks.test_quality_review import gate_passed, review_test_file, review_test_files

SAMPLE_APP = ROOT / "sample_app"


# ---- coverage gate ----------------------------------------------------------

def test_coverage_gate_passes_on_sample_app_full_suite():
    result = run_coverage_gate(SAMPLE_APP, package="app")
    assert result.passed, result.summary()
    assert result.coverage_pct >= 95.0


def test_coverage_gate_fails_when_a_test_is_skipped(tmp_path):
    # Copy sample_app's app/ package but omit most of the test suite, so
    # coverage genuinely drops below the 95% threshold.
    import shutil
    project = tmp_path / "proj"
    shutil.copytree(SAMPLE_APP / "app", project / "app")
    (project / "tests").mkdir()
    (project / "tests" / "__init__.py").write_text("")
    (project / "tests" / "test_main.py").write_text(textwrap.dedent("""
        from fastapi.testclient import TestClient
        from app.main import app

        def test_health():
            resp = TestClient(app).get("/health")
            assert resp.status_code == 200
    """))
    result = run_coverage_gate(project, package="app")
    assert not result.passed
    assert result.coverage_pct < 95.0


def test_parse_coverage_xml_reports_missing_lines(tmp_path):
    xml = tmp_path / "coverage.xml"
    xml.write_text(textwrap.dedent("""\
        <?xml version="1.0" ?>
        <coverage line-rate="0.5">
          <packages>
            <package>
              <classes>
                <class filename="app/main.py" line-rate="0.5">
                  <lines>
                    <line number="1" hits="1"/>
                    <line number="2" hits="0"/>
                  </lines>
                </class>
              </classes>
            </package>
          </packages>
        </coverage>
    """))
    result = parse_coverage_xml(xml)
    assert result.coverage_pct == 50.0
    assert result.files[0].missing_lines == [2]


# ---- test quality gate --------------------------------------------------------

def test_review_flags_assertion_free_test(tmp_path):
    f = tmp_path / "test_bad.py"
    f.write_text(textwrap.dedent("""
        def test_does_something():
            x = 1 + 1
    """))
    findings = review_test_file(f)
    assert len(findings) == 1
    assert "no assertion" in findings[0].reason


def test_review_flags_vacuous_assert(tmp_path):
    f = tmp_path / "test_bad.py"
    f.write_text(textwrap.dedent("""
        def test_does_something():
            assert True
    """))
    findings = review_test_file(f)
    assert len(findings) == 1
    assert "vacuous" in findings[0].reason


def test_review_accepts_real_assertion(tmp_path):
    f = tmp_path / "test_good.py"
    f.write_text(textwrap.dedent("""
        def test_addition():
            assert 1 + 1 == 2
    """))
    assert review_test_file(f) == []


def test_review_accepts_pytest_raises_with_no_bare_assert(tmp_path):
    f = tmp_path / "test_good.py"
    f.write_text(textwrap.dedent("""
        import pytest

        def test_raises_on_bad_input():
            with pytest.raises(ValueError):
                int("not a number")
    """))
    assert review_test_file(f) == []


def test_review_test_files_and_gate_passed_on_real_sample_app_suite():
    test_files = list((SAMPLE_APP / "tests").glob("test_*.py"))
    assert test_files, "expected sample_app to have test files"
    findings = review_test_files(test_files)
    assert gate_passed(findings), findings


# ---- sonar gate ----------------------------------------------------------------

def test_evaluate_issues_passes_with_no_issues():
    result = evaluate_issues([])
    assert result.passed
    assert result.blocking_issues == []


def test_evaluate_issues_fails_on_critical_severity():
    result = evaluate_issues([
        {"key": "k1", "rule": "python:S1128", "severity": "CRITICAL",
         "message": "Remove this unused import", "component": "app/storage.py", "line": 3},
    ])
    assert not result.passed
    assert len(result.blocking_issues) == 1
    assert isinstance(result.blocking_issues[0], SonarIssue)
    assert "unused import" in result.summary()


def test_evaluate_issues_ignores_minor_and_info_severity():
    result = evaluate_issues([
        {"key": "k1", "rule": "r1", "severity": "MINOR", "message": "nit", "component": "app/main.py"},
        {"key": "k2", "rule": "r2", "severity": "INFO", "message": "fyi", "component": "app/main.py"},
    ])
    assert result.passed
    assert len(result.info_issues) == 2


def test_scanner_env_drops_pipeline_ci_variables(monkeypatch):
    """The scanner must not see the pipeline run's GitHub Actions context (it is not the PR's)."""
    from dev_pipe import sonar
    monkeypatch.setenv("GITHUB_ACTIONS", "true")
    monkeypatch.setenv("GITHUB_SHA", "abc")
    monkeypatch.setenv("ACTIONS_RUNTIME_URL", "x")
    monkeypatch.setenv("CI", "true")
    monkeypatch.setenv("JAVA_HOME", "/opt/java")
    env = sonar.scanner_env()
    assert not any(k in env for k in ("GITHUB_ACTIONS", "GITHUB_SHA", "ACTIONS_RUNTIME_URL", "CI"))
    assert env["JAVA_HOME"] == "/opt/java" and "PATH" in env


def test_fetch_pr_measures_reads_period_values(monkeypatch):
    from dev_pipe import sonar

    class Resp:
        def raise_for_status(self):
            pass

        def json(self):
            return {"component": {"measures": [
                {"metric": "new_lines", "periods": [{"index": 1, "value": "249"}]},
                {"metric": "ncloc", "value": "1191"}]}}
    monkeypatch.setattr(sonar.requests, "get", lambda *a, **k: Resp())
    assert sonar.fetch_pr_measures("https://h", "t", "k", 4) == {"new_lines": "249", "ncloc": "1191"}
