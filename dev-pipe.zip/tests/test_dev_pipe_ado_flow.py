"""ADO writes: story Active in Step 3, tasks created (or reused) in Step 6, failure comment on the story.
No network: ADO is faked."""
from __future__ import annotations

import pathlib

import yaml

from dev_pipe import ado as ado_mod
from dev_pipe.steps import notify_failure as nf
from dev_pipe.steps import s4_autonomous_development as s3
from dev_pipe.steps import s7_pull_request_creation as s6

STORY = {"id": 101, "title": "Add /concat", "state": "New", "url": "https://ado/wi/101",
         "assigned_to": "", "area_path": "P", "iteration_path": "P\\S1"}


# ---------- reuse rules
def test_pick_existing_task_reuses_only_open_tasks_with_same_title():
    tasks = [{"id": 1, "title": "DEV - Add /concat", "state": "Closed"},
             {"id": 2, "title": "dev - add /concat ", "state": "Active"},
             {"id": 3, "title": "PR - Add /concat", "state": "Removed"}]
    closed = {"Closed", "Removed"}
    assert ado_mod.pick_existing_task(tasks, "DEV - Add /concat", closed)["id"] == 2
    assert ado_mod.pick_existing_task(tasks, "PR - Add /concat", closed) is None


def test_child_tasks_reads_children_and_keeps_tasks_only():
    client = ado_mod.AdoClient.__new__(ado_mod.AdoClient)
    client.api, client.version, client.dry_run = "https://ado/_apis/wit", "7.1", True
    calls = []

    def fake_call(method, url, **kw):
        calls.append((url, kw.get("params")))
        if url.endswith("/workitems/101"):
            return {"relations": [
                {"rel": "System.LinkTypes.Hierarchy-Forward", "url": "https://ado/_apis/wit/workItems/7"},
                {"rel": "System.LinkTypes.Hierarchy-Forward", "url": "https://ado/_apis/wit/workItems/8"},
                {"rel": "Hyperlink", "url": "https://github.com/o/r/pull/1"}]}
        return {"value": [
            {"id": 7, "fields": {"System.Title": "DEV - Add /concat", "System.WorkItemType": "Task",
                                 "System.State": "Active"}},
            {"id": 8, "fields": {"System.Title": "A bug", "System.WorkItemType": "Bug", "System.State": "New"}}]}
    client._call = fake_call
    assert client.child_tasks(101) == [{"id": 7, "title": "DEV - Add /concat", "state": "Active"}]
    assert calls[1][1]["ids"] == "7,8"


# ---------- Step 3: story only
class FakeAdo:
    def __init__(self, existing=()):
        self.existing = list(existing)
        self.states, self.created = [], []
        self.next_id = 500

    def set_state(self, wid, state, extra=None):
        self.states.append((wid, state))

    def child_tasks(self, wid):
        return self.existing

    def find_or_create_task(self, story, title, existing):
        found = ado_mod.pick_existing_task(existing, title, {"Closed", "Removed"})
        if found:
            return found, False
        self.next_id += 1
        self.created.append(title)
        return {"id": self.next_id}, True


def test_step3_moves_story_to_active_and_creates_no_tasks(monkeypatch):
    fake = FakeAdo()
    monkeypatch.setattr(s3, "AdoClient", lambda: fake)
    assert s3.update_ado_on_start(dict(STORY)) is True
    assert fake.states == [(101, "Active")] and fake.created == []


def test_step3_leaves_an_already_active_story_alone(monkeypatch):
    fake = FakeAdo()
    monkeypatch.setattr(s3, "AdoClient", lambda: fake)
    assert s3.update_ado_on_start({**STORY, "state": "active"}) is False
    assert fake.states == []


# ---------- Step 6: tasks after the PR
def test_step6_creates_both_tasks_and_starts_dev_task():
    fake = FakeAdo()
    ids = s6.ensure_tasks(dict(STORY), ado=fake)
    assert fake.created == ["DEV - Add /concat", "PR - Add /concat"]
    assert ids["dev_task_id"] == 501 and ids["pr_task_id"] == 502
    assert ids["created"] == ["dev", "pr"] and ids["reused"] == []
    assert fake.states == [(501, "Active")]   # only the new DEV task


def test_step6_rerun_reuses_open_tasks_no_duplicates():
    fake = FakeAdo(existing=[{"id": 7, "title": "DEV - Add /concat", "state": "Active"},
                             {"id": 8, "title": "PR - Add /concat", "state": "New"}])
    ids = s6.ensure_tasks(dict(STORY), ado=fake)
    assert fake.created == [] and fake.states == []
    assert (ids["dev_task_id"], ids["pr_task_id"]) == (7, 8) and ids["reused"] == ["dev", "pr"]


# ---------- failure comment
def test_first_failed_step_is_reported():
    needs = {"plan": {"result": "success"}, "implement": {"result": "success"},
             "test-gates": {"result": "failure"}, "sonar-precheck": {"result": "skipped"}}
    job, label = nf.failed_step(needs)
    assert job == "test-gates" and "Step 4" in label
    text = nf.message(job, label, "https://run/1")
    assert "failed at Step 4" in text and "https://run/1" in text and "No pull request" in text


def test_failure_after_pr_says_pr_exists():
    job, label = nf.failed_step({"create-pr": {"result": "success"}, "quality-gate": {"result": "failure"}})
    assert "pull request was raised" in nf.message(job, label, "u")


def test_nothing_posted_when_no_step_after_step3_failed(monkeypatch, capsys):
    monkeypatch.setenv("NEEDS_JSON", '{"plan": {"result": "failure"}, "implement": {"result": "skipped"}}')
    nf.main()
    assert "nothing to post" in capsys.readouterr().out


def test_ado_error_never_fails_the_notify_job(monkeypatch, capsys):
    monkeypatch.setenv("NEEDS_JSON", '{"implement": {"result": "failure"}}')
    monkeypatch.setenv("WORK_ITEM_ID", "101")

    class Broken:
        def __init__(self):
            raise SystemExit("ADO down")
    monkeypatch.setattr(ado_mod, "AdoClient", Broken)
    nf.main()
    assert "could not post" in capsys.readouterr().out


def test_workflow_runs_notify_only_on_failure_after_step3():
    jobs = yaml.safe_load(pathlib.Path(".github/workflows/dev-pipe.yml").read_text())["jobs"]
    job = jobs["notify-failure"]
    assert "failure()" in job["if"] and "needs.implement.result != 'skipped'" in job["if"]
    assert {j for j, _ in nf.JOBS} <= set(job["needs"])
