"""Step 4 Sonar pre-check for every stack (dev_pipe/sonar_precheck.py). No network: scanners and the
SonarQube Cloud API are faked."""
from __future__ import annotations

import subprocess
from pathlib import Path

import pytest
import requests

from dev_pipe import config, sonar_precheck as sp
from dev_pipe.steps import s6_build_test_coverage as s6

CONN = {"host": "https://sonarcloud.io", "token": "tok-secret", "project_key": "org_repo", "organization": "org"}

DIFF = """diff --git a/web/src/app/pay.service.ts b/web/src/app/pay.service.ts
index 1111111..2222222 100644
--- a/web/src/app/pay.service.ts
+++ b/web/src/app/pay.service.ts
@@ -10,0 +11,3 @@ export class PayService {
+  refund(id: string) {
+    return this.http.post(`/refund/${id}`, {});
+  }
@@ -40 +43 @@ export class PayService {
-  old()
+  newer()
diff --git a/api/Refunds/RefundController.cs b/api/Refunds/RefundController.cs
new file mode 100644
--- /dev/null
+++ b/api/Refunds/RefundController.cs
@@ -0,0 +1,4 @@
+public class RefundController {
+  public int Get() { return 1; }
+}
+
diff --git a/web/src/legacy.ts b/web/src/legacy.ts
deleted file mode 100644
--- a/web/src/legacy.ts
+++ /dev/null
@@ -1,2 +0,0 @@
-a
-b
"""


def issue(path, line=None, severity="MAJOR", rule="ts:S1", impacts=None, key="org_repo", end=None):
    i = {"component": f"{key}:{path}", "severity": severity, "rule": rule, "message": f"msg {path}:{line}"}
    if line is not None:
        i["line"] = line
        i["textRange"] = {"startLine": line, "endLine": end or line}
    if impacts is not None:
        i["impacts"] = impacts
    return i


# ---------------------------------------------------------------- pure helpers
def test_parse_changed_lines_added_modified_new_and_deleted_files():
    changed = sp.parse_changed_lines(DIFF)
    assert changed["web/src/app/pay.service.ts"] == {11, 12, 13, 43}
    assert changed["api/Refunds/RefundController.cs"] == {1, 2, 3, 4}
    assert "web/src/legacy.ts" not in changed          # deleted: nothing to analyse


def test_match_changed_path_handles_scanner_base_dir_in_a_subfolder():
    changed = {"web/src/app/pay.service.ts": {1}, ".github/x.yml": {1}}
    assert sp.match_changed_path("web/src/app/pay.service.ts", changed) == "web/src/app/pay.service.ts"
    assert sp.match_changed_path("src/app/pay.service.ts", changed) == "web/src/app/pay.service.ts"  # scanned from web/
    assert sp.match_changed_path(".github/x.yml", changed) == ".github/x.yml"
    assert sp.match_changed_path("app/pay.service.ts.bak", changed) is None
    assert sp.match_changed_path("other/pay.service.ts", changed) is None


def test_classify_only_blocks_issues_on_changed_lines_with_blocking_severity():
    changed = sp.parse_changed_lines(DIFF)
    issues = [
        issue("web/src/app/pay.service.ts", 12, "CRITICAL"),            # changed line -> blocks
        issue("web/src/app/pay.service.ts", 30, "BLOCKER"),             # same file, untouched line -> ignored
        issue("web/src/app/pay.service.ts", 43, "MINOR"),               # changed line, low severity -> ignored
        issue("web/src/other.ts", 5, "BLOCKER"),                        # file not changed -> ignored
        issue("api/Refunds/RefundController.cs", None, "MAJOR"),        # file-level issue on a changed file -> blocks
        issue("web/src/app/pay.service.ts", 8, "MAJOR", end=11),        # range overlaps a changed line -> blocks
    ]
    blocking, ignored = sp.classify_issues(issues, changed, "changed_lines", sp.DEFAULTS["severities"],
                                           sp.DEFAULTS["impact_severities"])
    assert [(b["path"], b["line"]) for b in blocking] == [
        ("api/Refunds/RefundController.cs", None), ("web/src/app/pay.service.ts", 8),
        ("web/src/app/pay.service.ts", 12)]
    assert ignored == 3


def test_classify_changed_files_mode_blocks_old_issues_in_touched_files():
    changed = sp.parse_changed_lines(DIFF)
    blocking, _ = sp.classify_issues([issue("web/src/app/pay.service.ts", 30, "BLOCKER")], changed,
                                     "changed_files", ["BLOCKER"], [])
    assert len(blocking) == 1


def test_mqr_mode_impact_severity_counts():
    changed = {"a.py": {3}}
    mqr = issue("a.py", 3, severity="", impacts=[{"softwareQuality": "MAINTAINABILITY", "severity": "HIGH"}])
    low = issue("a.py", 3, severity="", impacts=[{"softwareQuality": "MAINTAINABILITY", "severity": "LOW"}])
    blocking, ignored = sp.classify_issues([mqr, low], changed, "changed_lines", ["BLOCKER"], ["HIGH"])
    assert len(blocking) == 1 and ignored == 1
    assert blocking[0]["severity"] == "MAINTAINABILITY:HIGH"


def test_read_task_id_and_redact(tmp_path):
    f = tmp_path / "report-task.txt"
    f.write_text("projectKey=org_repo\nceTaskId=AYx123\n", encoding="utf-8")
    assert sp.read_task_id(f) == "AYx123"
    assert sp.read_task_id(tmp_path / "missing.txt") == ""
    net = tmp_path / ".sonarqube" / "out" / ".sonar"
    net.mkdir(parents=True)
    (net / "report-task.txt").write_text("ceTaskId=NET1\n", encoding="utf-8")
    assert sp.read_task_id(tmp_path / "missing.txt", tmp_path) == "NET1"   # .NET scanner's own location
    assert sp.redact("token tok-secret here", "tok-secret") == "token *** here"


def test_safe_branch_name():
    assert sp.safe_branch("devpipe-precheck", "123", "1") == "devpipe-precheck/123-1"
    assert sp.safe_branch("devpipe-precheck", "a b/c") == "devpipe-precheck/a-b-c"


# ---------------------------------------------------------------- scan planning
def make_monorepo(root: Path) -> None:
    (root / "web").mkdir(parents=True)
    (root / "web" / "package.json").write_text('{"scripts": {"build": "ng build"}}', encoding="utf-8")
    (root / "api" / "Refunds").mkdir(parents=True)
    (root / "api" / "Api.sln").write_text("", encoding="utf-8")
    (root / "api" / "Refunds" / "Refunds.csproj").write_text("<Project/>", encoding="utf-8")


def test_plan_units_cli_for_js_plus_dotnet_scanner_for_changed_dotnet_project(tmp_path):
    make_monorepo(tmp_path)
    units = sp.plan_units(tmp_path, [tmp_path / "web/src/app/pay.service.ts",
                                     tmp_path / "api/Refunds/RefundController.cs"], "devpipe-precheck/9")
    assert [(u.kind, u.cwd.name, u.branch) for u in units] == [
        ("cli", tmp_path.name, "devpipe-precheck/9"), ("dotnet", "api", "devpipe-precheck/9-net1")]
    assert units[1].build_cmd.startswith("dotnet build") and "Api.sln" in units[1].build_cmd


def test_plan_units_dotnet_only_change_needs_no_cli_scan(tmp_path):
    make_monorepo(tmp_path)
    units = sp.plan_units(tmp_path, [tmp_path / "api/Refunds/RefundController.cs"], "b")
    assert [u.kind for u in units] == ["dotnet"]


def test_plan_units_js_only_change_skips_dotnet(tmp_path):
    make_monorepo(tmp_path)
    assert [u.kind for u in sp.plan_units(tmp_path, [tmp_path / "web/a.ts"], "b")] == ["cli"]


def test_java_args_point_at_compiled_classes(tmp_path):
    (tmp_path / "src/main/java").mkdir(parents=True)
    (tmp_path / "src/main/java/A.java").write_text("class A {}", encoding="utf-8")
    assert sp.java_args(tmp_path) == ["-Dsonar.java.binaries=."]           # not built: scanner says why
    (tmp_path / "target/classes").mkdir(parents=True)
    assert sp.java_args(tmp_path) == ["-Dsonar.java.binaries=target/classes"]
    other = tmp_path / "js"
    other.mkdir()
    assert sp.java_args(other) == []


def test_coverage_args_per_language(tmp_path):
    (tmp_path / "coverage").mkdir()
    (tmp_path / "coverage/lcov.info").write_text("LF:1\nLH:1\n", encoding="utf-8")
    (tmp_path / "coverage.xml").write_text("<coverage/>", encoding="utf-8")
    (tmp_path / "target/site/jacoco").mkdir(parents=True)
    (tmp_path / "target/site/jacoco/jacoco.xml").write_text("<report/>", encoding="utf-8")
    args = sp.coverage_args(tmp_path, None)
    assert "-Dsonar.javascript.lcov.reportPaths=coverage/lcov.info" in args
    assert "-Dsonar.python.coverage.reportPaths=coverage.xml" in args
    assert "-Dsonar.coverage.jacoco.xmlReportPaths=target/site/jacoco/jacoco.xml" in args
    (tmp_path / "node_modules/x/coverage").mkdir(parents=True)          # dependencies are never scanned
    (tmp_path / "node_modules/x/coverage.xml").write_text("<coverage/>", encoding="utf-8")
    assert "-Dsonar.python.coverage.reportPaths=coverage.xml" in sp.coverage_args(tmp_path, None)


# ---------------------------------------------------------------- run_precheck end to end (faked)
class FakeApi:
    def __init__(self, issues_by_branch, status="SUCCESS"):
        self.issues_by_branch, self.status = issues_by_branch, status
        self.deleted: list[str] = []
        self.waited: list[str] = []

    def wait_for_task(self, task_id, wait_seconds, poll_seconds):
        self.waited.append(task_id)
        return self.status, "" if self.status == "SUCCESS" else "boom"

    def branch_issues(self, branch):
        return self.issues_by_branch.get(branch, [])

    def delete_branch(self, branch):
        self.deleted.append(branch)


def fake_scanner(returncode=0, task="T1", calls=None):
    def scan(unit, conn, metadata, extra):
        if calls is not None:
            calls.append((unit.kind, unit.branch, list(extra)))
        if task:
            metadata.write_text(f"ceTaskId={task}-{unit.kind}\n", encoding="utf-8")
        return subprocess.CompletedProcess(["scanner"], returncode, "INFO done", "")
    return scan


def test_run_precheck_fails_on_issue_in_changed_code_and_cleans_up_branches(tmp_path):
    make_monorepo(tmp_path)
    api = FakeApi({
        "devpipe-precheck/77": [issue("web/src/app/pay.service.ts", 12, "CRITICAL"),
                                issue("web/src/old.ts", 3, "BLOCKER")],             # legacy: ignored
        "devpipe-precheck/77-net1": [issue("Refunds/RefundController.cs", 2, "MAJOR")],  # .NET base dir = api/
    })
    calls: list = []
    scanner = fake_scanner(calls=calls)
    result = sp.run_precheck(CONN, tmp_path, tmp_path, DIFF, run_id="77", api=api,
                             scanners={"cli": scanner, "dotnet": scanner})
    assert result.status == "failed" and not result.passed
    assert [(b["path"], b["line"]) for b in result.blocking] == [
        ("api/Refunds/RefundController.cs", 2), ("web/src/app/pay.service.ts", 12)]
    assert result.ignored == 1
    assert api.waited == ["T1-cli", "T1-dotnet"]
    assert sorted(api.deleted) == ["devpipe-precheck/77", "devpipe-precheck/77-net1"]
    report = result.report()
    assert "api/Refunds/RefundController.cs:2" in report and "web/src/old.ts" not in report


def test_run_precheck_passes_when_only_legacy_issues(tmp_path):
    api = FakeApi({"devpipe-precheck/1": [issue("web/src/old.ts", 3, "BLOCKER")]})
    diff = DIFF.split("diff --git a/api")[0]
    result = sp.run_precheck(CONN, tmp_path, tmp_path, diff, run_id="1", api=api,
                             scanners={"cli": fake_scanner()})
    assert result.status == "passed" and result.passed and result.ignored == 1
    assert "passed" in result.label()


def test_run_precheck_scanner_failure_is_an_error_not_a_code_problem(tmp_path):
    api = FakeApi({})
    result = sp.run_precheck(CONN, tmp_path, tmp_path, "+++ b/a.py\n@@ -0,0 +1 @@\n+x\n", run_id="2", api=api,
                             scanners={"cli": fake_scanner(returncode=3)})
    assert result.status == "error" and "exited 3" in result.message
    assert api.deleted == ["devpipe-precheck/2"]


def test_run_precheck_analysis_failed_or_no_task_id(tmp_path):
    diff = "+++ b/a.py\n@@ -0,0 +1 @@\n+x\n"
    r = sp.run_precheck(CONN, tmp_path, tmp_path, diff, run_id="3", api=FakeApi({}, status="FAILED"),
                        scanners={"cli": fake_scanner()})
    assert r.status == "error" and "FAILED" in r.message
    r = sp.run_precheck(CONN, tmp_path, tmp_path, diff, run_id="3", api=FakeApi({}),
                        scanners={"cli": fake_scanner(task="")})
    assert r.status == "error" and "ceTaskId" in r.message


def test_run_precheck_api_error_is_an_error(tmp_path):
    class Broken(FakeApi):
        def branch_issues(self, branch):
            raise requests.ConnectionError("down")
    api = Broken({})
    r = sp.run_precheck(CONN, tmp_path, tmp_path, "+++ b/a.py\n@@ -0,0 +1 @@\n+x\n", run_id="4", api=api,
                        scanners={"cli": fake_scanner()})
    assert r.status == "error" and "ConnectionError" in r.message
    assert api.deleted == ["devpipe-precheck/4"]


def test_run_precheck_keep_branch_and_no_changes(tmp_path):
    api = FakeApi({})
    r = sp.run_precheck(CONN, tmp_path, tmp_path, "+++ b/a.py\n@@ -0,0 +1 @@\n+x\n", {"keep_branch": True},
                        run_id="5", api=api, scanners={"cli": fake_scanner()})
    assert r.status == "passed" and api.deleted == []
    assert sp.run_precheck(CONN, tmp_path, tmp_path, "", api=api).status == "skipped"


def test_cli_scanner_missing_is_reported(tmp_path, monkeypatch):
    monkeypatch.setattr(sp.shutil, "which", lambda name: None)
    r = sp.run_precheck(CONN, tmp_path, tmp_path, "+++ b/a.py\n@@ -0,0 +1 @@\n+x\n", api=FakeApi({}))
    assert r.status == "error" and "sonar-scanner CLI not found" in r.message


def test_cli_scan_passes_branch_and_keeps_token_out_of_argv(tmp_path, monkeypatch):
    seen = {}

    def fake_run(cmd, cwd, capture_output, text, encoding, errors, env, timeout):
        seen.update(cmd=cmd, env=env)
        return subprocess.CompletedProcess(cmd, 0, "using tok-secret", "")
    monkeypatch.setattr(sp.shutil, "which", lambda name: "/bin/sonar-scanner")
    monkeypatch.setattr(sp.subprocess, "run", fake_run)
    monkeypatch.setenv("GITHUB_SHA", "pipeline-sha")
    unit = sp.ScanUnit("app", "cli", tmp_path, "devpipe-precheck/9")
    proc = sp.run_cli_scan(unit, CONN, tmp_path / "rt.txt", ["-Dx=y"])
    assert "-Dsonar.branch.name=devpipe-precheck/9" in seen["cmd"] and "-Dx=y" in seen["cmd"]
    assert "-Dsonar.organization=org" in seen["cmd"]
    assert not any("tok-secret" in a for a in seen["cmd"])
    assert seen["env"]["SONAR_TOKEN"] == "tok-secret" and "GITHUB_SHA" not in seen["env"]
    assert "tok-secret" not in proc.stdout


# ---------------------------------------------------------------- Step 4 wiring + config
def sonar_on(monkeypatch, required=True):
    monkeypatch.setitem(config.settings(), "sonar", {"enabled": True, "precheck": {"required": required}})
    for k, v in (("SONAR_TOKEN", "t"), ("SONAR_HOST_URL", "https://sonarcloud.io"), ("SONAR_PROJECT_KEY", "k")):
        monkeypatch.setenv(k, v)


def test_sonar_gate_required_but_not_configured_stops_the_pipeline(monkeypatch):
    monkeypatch.setitem(config.settings(), "sonar", {"enabled": True, "precheck": {"required": True}})
    monkeypatch.delenv("SONAR_TOKEN", raising=False)
    failure, label, infra = s6.sonar_gate("abc", None)
    assert infra is True and "SONAR_TOKEN" in failure and label.startswith("error")


def test_sonar_gate_optional_and_off_is_skipped(monkeypatch):
    monkeypatch.setitem(config.settings(), "sonar", {"enabled": False})
    assert s6.sonar_gate("abc", None) == (None, "skipped (disabled in config (sonar.enabled: false))", False)


@pytest.mark.parametrize("status,expect_failure,expect_infra", [
    ("failed", True, False), ("error", True, True), ("passed", False, False)])
def test_sonar_gate_maps_precheck_result(monkeypatch, status, expect_failure, expect_infra):
    sonar_on(monkeypatch)
    monkeypatch.setattr(s6, "change_diff", lambda base: "+++ b/a.py\n@@ -0,0 +1 @@\n+x\n")
    seen = {}

    def fake_precheck(conn, app_dir, work_root, diff, opts, run_id, newer_than):
        seen.update(conn=conn, opts=opts)
        blocking = [{"path": "a.py", "line": 1, "rule": "r", "message": "m", "severity": "MAJOR"}]
        return sp.PrecheckResult(status, blocking if status == "failed" else [], 0, ["app"], "boom")
    monkeypatch.setattr(s6, "run_precheck", fake_precheck)
    failure, label, infra = s6.sonar_gate("abc", None)
    assert (failure is not None) is expect_failure and infra is expect_infra
    assert seen["conn"]["project_key"] == "k" and seen["opts"] == {"required": True}
    if status == "failed":
        assert "a.py:1" in failure


def test_non_python_target_now_runs_the_sonar_precheck(monkeypatch, tmp_path):
    """Before: non-Python stacks always reported `skipped (non-Python)` and the PR was raised unchecked."""
    monkeypatch.setattr(s6, "target_settings", lambda: {"build_commands": ["npm test"], "app_dir": "."})
    monkeypatch.setattr(s6, "app_dir", lambda: tmp_path)
    monkeypatch.setattr(s6, "changed_paths", lambda base: ["a.ts"])
    monkeypatch.setattr(s6, "check_build", lambda *a: type("B", (), {"ok": True, "projects": ["."],
                                                                       "warnings": [], "report": lambda s: ""})())
    monkeypatch.setattr(s6, "sonar_gate", lambda base, started: ("Sonar pre-check FAILED: 1 blocking", "failed (1)", False))
    failures, data = s6.run_gates(80, "abc")
    assert failures == ["Sonar pre-check FAILED: 1 blocking"] and data["sonar_precheck"] == "failed (1)"

    monkeypatch.setattr(s6, "check_build", lambda *a: type("B", (), {"ok": False, "projects": ["."],
                                                                       "warnings": [], "report": lambda s: "err"})())
    failures, data = s6.run_gates(80, "abc")
    assert data["sonar_precheck"] == "not run (build failed)" and len(failures) == 1


def test_project_key_override_per_target_repo(monkeypatch):
    monkeypatch.setitem(config.settings(), "sonar", {"enabled": True, "project_keys": {"org/payments": "org_payments"}})
    monkeypatch.setenv("SONAR_PROJECT_KEY", "shared")
    monkeypatch.setattr(config, "is_external", lambda: True)
    monkeypatch.setattr(config, "resolved_target", lambda: {"full_name": "org/payments"})
    assert config.sonar_project_key() == "org_payments"
    monkeypatch.setattr(config, "resolved_target", lambda: {"full_name": "org/other"})
    assert config.sonar_project_key() == "shared"


def test_change_diff_lists_exact_changed_lines_of_a_real_repo(tmp_path, monkeypatch):
    """gitops.change_diff + parse_changed_lines on a real git repo: edits, new untracked files, tool output."""
    from dev_pipe import gitops
    monkeypatch.setattr(gitops, "ROOT", tmp_path)
    monkeypatch.setattr(gitops, "is_external", lambda: False)
    run = lambda *a: subprocess.run(["git", *a], cwd=tmp_path, check=True, capture_output=True)
    run("init", "-q")
    run("config", "user.email", "t@example.com")
    run("config", "user.name", "t")
    (tmp_path / "app.py").write_text("a = 1\nb = 2\nc = 3\n", encoding="utf-8")
    run("add", "-A")
    run("commit", "-qm", "base")
    base = gitops.head_sha()
    (tmp_path / "app.py").write_text("a = 1\nb = 20\nc = 3\nd = 4\n", encoding="utf-8")
    (tmp_path / "new file.py").write_text("x = 1\n", encoding="utf-8")
    (tmp_path / ".scannerwork").mkdir()
    (tmp_path / ".scannerwork/report-task.txt").write_text("ceTaskId=1\n", encoding="utf-8")
    changed = sp.parse_changed_lines(gitops.change_diff(base))
    assert changed == {"app.py": {2, 4}, "new file.py": {1}}


# ---------------------------------------------------------------- Step 5: separate job
def test_step6_no_longer_runs_sonar(monkeypatch, tmp_path):
    monkeypatch.setattr(s6, "target_settings", lambda: {"build_commands": ["npm test"], "app_dir": "."})
    monkeypatch.setattr(s6, "app_dir", lambda: tmp_path)
    monkeypatch.setattr(s6, "changed_paths", lambda base: ["a.ts"])
    monkeypatch.setattr(s6, "check_build", lambda *a: type("B", (), {"ok": True, "projects": ["."],
                                                                       "warnings": [], "report": lambda s: ""})())
    monkeypatch.setattr(s6, "sonar_gate", lambda *a: pytest.fail("Step 4 must not run Sonar"))
    failures, data = s6.run_gates(80, "abc", with_sonar=False)
    assert failures == [] and data["sonar_precheck"] == "runs in Step 5"


def _out(monkeypatch, tmp_path):
    from dev_pipe import io_utils
    out = tmp_path / "out"
    out.mkdir()
    monkeypatch.setattr(io_utils, "OUT", out)
    monkeypatch.setenv("GITHUB_STEP_SUMMARY", str(tmp_path / "summary.md"))
    return out


def test_step6b_skips_when_sonar_optional_and_off(monkeypatch, tmp_path):
    import json
    from dev_pipe.steps import s6b_sonar_precheck as s6b
    out = _out(monkeypatch, tmp_path)
    (out / "gates.json").write_text('{"coverage_pct": 90}', encoding="utf-8")
    monkeypatch.setattr(s6b, "sonar_status", lambda: (False, "disabled in config"))
    monkeypatch.setattr(s6b, "sonar_precheck_required", lambda: False)
    monkeypatch.setattr(s6b, "prepare_checkout", lambda: pytest.fail("no checkout needed when skipped"))
    s6b.main()
    gates = json.loads((out / "gates.json").read_text(encoding="utf-8"))
    assert gates == {"coverage_pct": 90, "sonar_precheck": "skipped (disabled in config)"}


@pytest.mark.parametrize("failures,infra,expect_exit", [([], False, None), (["Sonar FAILED"], False, "still there"),
                                                       (["could not run"], True, "could not run")])
def test_step6b_runs_the_fix_loop_with_sonar_and_blocks_the_pr(monkeypatch, tmp_path, failures, infra, expect_exit):
    import json
    from dev_pipe.steps import s6b_sonar_precheck as s6b
    out = _out(monkeypatch, tmp_path)
    (out / "gates.json").write_text('{"coverage_pct": 90, "passed": true}', encoding="utf-8")
    seen = {}
    monkeypatch.setattr(s6b, "OUT", out)
    monkeypatch.setattr(s6b, "sonar_status", lambda: (True, "enabled"))
    monkeypatch.setattr(s6b, "prepare_checkout", lambda: None)
    monkeypatch.setattr(s6b, "head_sha", lambda: "base1")
    monkeypatch.setattr(s6b, "apply_patch", lambda p: seen.setdefault("patch", p.name))
    monkeypatch.setattr(s6b, "snapshot_patch", lambda base: b"diff")

    def fake_loop(threshold, base, max_attempts, with_sonar, step, reuse=None):
        seen.update(base=base, max_attempts=max_attempts, with_sonar=with_sonar, step=step)
        return failures, {"coverage_pct": 91, "sonar_precheck": "label", "sonar_infra_error": infra}, 2
    monkeypatch.setattr(s6b, "fix_loop", fake_loop)
    if expect_exit:
        with pytest.raises(SystemExit, match=expect_exit):
            s6b.main()
    else:
        s6b.main()
    assert seen == {"patch": "changes.patch", "base": "base1", "max_attempts": 3, "with_sonar": True,
                    "step": "fix_sonar"}
    gates = json.loads((out / "gates.json").read_text(encoding="utf-8"))
    assert gates["passed"] is (not failures) and gates["coverage_pct"] == 91 and gates["sonar_precheck"] == "label"
    assert (out / "changes.patch").read_bytes() == b"diff"


# ---------------------------------------------------------------- coverage + Step 7 baseline scan
def test_coverage_args_skip_stale_reports(tmp_path):
    import os, time
    old = tmp_path / "coverage.xml"
    old.write_text("<coverage/>", encoding="utf-8")
    os.utime(old, (time.time() - 3600, time.time() - 3600))
    assert sp.coverage_args(tmp_path, time.time()) == []
    (tmp_path / "backend").mkdir()
    (tmp_path / "backend" / "coverage.xml").write_text("<coverage/>", encoding="utf-8")
    assert sp.coverage_args(tmp_path, time.time() - 1) == ["-Dsonar.python.coverage.reportPaths=backend/coverage.xml"]


def test_python_project_in_own_venv_writes_coverage_xml(tmp_path):
    from dev_pipe import stack
    (tmp_path / "requirements.txt").write_text("fastapi\n", encoding="utf-8")
    (tmp_path / "tests").mkdir()
    cmd = stack.python_project(tmp_path).commands[-1].cmd
    assert "-m pytest tests" in cmd and "--cov=. --cov-report=xml:coverage.xml" in cmd
    bare = tmp_path / "bare"
    (bare / "tests").mkdir(parents=True)
    assert "--cov" not in stack.python_project(bare).commands[-1].cmd   # pipeline's Python: no pytest-cov promise


def test_cli_scan_without_branch_analyses_main(tmp_path, monkeypatch):
    seen = {}
    monkeypatch.setattr(sp.shutil, "which", lambda name: "/bin/sonar-scanner")
    monkeypatch.setattr(sp.subprocess, "run", lambda cmd, **kw: seen.setdefault("cmd", cmd)
                        and subprocess.CompletedProcess(cmd, 0, "", ""))
    sp.run_cli_scan(sp.ScanUnit("baseline", "cli", tmp_path, ""), CONN, tmp_path / "rt.txt", [])
    assert not any(a.startswith("-Dsonar.branch.name") for a in seen["cmd"])


class BranchApi(FakeApi):
    def __init__(self, branches, status="SUCCESS"):
        super().__init__({}, status)
        self._branches = branches

    def branches(self):
        return self._branches


@pytest.mark.parametrize("branches,expect_scan,expect_branch", [
    ([{"name": "main", "isMain": True, "analysisDate": "2026-10-01"}], False, None),     # already analysed
    ([{"name": "main", "isMain": True}], True, ""),                                      # main never analysed
    ([], True, ""),                                                                       # brand-new project
    ([{"name": "master", "isMain": True, "analysisDate": "x"}], True, "main"),           # main analysed, base unknown
])
def test_step7_baseline_scan_only_when_target_branch_has_no_analysis(monkeypatch, tmp_path, branches,
                                                                     expect_scan, expect_branch):
    from dev_pipe.steps import s8_sonarqube_quality_validation as s8
    api = BranchApi(branches)
    scans, gits = [], []
    monkeypatch.setattr(s8, "SonarApi", lambda *a: api)
    monkeypatch.setattr(s8, "app_dir", lambda: tmp_path)
    monkeypatch.setattr(s8, "git", lambda *a, **k: gits.append(a) or "sha1")

    def fake_scan(unit, conn, metadata, extra):
        scans.append(unit.branch)
        metadata.write_text("ceTaskId=B1\n", encoding="utf-8")
        return subprocess.CompletedProcess(["s"], 0, "", "")
    monkeypatch.setattr(s8, "run_cli_scan", fake_scan)
    s8.ensure_base_analysed(CONN, "main", "feature/1-x", 60)
    assert (scans == [expect_branch]) if expect_scan else scans == []
    if expect_scan:
        assert api.waited == ["B1"]
        assert gits[0][:3] == ("checkout", "-q", "--detach") and gits[-1] == ("checkout", "-q", "-B", "feature/1-x",
                                                                            "origin/feature/1-x")


def test_step7_baseline_scan_never_fails_the_step(monkeypatch, tmp_path):
    from dev_pipe.steps import s8_sonarqube_quality_validation as s8

    class Down(BranchApi):
        def branches(self):
            raise requests.ConnectionError("down")
    monkeypatch.setattr(s8, "SonarApi", lambda *a: Down([]))
    monkeypatch.setattr(s8, "git", lambda *a, **k: pytest.fail("no checkout when Sonar is unreachable"))
    s8.ensure_base_analysed(CONN, "main", "feature/1-x", 60)   # no exception
