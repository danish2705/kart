"""Tests for stack detection and the build check (dev_pipe/stack.py, dev_pipe/build.py). No network."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest

from dev_pipe import build, config, stack


def write(path: Path, text: str = "") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path


def pkg(path: Path, scripts: dict, dev: dict | None = None, **extra) -> None:
    write(path / "package.json", json.dumps({"name": "x", "scripts": scripts, "devDependencies": dev or {}, **extra}))


def cmds(project) -> list[str]:
    return [c.cmd for c in project.commands]


T = {"app_dir": ".", "test_dir": "tests", "language": "auto", "build_commands": []}


# ---------- detection per stack
def test_react_frontend_without_tests_type_checks_and_warns(tmp_path):
    """The failing run: a Vite/React TS frontend with no tests. Must type-check, build, and warn (not fail)."""
    fe = tmp_path / "frontend"
    pkg(fe, {"build": "vite build", "dev": "vite"}, {"typescript": "^5.4.0", "vite": "^5"})
    write(fe / "package-lock.json", "{}")
    write(fe / "tsconfig.json", '{\n  // comment\n  "compilerOptions": {"strict": true,},\n}')
    write(fe / "src" / "App.tsx", "export {}")
    [p] = stack.detect_projects(tmp_path)
    assert p.stack == "node" and p.path == fe.resolve()
    assert cmds(p) == ["npm ci", "npx --no-install tsc --noEmit -p tsconfig.json", "npm run build"]
    assert p.has_tests is False and "no `test` script" in p.warnings[0]


def test_node_solution_tsconfig_checks_referenced_configs(tmp_path):
    pkg(tmp_path, {"build": "vite build"}, {"typescript": "5"})
    write(tmp_path / "tsconfig.json", '{"files": [], "references": [{"path": "./tsconfig.app.json"}, {"path": "./tsconfig.node.json"}]}')
    write(tmp_path / "tsconfig.app.json", "{}")
    write(tmp_path / "tsconfig.node.json", "{}")
    [p] = stack.detect_projects(tmp_path)
    assert "npx --no-install tsc --noEmit -p tsconfig.app.json" in cmds(p)
    assert "npx --no-install tsc --noEmit -p tsconfig.node.json" in cmds(p)


def test_node_build_with_tsc_and_tests_and_lockfiles(tmp_path):
    pkg(tmp_path, {"build": "tsc -b && vite build", "test": "vitest run"}, {"typescript": "5"})
    write(tmp_path / "yarn.lock")
    write(tmp_path / "tsconfig.json", "{}")
    write(tmp_path / "src" / "a.test.ts")
    [p] = stack.detect_projects(tmp_path)
    assert cmds(p) == ["yarn install --frozen-lockfile", "yarn run build", "yarn run test"]  # tsc already in build
    assert p.has_tests and not p.warnings


def test_node_test_script_without_test_files_is_skipped(tmp_path):
    pkg(tmp_path, {"test": "jest"})
    write(tmp_path / "pnpm-lock.yaml")
    [p] = stack.detect_projects(tmp_path)
    assert cmds(p)[0] == "corepack pnpm install --frozen-lockfile"
    assert "corepack pnpm run test" not in cmds(p) and not p.has_tests


def test_node_typecheck_script_preferred_and_default_test_ignored(tmp_path):
    pkg(tmp_path, {"typecheck": "tsc --noEmit", "test": 'echo "Error: no test specified" && exit 1'}, {"typescript": "5"})
    write(tmp_path / "tsconfig.json", "{}")
    [p] = stack.detect_projects(tmp_path)
    assert cmds(p) == ["npm install --no-audit --no-fund", "npm run typecheck"]
    assert not p.has_tests


def test_python_maven_gradle_dotnet_go(tmp_path):
    write(tmp_path / "py" / "pyproject.toml")
    write(tmp_path / "py" / "tests" / "test_a.py")
    write(tmp_path / "jv" / "pom.xml")
    write(tmp_path / "jv" / "mvnw")
    write(tmp_path / "jv" / "src" / "test" / "java" / "ATest.java")
    write(tmp_path / "gr" / "build.gradle.kts")
    write(tmp_path / "net" / "App.sln")
    write(tmp_path / "net" / "App.Tests" / "App.Tests.csproj", "<PackageReference Include=\"Microsoft.NET.Test.Sdk\" />")
    write(tmp_path / "go" / "go.mod")
    by = {p.stack: p for p in stack.detect_projects(tmp_path)}
    assert set(by) == {"python", "maven", "gradle", "dotnet", "go"}
    assert any("pytest tests" in c for c in cmds(by["python"]))
    assert cmds(by["maven"]) == ["sh ./mvnw -B -q verify"] and by["maven"].has_tests
    assert cmds(by["gradle"]) == ["gradle build --no-daemon -q"] and not by["gradle"].has_tests
    assert cmds(by["dotnet"]) == ["dotnet build App.sln -nologo", "dotnet test App.sln --no-build -nologo"]
    assert "go test ./..." not in cmds(by["go"]) and not by["go"].has_tests


def test_python_without_tests_warns_instead_of_running_pytest(tmp_path):
    write(tmp_path / "requirements.txt")
    write(tmp_path / "app.py")
    [p] = stack.detect_projects(tmp_path)
    assert "compileall" in p.commands[-1].cmd and not any("pytest " in c.cmd and "pytest-cov" not in c.cmd
                                                          for c in p.commands)
    assert not p.has_tests


def test_plain_python_folder_like_sample_app(tmp_path):
    write(tmp_path / "app" / "main.py")
    write(tmp_path / "tests" / "test_main.py")
    [p] = stack.detect_projects(tmp_path)
    assert p.stack == "python" and p.path == tmp_path.resolve() and p.has_tests


def test_skips_dependency_folders_and_nested_modules(tmp_path):
    pkg(tmp_path / "fe", {"build": "x"})
    pkg(tmp_path / "fe" / "node_modules" / "dep", {"build": "x"})
    write(tmp_path / "jv" / "pom.xml")
    write(tmp_path / "jv" / "module-a" / "pom.xml")             # covered by the parent multi-module build
    pkg(tmp_path / "mono", {"build": "x"}, workspaces=["packages/*"])
    pkg(tmp_path / "mono" / "packages" / "ui", {"build": "x"})   # covered by the workspace root
    paths = sorted(p.rel(tmp_path) for p in stack.detect_projects(tmp_path))
    assert paths == ["fe", "jv", "mono"]


def test_separate_node_apps_are_separate_projects(tmp_path):
    pkg(tmp_path, {"build": "x"})
    pkg(tmp_path / "admin", {"build": "x"})
    assert sorted(p.rel(tmp_path) for p in stack.detect_projects(tmp_path)) == [".", "admin"]


def test_select_projects_by_changed_files(tmp_path):
    pkg(tmp_path / "frontend", {"build": "x"})
    write(tmp_path / "backend" / "pyproject.toml")
    projects = stack.detect_projects(tmp_path)
    sel, note = stack.select_projects(projects, [tmp_path / "frontend" / "src" / "a.tsx"])
    assert [p.stack for p in sel] == ["node"] and note == ""
    sel, note = stack.select_projects(projects, [tmp_path / "README.md"])
    assert len(sel) == 2 and "outside" in note


# ---------- build plan / precedence
def test_plan_uses_configured_commands_first(tmp_path):
    pkg(tmp_path, {"build": "x"})
    plan = build.plan_build({**T, "build_commands": ["make ci"]}, tmp_path)
    assert [c.cmd for c in plan.units[0].commands] == ["make ci"]


def test_plan_fails_clearly_when_nothing_detected(tmp_path):
    write(tmp_path / "README.md")
    plan = build.plan_build(T, tmp_path)
    assert not plan.units and "No build system detected" in plan.error
    result = build.check_build(T, tmp_path)
    assert result.ok is False and "No build system detected" in result.log


def test_language_limits_detection(tmp_path):
    pkg(tmp_path / "fe", {"build": "x"})
    write(tmp_path / "be" / "requirements.txt")
    plan = build.plan_build({**T, "language": "typescript"}, tmp_path)
    assert [u.label for u in plan.units] == ["fe (node)"]
    assert build.plan_build({**T, "language": "java"}, tmp_path).error


def test_is_python_target(tmp_path):
    write(tmp_path / "app" / "main.py")
    assert build.is_python_target(T, tmp_path)
    pkg(tmp_path / "web", {"build": "x"})
    assert not build.is_python_target(T, tmp_path)               # now a monorepo
    assert build.is_python_target({**T, "language": "python"}, tmp_path)
    assert not build.is_python_target({**T, "language": "python", "build_commands": ["x"]}, tmp_path)


def test_check_build_runs_detected_commands_and_reports_warnings(tmp_path, monkeypatch):
    write(tmp_path / "go.mod")
    seen = []
    monkeypatch.setattr(build, "_run_commands", lambda cwd, cs: (seen.extend(c.cmd for c in cs), (True, "ok"))[1])
    result = build.check_build(T, tmp_path)
    assert result.ok and seen == ["go build ./...", "go vet ./..."]
    assert result.projects == [". (go)"] and "no *_test.go" in result.warnings[0]
    assert "WARNING" in result.report()


def test_check_build_real_python_project_without_tests_passes(tmp_path):
    write(tmp_path / "requirements.txt")
    write(tmp_path / "app.py", "x = 1\n")
    result = build.check_build(T, tmp_path)
    assert result.ok and result.warnings


def test_run_build_python_missing_test_dir_is_not_a_failure(tmp_path):
    """Regression: `pytest tests` on a repo without tests/ used to exit 4 and fail the step."""
    write(tmp_path / "app.py", "x = 1\n")
    ok, log = build.run_build(tmp_path, "tests")
    assert ok and "WARNING" in log


def test_build_check_text_lists_detected_commands(tmp_path):
    pkg(tmp_path / "frontend", {"build": "vite build"}, {"typescript": "5"})
    write(tmp_path / "frontend" / "tsconfig.json", "{}")
    text = build.build_check_text(T, tmp_path)
    # The AI's shell has no network (agent.sandbox): the pipeline installs first, so the AI is not told to install.
    assert "npm install" not in text
    assert "in `frontend` run `npx --no-install tsc --noEmit" in text and "only report a check as passed if you ran it" in text


def test_build_check_text_includes_install_when_sandbox_is_off(tmp_path, monkeypatch):
    monkeypatch.setattr(build, "sandboxed", lambda: False)
    pkg(tmp_path / "frontend", {"build": "vite build"}, {"typescript": "5"})
    write(tmp_path / "frontend" / "tsconfig.json", "{}")
    assert "in `frontend` run `npm install --no-audit --no-fund`" in build.build_check_text(T, tmp_path)


def test_build_env_drops_pipeline_secrets(monkeypatch):
    for name in ("ADO_PAT", "AZURE_OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GITHUB_TOKEN", "SONAR_TOKEN",
                 "TARGET_GITHUB_TOKEN"):
        monkeypatch.setenv(name, "s3cret")
    monkeypatch.setenv("NPM_TOKEN", "npm")
    env = build._build_env()
    assert "s3cret" not in env.values() and env["NPM_TOKEN"] == "npm" and env["CI"] == "true"
    assert "PATH" in env


def test_jsonc_loader():
    assert stack.load_jsonc(Path("/does/not/exist")) == {}


# ---------- repo-owned .devpipe.yml
def test_repo_file_settings_precedence(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "OUT", tmp_path / "out")
    (tmp_path / "out").mkdir()
    (tmp_path / "out" / "target.json").write_text(json.dumps({"full_name": "org/web"}))
    checkout = tmp_path / "checkout"
    monkeypatch.setattr(config, "TARGET_CHECKOUT", checkout)
    write(checkout / ".devpipe.yml", "build_commands: ['make ci']\ntest_dir: spec\nsecret_thing: nope\n")
    target = {"mode": "external", "app_dir": "x", "app_package": "app", "test_dir": "tests",
              "architecture_file": "a.md", "language": "auto", "build_commands": [], "overrides": {}}
    monkeypatch.setitem(config.settings(), "target", target)
    t = config.target_settings()
    assert t["build_commands"] == ["make ci"] and t["test_dir"] == "spec" and "secret_thing" not in t
    target["overrides"] = {"org/web": {"build_commands": ["npm test"]}}
    assert config.target_settings()["build_commands"] == ["npm test"]   # config override wins


# ---------- Python target repos: their own dependencies are installed (separate virtualenv)
@pytest.mark.parametrize("files,expected", [
    ({"requirements.txt": "", "requirements-dev.txt": ""}, ["-r requirements.txt", "-r requirements-dev.txt"]),
    ({"setup.py": ""}, ["-e ."]),
    ({"pyproject.toml": '[project]\nname="x"\n[project.optional-dependencies]\ntest=["pytest"]\ndocs=["x"]\n'},
     ["-e '.[test]'"]),
    ({"pyproject.toml": '[build-system]\nrequires=["setuptools"]\n'}, ["-e ."]),
    ({"pyproject.toml": '[tool.poetry]\nname="x"\n'}, ["poetry install"]),
    ({"Pipfile": "", "Pipfile.lock": "{}"}, ["pipenv requirements --dev"]),
    ({"pyproject.toml": "[tool.black]\nline-length=100\n"}, []),     # tool config only: nothing to install
])
def test_python_install_commands(tmp_path, files, expected):
    if "[test]" in str(expected) and sys.version_info < (3, 11):
        pytest.skip("reading extras needs tomllib (Python 3.11+; the pipeline runs on 3.12)")
    for name, text in files.items():
        write(tmp_path / name, text)
    cmds = stack.python_install_commands(tmp_path, "PY")
    assert len(cmds) == len(expected)
    for cmd, part in zip(cmds, expected):
        assert part in cmd and cmd.startswith("PY -m pip install")


def test_python_project_with_requirements_uses_its_own_venv(tmp_path):
    write(tmp_path / "requirements.txt", "requests\n")
    write(tmp_path / "tests" / "test_a.py")
    [p] = stack.detect_projects(tmp_path)
    venv_py = str(stack.VENV_ROOT)
    assert "venv.create" in p.commands[0].cmd                              # 1. create the virtualenv
    assert "-r requirements.txt" in p.commands[1].cmd and venv_py in p.commands[1].cmd   # 2. repo deps
    assert "pytest pytest-cov" in p.commands[2].cmd                        # 3. test tools
    assert all(venv_py in c.cmd for c in p.commands[1:])                   # compileall + pytest use the venv
    assert not p.warnings


def test_python_project_without_dependency_file_warns(tmp_path):
    write(tmp_path / "app" / "main.py")
    [p] = stack.detect_projects(tmp_path)
    assert "compileall" in p.commands[0].cmd and "no dependency file" in p.warnings[0]


@pytest.mark.skipif(os.name == "nt" or os.environ.get("DEVPIPE_SKIP_NETWORK") == "1",
                    reason="creates a virtualenv and installs from PyPI")
def test_python_repo_dependencies_installed_end_to_end(tmp_path, monkeypatch):
    """A Python repo whose tests import a library the pipeline doesn't have: must pass after installing it."""
    monkeypatch.setattr(stack, "VENV_ROOT", tmp_path / "venvs")
    repo = tmp_path / "repo"
    write(repo / "requirements.txt", "tomli-w==1.0.0\n")
    write(repo / "app.py", "import tomli_w\n\ndef dump(d):\n    return tomli_w.dumps(d)\n")
    write(repo / "tests" / "test_app.py", "from app import dump\n\ndef test_dump():\n    assert dump({'a': 1}) == 'a = 1\\n'\n")
    write(repo / "conftest.py", "")
    result = build.check_build(T, repo)
    assert result.ok, result.log
    ok, python, _ = build.prepare_python(repo)
    assert ok and str(tmp_path / "venvs") in python


@pytest.mark.skipif(os.name == "nt", reason="uses sh")
def test_run_commands_respects_ok_codes(tmp_path):
    ok, _ = build._run_commands(tmp_path, [stack.Command("exit 5", (0, 5))])
    assert ok
    ok, log = build._run_commands(tmp_path, [stack.Command("exit 4", (0, 5))])
    assert not ok and "exit 4" in log
