"""Tests for the 'agent stopped early' follow-up loop in dev_pipe/agent_runner.py. Fake agent, no LLM."""
from __future__ import annotations

import asyncio

import pytest
from claude_agent_sdk import ResultMessage

from dev_pipe import agent_runner as ar

PLAN = ("## Summary\nAdd delete.\n\n```json\n"
        '{"branch": "feature/1-x", "files": [{"path": "a.ts", "action": "modify", "reason": "r"}]}\n```')
STALL = "I need to examine HistoryModal.tsx. I'll read:\n- frontend/src/components/runs/HistoryModal.tsx"


class FakeClient:
    """Answers each query with the next scripted final message."""

    def __init__(self, answers, on_query=None):
        self.answers = list(answers)
        self.queries: list[str] = []
        self.on_query = on_query

    async def query(self, prompt):
        self.queries.append(prompt)
        if self.on_query:
            self.on_query(len(self.queries))

    async def receive_response(self):
        answer = self.answers.pop(0)
        if answer is MAX_TURNS:  # the SDK's result when agent.max_turns is used up
            yield ResultMessage(subtype="error_max_turns", duration_ms=1, duration_api_ms=1, is_error=True,
                                num_turns=150, session_id="s", result=None)
            return
        yield ResultMessage(subtype="success", duration_ms=1, duration_api_ms=1, is_error=False, num_turns=1,
                            session_id="s", result=answer)


MAX_TURNS = object()


def converse(client, check, max_followups=2, on_incomplete="fail"):
    return asyncio.run(ar._converse(client, ["make a plan"], check, max_followups, on_incomplete))


def test_plan_stall_gets_followup_in_same_conversation(capsys):
    client = FakeClient([STALL, PLAN])
    assert converse(client, ar.plan_followup) == PLAN
    assert len(client.queries) == 2 and "COMPLETE development plan" in client.queries[1]
    assert "asking it to continue (1/2)" in capsys.readouterr().out


def test_plan_fails_clearly_after_max_followups():
    client = FakeClient([STALL, STALL, STALL])
    with pytest.raises(SystemExit, match=r"stopped 3 time\(s\) without finishing .*AZURE_OPENAI_DEPLOYMENT"):
        converse(client, ar.plan_followup)
    assert len(client.queries) == 3


def test_complete_answer_needs_no_followup():
    client = FakeClient([PLAN])
    assert converse(client, ar.plan_followup) == PLAN and len(client.queries) == 1


def test_no_check_keeps_old_behaviour():
    client = FakeClient([STALL])
    assert converse(client, None) == STALL and len(client.queries) == 1


@pytest.mark.parametrize("text,reason", [
    ("no block", "no ```json metadata block"),
    ("```json\n{\"files\": [}\n```", "not valid JSON"),
    ("```json\n{\"files\": []}\n```", "no `files` list"),
])
def test_plan_followup_reasons(text, reason):
    assert reason in ar.plan_followup(text).splitlines()[0]


def test_changes_followup_until_files_change(capsys):
    changed: list[str] = []
    client = FakeClient(["I'll edit HistoryModal.tsx next.", "Done: edited a.ts"],
                        on_query=lambda n: changed.append("frontend/a.ts") if n == 2 else None)
    out = converse(client, ar.changes_followup(lambda: changed))
    assert out == "Done: edited a.ts" and "Edit/Write" in client.queries[1]


def test_tests_followup_warn_mode_does_not_fail(capsys):
    client = FakeClient(["will write tests", "still nothing", "no test setup in this repo"])
    out = converse(client, ar.tests_followup(lambda: ["frontend/src/a.ts"]), on_incomplete="warn")
    assert out == "no test setup in this repo" and "WARNING" in capsys.readouterr().out


@pytest.mark.parametrize("path,is_test", [
    ("tests/test_main.py", True), ("sample_app/tests/x.py", True), ("app/test_util.py", True),
    ("pkg/foo_test.go", True), ("src/a.test.tsx", True), ("src/__tests__/a.ts", True),
    ("src/test/java/AppTest.java", True), ("App.Tests/UnitTests.cs", True),
    ("src/App.tsx", False), ("src/contest.java", False), ("frontend/src/services/runs.service.ts", False),
    ("latest/main.py", False),
])
def test_is_test_path(path, is_test):
    assert ar.is_test_path(path) is is_test


# ---------- per-step skills
def test_skills_for_step(monkeypatch):
    agent = {"skills": ["coverage-95-gate", "test-quality-review", "sonar-zero-issues"],
             "step_skills": {"plan": [], "implement": ["sonar-zero-issues", "not-installed"]}}
    monkeypatch.setitem(ar.settings(), "agent", agent)
    assert ar.skills_for("plan") == []
    assert ar.skills_for("implement") == ["sonar-zero-issues"]          # unknown names are dropped
    assert ar.skills_for("fix_gates") == agent["skills"]               # no entry: all installed skills
    assert ar.skills_for(None) == agent["skills"]


# ---------- Step 3: build errors and questions are sent back to the agent
@pytest.mark.parametrize("text,asks", [
    ("Please let me know if you'd like me to proceed with that refactor.", True),
    ("Would you like me to move TrashIcon into its own file?", True),
    ("Should I also update the backend?", True),
    ("Files changed: a.ts (added deleteRun). Build passes.", False),
    ("Check manually: the confirmation text.", False),
])
def test_question_followup(text, asks):
    assert (ar.question_followup(text) is not None) is asks


def test_first_of_returns_first_problem():
    check = ar.first_of(lambda t: None, lambda t: "second\nmsg", lambda t: "third")
    assert check("x") == "second\nmsg" and ar.first_of(lambda t: None)("x") is None


def test_step4_build_errors_are_fed_back_until_fixed(tmp_path, monkeypatch, capsys):
    """The failing run: the agent left a broken file. The pipeline builds, sends the errors back, the agent
    fixes the file on the follow-up, the build passes."""
    from dev_pipe.steps import s4_autonomous_development as s4
    src = tmp_path / "app.py"
    src.write_text("def f(:\n")                                    # broken, like the duplicated Icons.tsx
    monkeypatch.setattr(s4, "app_dir", lambda: tmp_path)
    monkeypatch.setattr(s4, "work_root", lambda: tmp_path)
    t = {"app_dir": ".", "test_dir": "tests", "language": "python", "build_commands": []}
    fix = lambda n: src.write_text("def f():\n    return 1\n") if n == 2 else None
    client = FakeClient(["Done.", "Fixed the syntax error."], on_query=fix)
    check = ar.first_of(ar.changes_followup(lambda: ["app.py"]), s4.build_followup(t, lambda: ["app.py"]),
                        ar.question_followup)
    out = converse(client, check, max_followups=3, on_incomplete="warn")
    assert out == "Fixed the syntax error." and len(client.queries) == 2
    assert "build check on your changes and it FAILED" in client.queries[1] and "app.py" in client.queries[1]
    assert "Re-read each affected file" in client.queries[1]
    assert "(the build failed); asking it to continue (1/3)" in capsys.readouterr().out


def test_step4_still_failing_warns_instead_of_raising(tmp_path, monkeypatch, capsys):
    from dev_pipe.steps import s4_autonomous_development as s4
    (tmp_path / "app.py").write_text("def f(:\n")
    monkeypatch.setattr(s4, "app_dir", lambda: tmp_path)
    monkeypatch.setattr(s4, "work_root", lambda: tmp_path)
    t = {"app_dir": ".", "test_dir": "tests", "language": "python", "build_commands": []}
    client = FakeClient(["a", "b", "c"])
    out = converse(client, s4.build_followup(t, lambda: ["app.py"]), max_followups=2, on_incomplete="warn")
    assert out == "c" and "WARNING" in capsys.readouterr().out


def test_max_turns_asks_agent_to_finish_instead_of_failing(capsys):
    client = FakeClient([MAX_TURNS, PLAN])
    assert converse(client, ar.plan_followup) == PLAN
    assert len(client.queries) == 2 and "ran out of turns" in client.queries[1]
    assert "reached the turn limit" in capsys.readouterr().out


def test_max_turns_every_time_fails_after_max_followups():
    client = FakeClient([MAX_TURNS, MAX_TURNS, MAX_TURNS])
    with pytest.raises(SystemExit, match=r"ran out of turns"):
        converse(client, ar.plan_followup)
    assert len(client.queries) == 3


def test_max_turns_without_check_fails_clearly():
    client = FakeClient([MAX_TURNS])
    with pytest.raises(SystemExit, match=r"agent\.max_turns"):
        converse(client, None)
