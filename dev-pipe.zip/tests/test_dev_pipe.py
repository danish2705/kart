"""Unit tests for the dev pipeline's deterministic parts (no network, no LLM)."""
from __future__ import annotations

import subprocess

import pytest

from dev_pipe import ado, config, gitops, sonar
from dev_pipe.agent_runner import extract_json_block, strip_json_block
from dev_pipe.steps.s9_ado_update_complete import build_summary


# ---------- config
def test_slugify_and_branch_name_follow_pattern():
    assert config.slugify("Add task PRIORITY filter!!") == "add-task-priority-filter"
    assert config.branch_name(42, "Add filter") == "feature/42-add-filter"


def test_branch_name_keeps_valid_suggestion_and_rejects_bad_one():
    assert config.branch_name(42, "x", "feature/42-custom") == "feature/42-custom"
    assert config.branch_name(42, "Add filter", "main; rm -rf /") == "feature/42-add-filter"
    assert config.branch_name(42, "Add filter", "hotfix/42") == "feature/42-add-filter"


def test_dry_run_defaults_to_true(monkeypatch):
    monkeypatch.delenv("DRY_RUN", raising=False)
    assert config.is_dry_run() is True
    monkeypatch.setenv("DRY_RUN", "false")
    assert config.is_dry_run() is False


def test_work_item_id_validation(monkeypatch):
    monkeypatch.setenv("WORK_ITEM_ID", "abc")
    with pytest.raises(SystemExit):
        config.work_item_id()
    monkeypatch.setenv("WORK_ITEM_ID", "123")
    assert config.work_item_id() == 123


def test_every_prompt_placeholder_is_filled():
    t = config.settings()["target"]
    text = config.load_prompt("plan", story="s", architecture="a", feedback="f",
                              app_dir=t["app_dir"], branch_hint="feature/1-x", target="r", code_context="c")
    assert "{{" not in text
    common = dict(plan="p", feedback="f", app_dir=".", test_dir="tests", build_check="run x.")
    assert "{{" not in config.load_prompt("implement", architecture_file="a.md", **common)
    assert "{{" not in config.load_prompt("unit_tests", app_package="app", threshold=85, **common)
    assert "{{" not in config.load_prompt("fix_gates", attempt=1, max_attempts=2, failures="x",
                                          app_dir=".", test_dir="tests", build_check="run x.")


def test_sonar_off_by_config_even_with_token(monkeypatch):
    monkeypatch.setitem(config.settings(), "sonar", {"enabled": False})
    monkeypatch.setenv("SONAR_TOKEN", "x")
    assert config.sonar_status() == (False, "disabled in config (sonar.enabled: false)")


def test_sonar_on_but_incomplete_is_skipped_not_failed(monkeypatch):
    monkeypatch.setitem(config.settings(), "sonar", {"enabled": True})
    monkeypatch.setenv("SONAR_TOKEN", "x")
    monkeypatch.delenv("SONAR_HOST_URL", raising=False)
    monkeypatch.delenv("SONAR_PROJECT_KEY", raising=False)
    enabled, reason = config.sonar_status()
    assert enabled is False and "SONAR_HOST_URL" in reason and "SONAR_PROJECT_KEY" in reason


def test_sonar_on_and_configured(monkeypatch):
    monkeypatch.setitem(config.settings(), "sonar", {"enabled": True})
    for k in ("SONAR_TOKEN", "SONAR_HOST_URL", "SONAR_PROJECT_KEY"):
        monkeypatch.setenv(k, "x")
    assert config.sonar_status() == (True, "enabled")


# ---------- ado
def test_simplify_strips_html_and_reads_assignee():
    raw = {"id": 7, "url": "u", "fields": {
        "System.Title": "T", "System.Description": "<p>Hello &amp; bye</p>",
        "System.AssignedTo": {"uniqueName": "dev@example.com"}, "System.IterationPath": "P\\S1"}}
    s = ado.simplify(raw)
    assert s["description"] == "Hello & bye"
    assert s["assigned_to"] == "dev@example.com"
    assert s["iteration_path"] == "P\\S1"


def test_new_task_patch_links_parent_and_skips_empty_fields():
    ops = ado.patch_new_task("DEV - T", "https://x/wi/1", "", "Area", "Iter")
    paths = [o["path"] for o in ops]
    assert "/fields/System.AssignedTo" not in paths
    assert "/fields/System.IterationPath" in paths
    assert ops[-1]["value"] == {"rel": "System.LinkTypes.Hierarchy-Reverse", "url": "https://x/wi/1"}


def test_ado_writes_are_skipped_in_dry_run(monkeypatch):
    for k, v in {"ADO_ORG_URL": "https://dev.azure.com/o", "ADO_PROJECT": "p", "ADO_PAT": "x", "DRY_RUN": "true"}.items():
        monkeypatch.setenv(k, v)
    client = ado.AdoClient()
    client.session.request = lambda *a, **k: pytest.fail("network call in dry run")
    assert client.set_state(1, "Active")["dry_run"] is True
    assert client.add_comment(1, "hi")["dry_run"] is True


def test_ado_sign_in_page_gives_clear_error(monkeypatch):
    """Bad/expired PAT: ADO returns HTTP 203 + HTML sign-in page instead of a 401."""
    for k, v in {"ADO_ORG_URL": "https://dev.azure.com/o", "ADO_PROJECT": "p", "ADO_PAT": "x"}.items():
        monkeypatch.setenv(k, v)

    class FakeResp:
        status_code = 203
        headers = {"Content-Type": "text/html; charset=utf-8"}
        content = b"\r\n\r\n<html>sign in</html>"
        text = content.decode()

    client = ado.AdoClient()
    client.session.request = lambda *a, **k: FakeResp()
    with pytest.raises(SystemExit) as err:
        client.get_work_item(1)
    assert "sign-in page" in str(err.value) and "ADO_PAT" in str(err.value)


def test_set_output_writes_github_output(tmp_path, monkeypatch):
    from dev_pipe.io_utils import set_output
    out = tmp_path / "gh_output"
    monkeypatch.setenv("GITHUB_OUTPUT", str(out))
    set_output("existing_code_changed", "true")
    assert out.read_text() == "existing_code_changed=true\n"


# ---------- agent output parsing
def test_extract_json_block_takes_last_block():
    text = 'plan\n```json\n{"branch": "a"}\n```\nmore\n```json\n{"branch": "b"}\n```'
    assert extract_json_block(text) == {"branch": "b"}
    assert "```json" not in strip_json_block(text)


def test_extract_json_block_requires_block():
    with pytest.raises(SystemExit):
        extract_json_block("no metadata")


# ---------- sonar
def test_evaluate_gate_lists_failed_conditions():
    passed, failed = sonar.evaluate_gate({"status": "ERROR", "conditions": [
        {"status": "ERROR", "metricKey": "new_coverage", "actualValue": "60", "comparator": "LT", "errorThreshold": "80"},
        {"status": "OK", "metricKey": "new_bugs"}]})
    assert passed is False
    assert failed == ["new_coverage: actual 60 vs threshold LT 80"]
    assert sonar.evaluate_gate({"status": "OK"})[0] is True


# ---------- git hand-off (real git in a temp repo)
@pytest.fixture
def repo(tmp_path, monkeypatch):
    def run(*args):
        subprocess.run(["git", *args], cwd=tmp_path, check=True, capture_output=True)
    run("init", "-q")
    run("config", "user.email", "t@example.com")
    run("config", "user.name", "t")
    (tmp_path / "a.py").write_text("x = 1\ny = 2\n")
    run("add", ".")
    run("commit", "-qm", "init")
    monkeypatch.setattr(gitops, "ROOT", tmp_path)
    return tmp_path


def test_patch_roundtrip_and_risky_detection(repo, tmp_path_factory):
    base = gitops.head_sha()
    (repo / "a.py").write_text("x = 10\n")
    (repo / "b.py").write_text("z = 3\n")
    (repo / "out").mkdir()
    (repo / "out" / "plan.md").write_text("not part of the change")

    patch = gitops.snapshot_patch(base)
    assert b"out/plan.md" not in patch
    stats = gitops.changed_files_stats(base)
    assert {r["path"] for r in stats} == {"a.py", "b.py"}
    assert [r["path"] for r in gitops.risky_changes(stats)] == ["a.py"]

    # A fresh checkout at the same commit reproduces the change from the patch.
    patch_file = tmp_path_factory.mktemp("p") / "changes.patch"
    patch_file.write_bytes(patch)
    gitops.git("reset", "-q", "--hard", base)
    gitops.git("clean", "-qfd", "-e", "out")
    gitops.apply_patch(patch_file)
    assert (repo / "a.py").read_text() == "x = 10\n"
    assert (repo / "b.py").read_text() == "z = 3\n"


def test_summary_mentions_pr_and_gates():
    text = build_summary({"id": 5, "title": "T"}, {"url": "https://gh/pr/1", "head": "h", "base": "b"},
                         {"coverage_pct": 91.0, "coverage_threshold": 85}, {"status": "passed"}, "- step")
    assert "https://gh/pr/1" in text and "91.0%" in text and "passed" in text


def test_misplaced_architecture_file_is_moved_to_the_repo_root(tmp_path, monkeypatch):
    import subprocess
    monkeypatch.setattr(gitops, "ROOT", tmp_path)
    monkeypatch.setattr(gitops, "is_external", lambda: False)
    run = lambda *a: subprocess.run(["git", *a], cwd=tmp_path, check=True, capture_output=True)
    run("init", "-q")
    run("config", "user.email", "[REDACTED_EMAIL_ADDRESS_2]")
    run("config", "user.name", "t")
    (tmp_path / "docs" / ".github").mkdir(parents=True)
    (tmp_path / "docs" / ".github" / "project-architecture.md").write_text("old, committed", encoding="utf-8")
    run("add", "-A")
    run("commit", "-qm", "base")
    base = gitops.head_sha()
    (tmp_path / "backend" / ".github").mkdir(parents=True)
    (tmp_path / "backend" / ".github" / "project-architecture.md").write_text("by agent", encoding="utf-8")
    notes = gitops.fix_architecture_file(base, ".github/project-architecture.md")
    assert notes == ["moved backend/.github/project-architecture.md -> .github/project-architecture.md"]
    assert (tmp_path / ".github" / "project-architecture.md").read_text(encoding="utf-8") == "by agent"
    assert not (tmp_path / "backend" / ".github").exists()
    assert (tmp_path / "docs" / ".github" / "project-architecture.md").exists()   # committed file untouched
    (tmp_path / "api" / ".github").mkdir(parents=True)
    (tmp_path / "api" / ".github" / "project-architecture.md").write_text("dup", encoding="utf-8")
    assert gitops.fix_architecture_file(base, ".github/project-architecture.md") == [
        "removed duplicate api/.github/project-architecture.md (.github/project-architecture.md already exists)"]
    assert gitops.fix_architecture_file(base, ".github/project-architecture.md") == []
