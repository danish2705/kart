"""Step 6 re-run in external mode: the target repo is checked out with only its latest commit (shallow).
Real git repos in a temp folder (no network)."""
from __future__ import annotations

import shutil
import subprocess

import pytest

from dev_pipe import gitops

pytestmark = pytest.mark.skipif(shutil.which("git") is None, reason="git not installed")

BOT = "bot@example.com"
DEV = "dev@example.com"


def run(cwd, *args, email=DEV):
    return subprocess.run(["git", "-c", f"user.email={email}", "-c", "user.name=x", *args], cwd=cwd,
                          check=True, capture_output=True, text=True).stdout.strip()


@pytest.fixture
def remote(tmp_path):
    """Bare remote with main (3 developer commits) and an earlier pipeline branch feature/1-x = main + 1 bot commit;
    then main moves on by one more developer commit."""
    bare = tmp_path / "remote.git"
    run(tmp_path, "init", "-q", "--bare", "-b", "main", str(bare))
    dev = tmp_path / "dev"
    run(tmp_path, "clone", "-q", str(bare), str(dev))
    for i in range(3):
        (dev / f"f{i}").write_text(str(i))
        run(dev, "add", ".")
        run(dev, "commit", "-qm", f"c{i}")
    run(dev, "push", "-q", "origin", "HEAD:main")
    run(dev, "checkout", "-qb", "feature/1-x")
    run(dev, "commit", "-q", "--allow-empty", "-m", "pipeline run 1", email=BOT)
    run(dev, "push", "-q", "origin", "feature/1-x")
    run(dev, "checkout", "-q", "main")
    (dev / "f3").write_text("3")
    run(dev, "add", ".")
    run(dev, "commit", "-qm", "c3")
    run(dev, "push", "-q", "origin", "main")
    return bare, dev


def shallow_rerun(tmp_path, bare, monkeypatch):
    """What Step 6 does in external mode: depth-1 checkout of the (moved) base, new pipeline commit on the branch."""
    work = tmp_path / "target-checkout"
    work.mkdir()
    run(work, "init", "-q")
    run(work, "remote", "add", "origin", f"file://{bare}")
    run(work, "fetch", "-q", "--depth", "1", "origin", "main")
    run(work, "checkout", "-q", "--detach", "FETCH_HEAD")
    assert run(work, "rev-parse", "--is-shallow-repository") == "true"
    run(work, "config", "user.email", BOT)
    run(work, "checkout", "-qb", "feature/1-x")
    run(work, "commit", "-q", "--allow-empty", "-m", "pipeline run 2", email=BOT)
    monkeypatch.setattr(gitops, "_cwd", lambda: work)
    monkeypatch.setattr(gitops, "is_external", lambda: False)   # no token env needed for a local remote
    return work


def test_rerun_after_base_moved_replaces_the_pipeline_branch(tmp_path, remote, monkeypatch):
    bare, _ = remote
    work = shallow_rerun(tmp_path, bare, monkeypatch)
    assert gitops.push_branch("feature/1-x", "main") is True
    assert run(bare, "rev-parse", "feature/1-x") == run(work, "rev-parse", "HEAD")


def test_developer_commit_on_the_branch_still_blocks(tmp_path, remote, monkeypatch):
    bare, dev = remote
    run(dev, "fetch", "-q", "origin")
    run(dev, "checkout", "-q", "-b", "mine", "origin/feature/1-x")
    run(dev, "commit", "-q", "--allow-empty", "-m", "developer work")
    run(dev, "push", "-q", "origin", "HEAD:feature/1-x")
    shallow_rerun(tmp_path, bare, monkeypatch)
    with pytest.raises(SystemExit, match="Not overwriting"):
        gitops.push_branch("feature/1-x", "main")
