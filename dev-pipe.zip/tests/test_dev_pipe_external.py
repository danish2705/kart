"""Tests for external mode: repo/branch discovery (GitHub + AAVA faked), checkout and build commands.
No network, no LLM."""
from __future__ import annotations

import json
import subprocess
from datetime import datetime, timezone

import pytest

from dev_pipe import aava, build, config, gitops, resolver, workspace

NOW = datetime(2026, 10, 22, tzinfo=timezone.utc)
RECENT = "2026-10-15T10:00:00Z"
OLD = "2025-01-01T10:00:00Z"

STORY = {"id": 4321, "title": "Add refund status to payments API",
         "acceptance_criteria": "Refund status is returned for each payment", "description": "Customers see refunds"}


# ---------- fakes
class FakeGitHub:
    def __init__(self, repos, branches=None, compares=None, pulls=None):
        self.repos = {r["full_name"]: r for r in repos}
        self.branches = branches or {}          # full -> {name: date}
        self.compares = compares or {}          # (full, head) -> compare dict
        self.pulls = pulls or {}                # full -> [pr]

    def list_owner_repos(self, owner, limit=100):
        return [r for r in self.repos.values() if r["full_name"].startswith(owner + "/")]

    def get_repo(self, full):
        return self.repos.get(full)

    def list_branches(self, full, limit=100):
        return list(self.branches.get(full, {}))

    def get_branch(self, full, branch):
        date = self.branches.get(full, {}).get(branch)
        return None if date is None else {"name": branch, "sha": f"sha-{full}-{branch}", "date": date}

    def compare(self, full, base, head):
        return self.compares.get((full, head), {"ahead_by": 0, "files": [], "messages": []})

    def open_pulls(self, full, limit=100):
        return self.pulls.get(full, [])


class FakeAava:
    """scores: (repo, branch) -> similarity; indexed: set of (repo, branch) already indexed."""
    def __init__(self, scores, indexed=None):
        self.scores, self.triggered, self.searched = scores, [], []
        self.indexed = set(scores if indexed is None else indexed)

    def progress(self, owner, repo, branch):
        return {"state": "COMPLETED"} if (repo, branch) in self.indexed else None

    state_of = staticmethod(aava.Aava.state_of)

    def trigger_index(self, owner, repo, branch):
        self.triggered.append((repo, branch))
        self.indexed.add((repo, branch))
        return "TRIGGERED"

    def wait_until_done(self, targets, timeout, poll):
        return {t: "COMPLETED" for t in targets}

    def search(self, owner, repo, branch, query, intent="feature_flow", limit=5):
        self.searched.append((repo, branch))
        sim = self.scores.get((repo, branch), 0.0)
        return [{"filePath": f"docs/{repo}.md", "name": "Refunds", "startLine": 1, "endLine": 9,
                 "contentPreview": "refund status", "similarity": sim}] if sim else []


def repo(name, default="main", desc=""):
    return {"full_name": f"org/{name}", "name": name, "default_branch": default, "description": desc,
            "archived": False, "fork": False, "topics": []}


CFG = {"github_org": "org", "base_min_similarity": 0.75, "min_margin": 0.05, "repos_for_branch_scan": 2,
       "max_branches_scanned": 50, "branch_active_days": 60, "branch_shortlist": 3,
       "exclude_branch_patterns": ["dependabot/*"], "aava": {"index_missing": True}}


def make(gh, av, **cfg):
    return resolver.Resolver(gh, av, {**CFG, **cfg}, log=lambda *_: None, now=NOW)


# ---------- pure helpers
def test_story_queries_and_keywords():
    qs = resolver.story_queries(STORY)
    assert qs[0] == STORY["title"] and len(qs) == 3
    kw = resolver.story_keywords(STORY)
    assert {"refund", "payment", "status"} <= kw and "user" not in kw


def test_branch_signals_use_keywords_only():
    kw = resolver.story_keywords(STORY)
    score, ev = resolver.branch_signals(
        kw, "feature/refund-status",
        {"ahead_by": 2, "files": ["api/refund_service.py"], "messages": ["refund flow"]},
        [{"number": 7, "head": "feature/refund-status", "title": "Refund status", "body": ""}])
    assert score > 0 and any("PR #7" in e for e in ev)
    # a generic branch name and commit message is normal: score 0, no evidence, but no error
    assert resolver.branch_signals(kw, "feature/sprint-12", {"files": [], "messages": ["fix"]}, []) == (0, [])


def test_decide_threshold_and_margin():
    a, b = {"similarity": 0.9}, {"similarity": 0.88}
    assert resolver.decide([a, b], 0.75, 0.05) == (a, "low")
    assert resolver.decide([a, {"similarity": 0.5}], 0.75, 0.05) == (a, "high")
    assert resolver.decide([{"similarity": 0.5}], 0.75, 0.05) == (None, "none")


def test_excluded_repo_patterns():
    assert resolver.excluded("sandbox-x", ["sandbox-*"]) and not resolver.excluded("payments", ["sandbox-*"])


# ---------- resolver scenarios
def test_found_on_base_branch_of_best_repo():
    gh = FakeGitHub([repo("payments"), repo("web")],
                    branches={"org/payments": {"main": RECENT}, "org/web": {"main": RECENT}})
    av = FakeAava({("payments", "main"): 0.86, ("web", "main"): 0.40})
    t = make(gh, av).resolve(STORY)
    assert (t["full_name"], t["base_branch"], t["found_on"], t["confidence"]) == ("org/payments", "main", "base", "high")
    assert t["base_sha"] == "sha-org/payments-main" and t["matches"]


def test_preferred_base_branch_used_when_it_exists():
    gh = FakeGitHub([repo("payments")], branches={"org/payments": {"main": RECENT, "develop": RECENT}})
    av = FakeAava({("payments", "develop"): 0.9})
    assert make(gh, av, base_branch="develop").resolve(STORY)["base_branch"] == "develop"


def test_missing_index_is_triggered():
    gh = FakeGitHub([repo("payments")], branches={"org/payments": {"main": RECENT}})
    av = FakeAava({("payments", "main"): 0.9}, indexed=set())
    make(gh, av).resolve(STORY)
    assert ("payments", "main") in av.triggered


def test_not_on_base_found_on_feature_branch():
    gh = FakeGitHub(
        [repo("payments", desc="payments service"), repo("web")],
        branches={"org/payments": {"main": RECENT, "feature/refunds": RECENT, "feature/old": OLD,
                                   "dependabot/x": RECENT, "feature/unrelated": RECENT},
                  "org/web": {"main": RECENT}},
        compares={("org/payments", "feature/refunds"): {"ahead_by": 3, "files": ["docs/refund.md"],
                                                             "messages": ["refund draft"]},
                  ("org/payments", "feature/unrelated"): {"ahead_by": 1, "files": ["x.md"], "messages": ["chore"]}})
    av = FakeAava({("payments", "main"): 0.41, ("web", "main"): 0.2, ("payments", "feature/refunds"): 0.82},
                  indexed={("payments", "main"), ("web", "main")})
    t = make(gh, av).resolve(STORY)
    assert (t["full_name"], t["base_branch"], t["found_on"], t["confidence"]) == \
        ("org/payments", "feature/refunds", "branch", "high")
    assert ("payments", "feature/refunds") in av.triggered          # branch indexed on demand
    # no filtering: old, bot and unrelated branches are all indexed and searched too
    for b in ("feature/old", "dependabot/x", "feature/unrelated"):
        assert ("payments", b) in av.searched


def test_branch_without_any_keyword_is_still_searched():
    """Generic branch names / commit messages: the code is found by AAVA on a recent branch."""
    gh = FakeGitHub(
        [repo("payments")],
        branches={"org/payments": {"main": RECENT, "feature/sprint-12": "2026-10-20T10:00:00Z",
                                   "feature/misc": "2026-09-01T10:00:00Z", "feature/merged": RECENT}},
        compares={("org/payments", "feature/sprint-12"): {"ahead_by": 4, "files": ["src/a.py"], "messages": ["wip"]},
                  ("org/payments", "feature/misc"): {"ahead_by": 1, "files": ["b.py"], "messages": ["fix"]}})
    av = FakeAava({("payments", "main"): 0.3, ("payments", "feature/sprint-12"): 0.8},
                  indexed={("payments", "main")})
    t = make(gh, av).resolve(STORY)
    assert (t["base_branch"], t["found_on"]) == ("feature/sprint-12", "branch")
    assert ("payments", "feature/merged") in av.searched          # no filtering: every branch is searched


def test_all_branches_searched_and_listed_when_nothing_qualifies():
    names = ["a", "b", "c", "d", "feature/refund", "old-branch"]
    gh = FakeGitHub([repo("payments")],
                    branches={"org/payments": {"main": RECENT, **{n: (OLD if n == "old-branch" else RECENT) for n in names}}})
    av = FakeAava({("payments", "main"): 0.1, ("payments", "c"): 0.6}, indexed={("payments", "main")})
    t = make(gh, av).resolve(STORY)
    searched = {b for r, b in av.searched if b != "main"}
    assert searched == set(names)                                 # every branch, no cap, no age filter
    assert set(names) <= {b for r, b in av.triggered}             # all indexed on demand
    assert t["confidence"] == "low" and t["base_branch"] == "main"
    assert t["alternatives"][0]["branch"] == "c"                  # best-scoring branch shown first to the reviewer
    assert {a["branch"] for a in t["alternatives"]} >= set(names)


def test_nothing_found_falls_back_to_most_likely_repo_with_low_confidence():
    gh = FakeGitHub([repo("payments"), repo("web")],
                    branches={"org/payments": {"main": RECENT}, "org/web": {"main": RECENT}})
    av = FakeAava({("payments", "main"): 0.5, ("web", "main"): 0.3})
    t = make(gh, av).resolve(STORY)
    assert (t["full_name"], t["confidence"]) == ("org/payments", "low")


def test_no_signal_anywhere_stops_with_instructions():
    gh = FakeGitHub([repo("alpha"), repo("beta")],
                    branches={"org/alpha": {"main": RECENT}, "org/beta": {"main": RECENT}})
    with pytest.raises(SystemExit) as err:
        make(gh, FakeAava({})).resolve(STORY)
    assert "target_repo" in str(err.value)


def test_manual_override_skips_detection():
    gh = FakeGitHub([repo("payments"), repo("web")],
                    branches={"org/web": {"main": RECENT, "release/2": RECENT}})
    t = make(gh, FakeAava({})).resolve(STORY, "org/web", "release/2")
    assert (t["full_name"], t["base_branch"], t["confidence"]) == ("org/web", "release/2", "manual")


def test_include_list_limits_candidates():
    gh = FakeGitHub([repo("payments"), repo("web")], branches={"org/web": {"main": RECENT}})
    r = make(gh, FakeAava({}), include_repos=["web"])
    assert [x["full_name"] for x in r.candidate_repos()] == ["org/web"]


def test_code_context_formats_matches():
    text = resolver.code_context({"matches": [{"filePath": "a.md", "startLine": 1, "endLine": 3, "name": "H",
                                               "contentPreview": "body", "similarity": 0.8}]})
    assert "a.md:1-3" in text and "body" in text
    assert "no matches" in resolver.code_context({})


# ---------- AAVA client parsing
@pytest.mark.parametrize("payload", [
    {"status": "SUCCESS", "data": {"matches": [{"filePath": "a.md", "similarity": 0.5}, {"filePath": "b.md", "similarity": 0.9}]}},
    {"data": [{"filePath": "a.md", "similarity": 0.5}, {"filePath": "b.md", "similarity": 0.9}]},
    {"results": [{"filePath": "a.md", "score": 0.5}, {"filePath": "b.md", "score": 0.9}]},
])
def test_normalize_matches_accepts_shapes(payload):
    m = aava.normalize_matches(payload)
    assert [x["filePath"] for x in m] == ["b.md", "a.md"]


def test_wait_until_done_times_out():
    t = {"now": 0.0}
    client = aava.Aava("http://x", sleep=lambda s: t.__setitem__("now", t["now"] + s), clock=lambda: t["now"])
    client.progress = lambda *a: {"state": "RUNNING"}
    states = client.wait_until_done([("o", "r", "main")], timeout=30, poll=10)
    assert states[("o", "r", "main")].startswith("TIMEOUT")


def test_search_sends_token_and_string_query():
    sent = {}

    class Resp:
        status_code, content = 200, b"{}"

        def json(self):
            return {"data": {"matches": []}}

    class Session:
        def post(self, url, json=None, timeout=None):
            sent.update(json)
            return Resp()

    aava.Aava("http://x", github_token="tok", session=Session()).search("o", "r", "main", None)
    assert sent["query"] == "" and sent["githubToken"] == "tok" and sent["branch"] == "main"


# ---------- token handling
def test_token_removed_from_environment_and_not_in_plain_text(monkeypatch):
    monkeypatch.setattr(workspace, "_token", None)
    monkeypatch.setenv("TARGET_GITHUB_TOKEN", "secret123")
    assert workspace.take_token() == "secret123"
    import os
    assert "TARGET_GITHUB_TOKEN" not in os.environ
    env = workspace.git_auth_env()
    assert "secret123" not in json.dumps(env) and env["GIT_CONFIG_KEY_0"].endswith(".extraheader")


# ---------- config in external mode
def test_target_settings_external_applies_overrides(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "OUT", tmp_path)
    (tmp_path / "target.json").write_text(json.dumps({"full_name": "org/web"}))
    monkeypatch.setitem(config.settings(), "target", {
        "mode": "external", "app_dir": "sample_app", "app_package": "app", "test_dir": "tests",
        "architecture_file": "a.md",
        "overrides": {"org/web": {"language": "node", "build_commands": ["npm test"], "test_dir": ""}}})
    t = config.target_settings()
    assert t["app_dir"] == "." and t["language"] == "node" and t["build_commands"] == ["npm test"]
    assert t["test_dir"] == "tests"                      # empty override values are ignored
    assert config.work_root() == config.TARGET_CHECKOUT


# ---------- build commands
def test_run_build_with_commands(tmp_path):
    ok, log = build.run_build(tmp_path, "tests", ["echo hello", "exit 3", "echo never"])
    assert ok is False and "hello" in log and "exit 3" in log and "never" not in log
    assert build.run_build(tmp_path, "tests", ["echo ok"])[0] is True
    assert "npm test" in build.build_check_text({"app_dir": ".", "test_dir": "t", "build_commands": ["npm test"]})


# ---------- checkout of the target repo (real git, local "remote")
def test_prepare_checkout_and_patch_in_target(tmp_path, monkeypatch):
    def run(*args, cwd):
        return subprocess.run(["git", *args], cwd=cwd, check=True, capture_output=True, text=True).stdout.strip()

    src = tmp_path / "src"
    src.mkdir()
    run("init", "-q", cwd=src)
    run("config", "user.email", "t@example.com", cwd=src)
    run("config", "user.name", "t", cwd=src)
    (src / "a.py").write_text("x = 1\n")
    run("add", ".", cwd=src)
    run("commit", "-qm", "init", cwd=src)
    sha = run("rev-parse", "HEAD", cwd=src)
    remote = tmp_path / "server" / "org" / "web.git"
    remote.parent.mkdir(parents=True)
    run("clone", "-q", "--bare", str(src), str(remote), cwd=tmp_path)
    run("config", "uploadpack.allowAnySHA1InWant", "true", cwd=remote)

    checkout = tmp_path / "root" / ".target"
    monkeypatch.setattr(workspace, "TARGET_CHECKOUT", checkout)
    monkeypatch.setattr(gitops, "TARGET_CHECKOUT", checkout)
    monkeypatch.setattr(workspace, "ROOT", config.ROOT)
    monkeypatch.setattr(workspace, "_token", "")
    monkeypatch.setitem(config.settings()["target"], "mode", "external")
    monkeypatch.setenv("GITHUB_SERVER_URL", f"file://{tmp_path / 'server'}")

    def _git(*args, cwd=checkout, auth=False):
        return run(*args, cwd=cwd)
    monkeypatch.setattr(workspace, "_git", _git)

    workspace.prepare_checkout({"full_name": "org/web", "base_sha": sha, "base_branch": "main"})
    assert (checkout / "a.py").read_text() == "x = 1\n"
    assert gitops.head_sha() == sha
    # agent skills are copied in but never become part of the change set
    assert (checkout / ".claude" / "skills").exists()
    (checkout / "a.py").write_text("x = 2\n")
    patch = gitops.snapshot_patch(sha)
    assert b"a.py" in patch and b".claude" not in patch
    workspace.prepare_checkout({"full_name": "org/web", "base_sha": sha, "base_branch": "main"})  # idempotent


def test_prepare_full_clone_has_history_and_branches(tmp_path, monkeypatch):
    """Step 7 scans from a regular full clone: full history (not shallow) and remote-tracking
    refs for every branch, so the Sonar scanner can diff the PR against its base."""
    def run(*args, cwd):
        return subprocess.run(["git", *args], cwd=cwd, check=True, capture_output=True, text=True).stdout.strip()

    src = tmp_path / "src"
    src.mkdir()
    run("init", "-q", "-b", "main", cwd=src)
    run("config", "user.email", "[REDACTED_EMAIL_ADDRESS_1]", cwd=src)
    run("config", "user.name", "t", cwd=src)
    (src / "a.py").write_text("x = 1\n")
    run("add", ".", cwd=src)
    run("commit", "-qm", "init", cwd=src)
    run("checkout", "-qb", "feature/x", cwd=src)
    (src / "a.py").write_text("x = 2\n")
    run("commit", "-qam", "change", cwd=src)
    remote = tmp_path / "server" / "org" / "web.git"
    remote.parent.mkdir(parents=True)
    run("clone", "-q", "--bare", str(src), str(remote), cwd=tmp_path)

    checkout = tmp_path / "root" / ".target"
    checkout.mkdir(parents=True)
    (checkout / "stale.txt").write_text("old shallow checkout")
    monkeypatch.setattr(workspace, "TARGET_CHECKOUT", checkout)
    monkeypatch.setattr(workspace, "_token", "")
    monkeypatch.setitem(config.settings()["target"], "mode", "external")
    monkeypatch.setenv("GITHUB_SERVER_URL", f"file://{tmp_path / 'server'}")

    workspace.prepare_full_clone({"full_name": "org/web", "base_sha": "", "base_branch": "main"})
    assert not (checkout / "stale.txt").exists()
    assert run("rev-parse", "--is-shallow-repository", cwd=checkout) == "false"
    refs = run("branch", "-r", cwd=checkout)
    assert "origin/main" in refs and "origin/feature/x" in refs
    assert "a.py" in run("diff", "--name-only", "origin/main...origin/feature/x", cwd=checkout)
    assert "@" not in run("remote", "get-url", "origin", cwd=checkout)  # no credentials in the URL
