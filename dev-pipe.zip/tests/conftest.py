"""Shared test setup."""
import pytest


@pytest.fixture(autouse=True)
def _step_logs_in_tmp(tmp_path, monkeypatch):
    """Step logs (dev_pipe/steplog.py) record to out/steps.json; keep tests from writing into the repo's out/."""
    from dev_pipe import steplog
    monkeypatch.setattr(steplog, "OUT", tmp_path / "steplog-out")
    monkeypatch.delenv("GITHUB_STEP_SUMMARY", raising=False)
