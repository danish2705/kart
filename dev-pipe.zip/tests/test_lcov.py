import os
import time

from dev_pipe.lcov import find_lcov_reports, line_coverage, report_paths_arg

LCOV = "TN:\nSF:src/a.ts\nLF:10\nLH:8\nend_of_record\nSF:src/b.ts\nLF:10\nLH:2\nend_of_record\n"


def _write(path, text=LCOV):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path


def test_finds_reports_and_skips_node_modules(tmp_path):
    fe = _write(tmp_path / "frontend" / "coverage" / "lcov.info")
    _write(tmp_path / "frontend" / "node_modules" / "pkg" / "coverage" / "lcov.info")
    _write(tmp_path / "frontend" / "lcov.info")  # not inside a coverage/ folder
    assert find_lcov_reports(tmp_path) == [fe]


def test_newer_than_ignores_stale_reports(tmp_path):
    stale = _write(tmp_path / "backend" / "coverage" / "lcov.info")
    old = time.time() - 3600
    os.utime(stale, (old, old))
    fresh = _write(tmp_path / "frontend" / "coverage" / "lcov.info")
    assert find_lcov_reports(tmp_path, newer_than=time.time() - 60) == [fresh]


def test_report_written_right_after_start_is_found(tmp_path):
    started = time.time()
    fresh = _write(tmp_path / "coverage" / "lcov.info")
    assert find_lcov_reports(tmp_path, newer_than=started) == [fresh]


def test_line_coverage_sums_all_files_and_reports(tmp_path):
    a = _write(tmp_path / "a" / "coverage" / "lcov.info")                        # 10 / 20
    b = _write(tmp_path / "b" / "coverage" / "lcov.info", "SF:x\nLF:20\nLH:20\n")  # 20 / 20
    assert line_coverage([a]) == 50.0
    assert line_coverage([a, b]) == 75.0


def test_line_coverage_none_when_no_lines(tmp_path):
    empty = _write(tmp_path / "coverage" / "lcov.info", "TN:\n")
    assert line_coverage([empty]) is None
    assert line_coverage([]) is None


def test_report_paths_are_relative_posix(tmp_path):
    r = _write(tmp_path / "frontend" / "coverage" / "lcov.info")
    assert report_paths_arg([r], tmp_path) == "frontend/coverage/lcov.info"


def test_finds_angular_cli_report_in_a_project_subfolder(tmp_path):
    ng = _write(tmp_path / "coverage" / "my-app" / "lcov.info")            # ng test --code-coverage
    _write(tmp_path / "src" / "deep" / "x" / "lcov.info")                    # not a coverage folder
    assert find_lcov_reports(tmp_path) == [ng]
