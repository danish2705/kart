"""Workflow/setup optimisations: concurrency per story, bundled Claude CLI, cached Sonar scanner, Node only where
needed, Step 5's early Sonar check, uploads on failure. No network."""
from __future__ import annotations

import pathlib

import pytest
import yaml

from dev_pipe import config
from dev_pipe.steps import sonar_needed as sn

WF = pathlib.Path(".github/workflows/dev-pipe.yml")
ACTION = pathlib.Path(".github/actions/setup-dev-pipe/action.yml")


@pytest.fixture
def sonar_cfg(monkeypatch):
    def set_cfg(enabled: bool, required: bool, token: bool = True, host: str = "https://sonarcloud.io",
                key: str = "proj"):
        monkeypatch.setattr(config, "_settings", {"sonar": {"enabled": enabled, "precheck": {"required": required}},
                                                  "target": {"mode": "local"}})
        monkeypatch.setenv("SONAR_TOKEN_PRESENT", "true" if token else "false")
        monkeypatch.delenv("SONAR_TOKEN", raising=False)
        monkeypatch.setenv("SONAR_HOST_URL", host)
        monkeypatch.setenv("SONAR_PROJECT_KEY", key)
        monkeypatch.delenv("TARGET_MODE", raising=False)
    return set_cfg


# ---------- Step 5 early check
def test_sonar_enabled_needs_full_setup(sonar_cfg):
    sonar_cfg(enabled=True, required=True)
    assert sn.needed()[0] is True


def test_sonar_off_and_optional_skips_setup(sonar_cfg):
    sonar_cfg(enabled=False, required=False)
    assert sn.needed()[0] is False


def test_sonar_off_but_required_still_runs_the_step(sonar_cfg):
    sonar_cfg(enabled=False, required=True)
    assert sn.needed()[0] is True


def test_missing_token_and_optional_skips(sonar_cfg):
    sonar_cfg(enabled=True, required=False, token=False)
    assert sn.needed()[0] is False


def test_any_error_means_full_setup(monkeypatch):
    def boom():
        raise RuntimeError("no yaml")
    monkeypatch.setattr(config, "settings", boom)
    assert sn.needed()[0] is True


def test_output_written(sonar_cfg, tmp_path, monkeypatch):
    sonar_cfg(enabled=False, required=False)
    out = tmp_path / "out.txt"
    monkeypatch.setenv("GITHUB_OUTPUT", str(out))
    sn.main()
    assert out.read_text() == "needed=false\n"


# ---------- workflow wiring
def jobs():
    return yaml.safe_load(WF.read_text())["jobs"]


def setup_inputs(job: dict) -> dict:
    return next(s["with"] for s in job["steps"] if s.get("uses") == "./.github/actions/setup-dev-pipe")


def test_concurrency_is_per_story():
    wf = yaml.safe_load(WF.read_text())
    assert "work_item_id" in wf["concurrency"]["group"] and "TEST_WORK_ITEM_ID" in wf["concurrency"]["group"]


def test_node_only_in_jobs_that_build_or_scan():
    j = jobs()
    for name in ("implement", "test-gates", "quality-gate"):
        assert setup_inputs(j[name]).get("node") == "true", name
    assert setup_inputs(j["sonar-precheck"]).get("node") == "${{ steps.sonar.outputs.needed }}"
    for name in ("plan", "create-pr", "ado-complete", "notify-failure"):
        assert "node" not in setup_inputs(j[name]), name


def test_step5_checks_before_setup():
    steps = jobs()["sonar-precheck"]["steps"]
    order = [s.get("id") or s.get("uses", "") for s in steps]
    assert order.index("sonar") < order.index("./.github/actions/setup-dev-pipe")
    check = next(s for s in steps if s.get("id") == "sonar")
    assert "secrets.SONAR_TOKEN" not in str(check.get("env", {})).replace("secrets.SONAR_TOKEN != ''", "")


def test_plan_and_create_pr_upload_on_failure():
    j = jobs()
    for name in ("plan", "create-pr"):
        upload = next(s for s in j[name]["steps"] if s.get("uses") == "./.github/actions/save-stage")
        assert upload.get("if") == "always()", name


def test_setup_uses_bundled_cli_and_cached_scanner():
    text = ACTION.read_text()
    steps = yaml.safe_load(text)["runs"]["steps"]
    npm = next(s for s in steps if "npm install" in s.get("run", ""))
    assert "bundled != 'true'" in npm["if"]                         # npm only as fallback
    assert "CLI_VERSION" in npm["run"]                              # pinned to the SDK's CLI version
    assert any(s.get("uses") == "actions/cache@v4" and "sonar-scanner" in s["with"]["key"] for s in steps)
    download = next(s for s in steps if "binaries.sonarsource.com" in s.get("run", ""))
    assert "cache-hit != 'true'" in download["if"]
    node = [s for s in steps if s.get("uses") == "actions/setup-node@v4"]
    assert all("if" in s for s in node)                             # never unconditional
