"""Tests for the comment-triggered approval (APPROVAL_MODE=comment, dev_pipe/steps/gate_comment.py).
No network: GitHub is faked."""
from __future__ import annotations

import json
import pathlib

import pytest
import yaml

from dev_pipe.steps import gate_comment as gc


class FakeGitHub:
    def __init__(self, run_path=".github/workflows/dev-pipe.yml@refs/heads/feature/dev-pipe"):
        self.run_path = run_path
        self.created, self.comments, self.closed = [], [], []

    def create_issue(self, title, body):
        self.created.append((title, body))
        return {"number": 9, "html_url": "https://github.com/o/r/issues/9"}

    def comment(self, number, body):
        self.comments.append((number, body))

    def close(self, number, completed):
        self.closed.append((number, completed))

    def get_run(self, run_id):
        return {"path": self.run_path, "head_sha": "abc123", "html_url": f"https://github.com/o/r/actions/runs/{run_id}"}


@pytest.fixture
def out_dir(tmp_path, monkeypatch):
    out = tmp_path / "out"
    out.mkdir()
    (out / "story.json").write_text(json.dumps({"id": 101, "title": "Add /concat"}))
    (out / "summary.md").write_text("- Step 3: implemented 1 file")
    monkeypatch.setenv("APPROVERS", "alice")
    monkeypatch.setenv("APPROVAL_TIMEOUT_MINUTES", "30")
    monkeypatch.setenv("GITHUB_RUN_ID", "555")
    monkeypatch.setenv("GITHUB_REPOSITORY", "o/r")
    monkeypatch.setenv("DRY_RUN", "false")
    monkeypatch.delenv("GITHUB_OUTPUT", raising=False)
    return out


def event(login, body, issue_body="", number=9):
    return {"issue": {"number": number, "body": issue_body}, "comment": {"user": {"login": login}, "body": body}}


def test_prepare_records_approvers_timeout_and_dry_run(out_dir):
    req = gc.prepare("approve-ado-update", out_dir, now=lambda: 1000.0)
    saved = json.loads((out_dir / gc.REQUEST_FILE).read_text())
    assert saved == req
    assert req["approvers"] == ["alice"] and req["timeout_minutes"] == 30
    assert req["dry_run"] == "false" and req["run_id"] == "555"


def test_prepare_fails_fast(out_dir, monkeypatch):
    with pytest.raises(SystemExit):
        gc.prepare("approve-everything", out_dir)
    monkeypatch.setenv("APPROVERS", "")
    with pytest.raises(SystemExit):
        gc.prepare("approve-ado-update", out_dir)


def test_dry_run_unless_explicitly_false(out_dir, monkeypatch):
    monkeypatch.delenv("DRY_RUN")
    assert gc.prepare("approve-ado-update", out_dir)["dry_run"] == "true"


def test_open_issue_carries_marker_and_does_not_wait(out_dir):
    gc.prepare("approve-ado-update", out_dir)
    gh = FakeGitHub()
    gc.open_issue(out_dir, gh=gh)
    title, body = gh.created[0]
    assert title.startswith("[Dev Pipeline]") and "#101" in title
    assert gc.marker("555") in body and "No runner waits" in body and "@alice" in body
    assert gc.MARKER_RE.search(body).group(1) == "555"


def test_locate_accepts_only_dev_pipe_runs():
    body = "...\n" + gc.marker("555")
    assert gc.locate(event("alice", "approve", body), gh=FakeGitHub())["run_id"] == "555"
    assert gc.locate(event("alice", "approve", body), gh=FakeGitHub(".github/workflows/other.yml"))["found"] is False
    assert gc.locate(event("alice", "approve", "no marker"), gh=FakeGitHub())["found"] is False


def test_approve_by_allowed_approver(out_dir):
    gc.prepare("approve-ado-update", out_dir, now=lambda: 1000.0)
    gh = FakeGitHub()
    assert gc.decide_comment(event("Alice", "approve"), out_dir, gh=gh, now=lambda: 1060.0) == "approve"
    assert gh.closed == [(9, True)] and "Approved by @Alice" in gh.comments[0][1]


def test_reject_closes_issue(out_dir):
    gc.prepare("approve-ado-update", out_dir, now=lambda: 1000.0)
    gh = FakeGitHub()
    assert gc.decide_comment(event("alice", "reject: wrong file"), out_dir, gh=gh, now=lambda: 1001.0) == "reject"
    assert gh.closed == [(9, False)] and "wrong file" in gh.comments[0][1]


def test_other_people_and_chatter_are_ignored(out_dir):
    gc.prepare("approve-ado-update", out_dir, now=lambda: 1000.0)
    gh = FakeGitHub()
    assert gc.decide_comment(event("mallory", "approve"), out_dir, gh=gh, now=lambda: 1001.0) == "none"
    assert gc.decide_comment(event("alice", "looking now"), out_dir, gh=gh, now=lambda: 1001.0) == "none"
    assert gh.comments == [] and gh.closed == []


def test_late_answer_is_refused(out_dir):
    gc.prepare("approve-ado-update", out_dir, now=lambda: 1000.0)
    gh = FakeGitHub()
    assert gc.decide_comment(event("alice", "approve"), out_dir, gh=gh, now=lambda: 1000.0 + 31 * 60) == "expired"
    assert gh.closed == [(9, False)] and "expired" in gh.comments[0][1]


def test_outputs_written_for_the_workflow(out_dir, tmp_path, monkeypatch):
    output = tmp_path / "gh_output"
    monkeypatch.setenv("GITHUB_OUTPUT", str(output))
    gc.prepare("approve-ado-update", out_dir, now=lambda: 1000.0)
    gc.decide_comment(event("alice", "approve"), out_dir, gh=FakeGitHub(), now=lambda: 1001.0)
    assert "decision=approve" in output.read_text() and "dry_run=false" in output.read_text()


# ---------- workflow wiring
WF = pathlib.Path(".github/workflows")


def test_pipeline_has_both_approval_modes_and_dry_run_skip():
    jobs = yaml.safe_load((WF / "dev-pipe.yml").read_text())["jobs"]
    assert "APPROVAL_MODE != 'comment'" in jobs["gate-ado"]["if"]
    assert "APPROVAL_MODE == 'comment'" in jobs["request-ado-approval"]["if"]
    assert "'false'" in jobs["quality-gate"]["if"]   # Step 7 skipped in a dry run
    steps = jobs["request-ado-approval"]["steps"]
    names = [s.get("run", "") + str(s.get("uses", "")) for s in steps]
    upload = next(i for i, n in enumerate(names) if "save-stage" in n)
    opened = next(i for i, n in enumerate(names) if "gate_comment open" in n)
    assert upload < opened   # artifact exists before anyone can approve


def test_decision_workflow_only_gives_ado_pat_to_step_8():
    wf = yaml.safe_load((WF / "dev-pipe-approval-decision.yml").read_text())
    text = (WF / "dev-pipe-approval-decision.yml").read_text()
    assert text.count("secrets.ADO_PAT") == 1
    assert "ADO_PAT" not in json.dumps(wf["jobs"]["decide"])
    assert wf["jobs"]["ado-complete"]["if"] == "${{ needs.decide.outputs.decision == 'approve' }}"
