"""Readable step logs + pipeline report (dev_pipe/steplog.py)."""
from __future__ import annotations

import json

import pytest

from dev_pipe import steplog
from dev_pipe.steplog import StepLog, build_report, counts_text, story_lines, trigger_text
from dev_pipe.steplog import test_counts as count_tests

STORY = {"id": 118377, "type": "User Story", "state": "New", "title": "Show the app version",
         "assigned_to": "person@example.com", "iteration_path": "POC\\Sprint 12", "area_path": "POC",
         "description": "As a support engineer...", "acceptance_criteria": "1. First\n- Second\n\n3) Third"}


def test_story_block_has_no_personal_names(monkeypatch):
    monkeypatch.setenv("ADO_ORG_URL", "https://dev.azure.com/org")
    monkeypatch.setenv("ADO_PROJECT", "proj")
    text = "\n".join(story_lines(STORY))
    assert "person@example.com" not in text and "Assigned            : yes" in text
    assert "Acceptance criteria (3):" in text and "  2. Second" in text
    assert "https://dev.azure.com/org/proj/_workitems/edit/118377" in text


def test_trigger_text_has_no_actor(monkeypatch):
    monkeypatch.setenv("GITHUB_EVENT_NAME", "push")
    monkeypatch.setenv("GITHUB_REF_NAME", "feature/dev-pipe")
    monkeypatch.setenv("GITHUB_RUN_NUMBER", "12")
    monkeypatch.setenv("GITHUB_ACTOR", "someone")
    text = trigger_text()
    assert text.startswith("push to feature/dev-pipe | run #12 |") and "someone" not in text


def test_step_block_and_report(tmp_path, capsys, monkeypatch):
    monkeypatch.setenv("DRY_RUN", "false")
    monkeypatch.setenv("GITHUB_ACTIONS", "true")
    (tmp_path / "story.json").write_text(json.dumps(STORY), encoding="utf-8")
    with StepLog("3", "Write the code", out_dir=tmp_path) as log:
        print("[agent] noisy technical line")
        log.heading("Azure DevOps")
        log.ok('Story #118377 moved from "New" to "Active".')
        log.detail("Both tasks copy the story's assignee and sprint.")
        log.fact("1 file(s) changed")
        log.metric("fix_rounds", 2)
        log.result("PASSED", next_step="The AI writes tests and we check quality (Step 4).")
    out = capsys.readouterr().out
    # technical output is folded away, the readable block comes after it
    assert out.index("::group::Step 3 technical details") < out.index("[agent] noisy") < out.index("::endgroup::")
    block = out[out.index("::endgroup::"):]
    assert "==================== STEP 3: WRITE THE CODE ====================" in block
    assert "AZURE DEVOPS" in block and '\u2714 Story #118377 moved from "New" to "Active".' in block
    assert "What happens here" not in out
    assert "Result  : PASSED in" in block and "Next    : The AI writes tests" in block
    steps = json.loads((tmp_path / "steps.json").read_text())
    assert steps[0]["result"] == "PASSED" and steps[0]["metrics"]["fix_rounds"] == 2
    report = (tmp_path / "pipeline-report.md").read_text()
    assert 'Story        : #118377 "Show the app version"' in report
    assert "3   Code" in report and "\u2714 PASSED" in report and "2 fix round(s) needed" in report


def test_failure_is_logged_and_reraised(tmp_path, capsys):
    with pytest.raises(SystemExit):
        with StepLog("5", "Quality and security check", out_dir=tmp_path):
            raise SystemExit("still failing after 3 fix attempts")
    out = capsys.readouterr().out
    assert "\u2718 Stopped: still failing after 3 fix attempts" in out
    assert "Result  : FAILED" in out
    assert "STOPPED AT STEP 5" in (tmp_path / "pipeline-report.md").read_text()


def test_rerun_replaces_row_and_rows_are_ordered(tmp_path):
    for key, num in (("5", "5"), ("1-2", "1-2"), ("8-approval", "8"), ("8-ado", "8"), ("5", "5")):
        steplog.record_step(key, num, f"step {key}", "PASSED", out=tmp_path)
    steps = json.loads((tmp_path / "steps.json").read_text())
    assert len(steps) == 4
    report = build_report(steps, tmp_path)
    assert report.index("1-2 Plan") < report.index("5   Quality check") < report.index("8   Approval") \
        < report.index("8   ADO update")
    assert "RESULT: COMPLETED" in report


@pytest.mark.parametrize("text,expected", [
    ("14 passed in 0.52s", (14, 0, 0)),
    ("==== 3 failed, 10 passed, 1 skipped in 2.1s ====", (10, 3, 1)),
    ("      Tests  5 passed (5)\n Test Files  1 passed (1)", (5, 0, 0)),
    ("Tests:       2 failed, 5 passed, 7 total", (5, 2, 0)),
    ("Passed!  - Failed:     0, Passed:    12, Skipped:     1, Total: 13", (12, 0, 1)),
])
def test_test_counts(text, expected):
    c = count_tests(text)
    assert (c["passed"], c["failed"], c["skipped"]) == expected


def test_no_counts():
    assert count_tests("compiled fine") is None
    assert counts_text(None).startswith("n/a")


def test_quality_gate_table():
    from dev_pipe.steps.s8_sonarqube_quality_validation import gate_table
    rows = gate_table({"status": "OK", "conditions": [
        {"metricKey": "new_coverage", "comparator": "LT", "errorThreshold": "80", "actualValue": "95.0", "status": "OK"},
        {"metricKey": "new_reliability_rating", "comparator": "GT", "errorThreshold": "1", "actualValue": "1",
         "status": "OK"}]})
    assert "Coverage on new code" in rows[1] and "95.0%" in rows[1] and ">= 80.0%" in rows[1] and rows[1].endswith("OK")
    assert "Reliability rating" in rows[2] and "<= A" in rows[2]


def test_new_test_names_and_test_paths():
    from dev_pipe.report_data import is_test_path, new_test_names
    diff = """+++ b/backend/tests/test_health.py
@@ -0,0 +1,5 @@
+def test_health_returns_version():
+    assert True
+async def test_health_default():
+++ b/frontend/src/App.test.jsx
@@ -1,0 +2,2 @@
+  it('shows the version', () => {})
+++ b/backend/app/main.py
@@ -1 +1 @@
+def test_not_a_test_file():
"""
    assert new_test_names(diff) == {"backend/tests/test_health.py": ["test_health_returns_version",
                                                                    "test_health_default"],
                                    "frontend/src/App.test.jsx": ["shows the version"]}
    assert is_test_path("backend/tests/test_x.py") and is_test_path("src/a.spec.ts")
    assert not is_test_path("backend/app/main.py")


def test_file_coverage_from_cobertura_and_lcov(tmp_path):
    from dev_pipe.report_data import file_coverage
    (tmp_path / "backend").mkdir()
    (tmp_path / "backend" / "coverage.xml").write_text(
        f'<coverage><sources><source>{tmp_path / "backend"}</source></sources><packages><package><classes>'
        '<class filename="app/main.py" line-rate="0.96"/></classes></package></packages></coverage>', encoding="utf-8")
    (tmp_path / "frontend" / "coverage").mkdir(parents=True)
    (tmp_path / "frontend" / "coverage" / "lcov.info").write_text(
        "SF:frontend/src/App.jsx\nLF:10\nLH:8\nend_of_record\n", encoding="utf-8")
    got = file_coverage(tmp_path, ["backend/app/main.py", "frontend/src/App.jsx", "other.py"])
    assert got == {"backend/app/main.py": 96.0, "frontend/src/App.jsx": 80.0}


def test_command_steps_in_plain_words():
    from dev_pipe.report_data import command_steps
    log = "$ /v/bin/python -m pip install -q -r requirements.txt  (exit 0)\n$ /v/bin/python -m compileall -q .  (exit 0)\n" \
          "$ COVERAGE_FILE=x /v/bin/python -m pytest tests -p no:cacheprovider  (exit 1)\n"
    assert command_steps(log) == [("Installed dependencies", True), ("Compiled / built the code", True),
                                  ("Ran the tests", False)]
