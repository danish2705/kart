"""Tests for azure_openai_proxy: pure translation-function unit tests plus
a full round-trip integration test against a stub "fake Azure" HTTP server
(no live Azure credentials needed -- see README.md's "What's been verified
vs. not" for why a real Azure OpenAI call itself isn't exercised here)."""
from __future__ import annotations

import json
import subprocess
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest
import requests

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from azure_openai_proxy import (
    anthropic_error,
    anthropic_messages_to_openai,
    anthropic_request_to_openai,
    anthropic_tool_choice_to_openai,
    anthropic_tools_to_openai,
    is_reasoning_model,
    openai_response_to_anthropic,
    sse_events_for_message,
    start_proxy,
    stop_proxy,
)
from azure_openai_proxy.server import azure_chat_completions_url, azure_headers

# ---------------------------------------------------------------------------
# Pure translation functions
# ---------------------------------------------------------------------------

def test_is_reasoning_model_matches_o_series_and_gpt5():
    assert is_reasoning_model("o4-mini")
    assert is_reasoning_model("O3")
    assert is_reasoning_model("gpt-5-thinking")
    assert not is_reasoning_model("gpt-4o")


def test_anthropic_messages_to_openai_plain_text_roundtrip():
    out = anthropic_messages_to_openai("You are helpful.", [{"role": "user", "content": "hi"}])
    assert out == [
        {"role": "system", "content": "You are helpful."},
        {"role": "user", "content": "hi"},
    ]


def test_anthropic_messages_to_openai_expands_tool_use_into_tool_calls():
    messages = [
        {"role": "user", "content": "read the file"},
        {
            "role": "assistant",
            "content": [
                {"type": "text", "text": "Sure, reading it."},
                {"type": "tool_use", "id": "call_1", "name": "Read", "input": {"file_path": "a.py"}},
            ],
        },
        {
            "role": "user",
            "content": [{"type": "tool_result", "tool_use_id": "call_1", "content": "file contents"}],
        },
    ]
    out = anthropic_messages_to_openai(None, messages)
    assert out[0] == {"role": "user", "content": "read the file"}
    assert out[1]["role"] == "assistant"
    assert out[1]["content"] == "Sure, reading it."
    assert out[1]["tool_calls"] == [
        {"id": "call_1", "type": "function", "function": {"name": "Read", "arguments": json.dumps({"file_path": "a.py"})}}
    ]
    assert out[2] == {"role": "tool", "tool_call_id": "call_1", "content": "file contents"}


def test_anthropic_messages_to_openai_system_as_content_block_list():
    out = anthropic_messages_to_openai(
        [{"type": "text", "text": "part one"}, {"type": "text", "text": "part two"}],
        [{"role": "user", "content": "hi"}],
    )
    assert out[0] == {"role": "system", "content": "part one\npart two"}


def test_anthropic_messages_to_openai_user_message_with_text_content_blocks():
    out = anthropic_messages_to_openai(None, [
        {"role": "user", "content": [{"type": "text", "text": "line one"}, {"type": "text", "text": "line two"}]},
    ])
    assert out == [{"role": "user", "content": "line one\nline two"}]


def test_anthropic_messages_to_openai_tool_result_with_list_content():
    messages = [{
        "role": "user",
        "content": [{"type": "tool_result", "tool_use_id": "c1", "content": [{"type": "text", "text": "ok"}]}],
    }]
    out = anthropic_messages_to_openai(None, messages)
    assert out == [{"role": "tool", "tool_call_id": "c1", "content": "ok"}]


def test_anthropic_tools_to_openai_maps_input_schema_to_parameters():
    tools = [{"name": "Read", "description": "reads a file", "input_schema": {"type": "object", "properties": {}}}]
    out = anthropic_tools_to_openai(tools)
    assert out == [{
        "type": "function",
        "function": {"name": "Read", "description": "reads a file", "parameters": {"type": "object", "properties": {}}},
    }]
    assert anthropic_tools_to_openai(None) is None
    assert anthropic_tools_to_openai([]) is None


@pytest.mark.parametrize("anthropic_choice,expected", [
    (None, None),
    ({"type": "auto"}, "auto"),
    ({"type": "any"}, "required"),
    ({"type": "tool", "name": "Read"}, {"type": "function", "function": {"name": "Read"}}),
])
def test_anthropic_tool_choice_to_openai(anthropic_choice, expected):
    assert anthropic_tool_choice_to_openai(anthropic_choice) == expected


def test_anthropic_request_to_openai_reasoning_model_uses_max_completion_tokens():
    body = {"model": "o4-mini", "max_tokens": 512, "temperature": 0.7, "messages": [{"role": "user", "content": "hi"}]}
    out = anthropic_request_to_openai(body)
    assert out["max_completion_tokens"] == 512
    assert "max_tokens" not in out
    assert "temperature" not in out  # reasoning models reject it


def test_anthropic_request_to_openai_normal_model_keeps_temperature_and_max_tokens():
    body = {"model": "gpt-4o", "max_tokens": 256, "temperature": 0.2, "messages": [{"role": "user", "content": "hi"}]}
    out = anthropic_request_to_openai(body)
    assert out["max_tokens"] == 256
    assert out["temperature"] == 0.2
    assert "max_completion_tokens" not in out


def test_anthropic_request_to_openai_includes_tools_and_tool_choice_only_when_present():
    body = {
        "model": "gpt-4o", "messages": [{"role": "user", "content": "hi"}],
        "tools": [{"name": "Read", "input_schema": {}}], "tool_choice": {"type": "any"},
    }
    out = anthropic_request_to_openai(body)
    assert out["tools"][0]["function"]["name"] == "Read"
    assert out["tool_choice"] == "required"

    body_no_tools = {"model": "gpt-4o", "messages": [{"role": "user", "content": "hi"}]}
    assert "tools" not in anthropic_request_to_openai(body_no_tools)


def test_openai_response_to_anthropic_text_only():
    resp = {
        "id": "chatcmpl-1",
        "choices": [{"finish_reason": "stop", "message": {"role": "assistant", "content": "hello there"}}],
        "usage": {"prompt_tokens": 10, "completion_tokens": 3},
    }
    out = openai_response_to_anthropic(resp, "gpt-4o")
    assert out["content"] == [{"type": "text", "text": "hello there"}]
    assert out["stop_reason"] == "end_turn"
    assert out["usage"] == {"input_tokens": 10, "output_tokens": 3}


def test_openai_response_to_anthropic_tool_call():
    resp = {
        "id": "chatcmpl-2",
        "choices": [{
            "finish_reason": "tool_calls",
            "message": {
                "role": "assistant", "content": None,
                "tool_calls": [{"id": "call_1", "type": "function",
                                 "function": {"name": "Read", "arguments": '{"file_path": "a.py"}'}}],
            },
        }],
        "usage": {"prompt_tokens": 20, "completion_tokens": 5},
    }
    out = openai_response_to_anthropic(resp, "gpt-4o")
    assert out["content"] == [{"type": "tool_use", "id": "call_1", "name": "Read", "input": {"file_path": "a.py"}}]
    assert out["stop_reason"] == "tool_use"


def test_openai_response_to_anthropic_malformed_tool_arguments_default_to_empty_dict():
    resp = {
        "id": "chatcmpl-3",
        "choices": [{
            "finish_reason": "tool_calls",
            "message": {"role": "assistant", "content": None,
                        "tool_calls": [{"id": "call_1", "type": "function",
                                        "function": {"name": "Read", "arguments": "not json"}}]},
        }],
        "usage": {},
    }
    out = openai_response_to_anthropic(resp, "gpt-4o")
    assert out["content"][0]["input"] == {}


def test_openai_response_to_anthropic_no_content_and_no_tool_calls_falls_back_to_empty_text():
    resp = {
        "id": "chatcmpl-4",
        "choices": [{"finish_reason": "stop", "message": {"role": "assistant", "content": None}}],
        "usage": {},
    }
    out = openai_response_to_anthropic(resp, "gpt-4o")
    assert out["content"] == [{"type": "text", "text": ""}]


def test_anthropic_error_shape():
    err = anthropic_error("boom")
    assert err == {"type": "error", "error": {"type": "api_error", "message": "boom"}}


def test_sse_events_for_message_contains_matching_start_delta_stop_for_each_block():
    message = {
        "id": "msg_1", "type": "message", "role": "assistant", "model": "gpt-4o",
        "content": [
            {"type": "text", "text": "hi"},
            {"type": "tool_use", "id": "call_1", "name": "Read", "input": {"a": 1}},
        ],
        "stop_reason": "tool_use", "stop_sequence": None,
        "usage": {"input_tokens": 5, "output_tokens": 2},
    }
    stream = sse_events_for_message(message)
    assert stream.count("event: content_block_start") == 2
    assert stream.count("event: content_block_stop") == 2
    assert "event: message_start" in stream
    assert "event: message_stop" in stream
    assert '"partial_json": "{\\"a\\": 1}"' in stream


# ---------------------------------------------------------------------------
# URL/header shape selection
# ---------------------------------------------------------------------------

def test_azure_chat_completions_url_new_v1_shape_has_no_api_version():
    url = azure_chat_completions_url("https://res.openai.azure.com/openai/v1", "o4-mini", "2024-12-01-preview")
    assert url == "https://res.openai.azure.com/openai/v1/chat/completions"


def test_azure_chat_completions_url_classic_shape_includes_deployment_and_api_version():
    url = azure_chat_completions_url("https://res.openai.azure.com", "o4-mini", "2024-12-01-preview")
    assert url == "https://res.openai.azure.com/openai/deployments/o4-mini/chat/completions?api-version=2024-12-01-preview"


def test_azure_headers_new_v1_shape_uses_bearer():
    headers = azure_headers("https://res.openai.azure.com/openai/v1", "secret")
    assert headers["Authorization"] == "Bearer secret"


def test_azure_headers_classic_shape_uses_api_key():
    headers = azure_headers("https://res.openai.azure.com", "secret")
    assert headers["api-key"] == "secret"


# ---------------------------------------------------------------------------
# Full round trip against a stub fake-Azure server
# ---------------------------------------------------------------------------

class _FakeAzureHandler(BaseHTTPRequestHandler):
    response_body: dict = {}

    def log_message(self, format, *args):
        pass

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        self.last_request = json.loads(self.rfile.read(length) or b"{}")
        _FakeAzureHandler.received.append(self.last_request)
        data = json.dumps(_FakeAzureHandler.response_body).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


@pytest.fixture
def fake_azure():
    _FakeAzureHandler.received = []
    _FakeAzureHandler.response_body = {
        "id": "chatcmpl-fake",
        "choices": [{"finish_reason": "stop", "message": {"role": "assistant", "content": "fake reply"}}],
        "usage": {"prompt_tokens": 7, "completion_tokens": 2},
    }
    server = ThreadingHTTPServer(("127.0.0.1", 0), _FakeAzureHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    port = server.server_address[1]
    yield f"http://127.0.0.1:{port}/openai/v1", _FakeAzureHandler
    server.shutdown()
    server.server_close()
    thread.join(timeout=5)


@pytest.fixture
def proxy(fake_azure):
    endpoint, _ = fake_azure
    server, thread, port = start_proxy(endpoint=endpoint, api_key="fake-key", deployment="o4-mini")
    yield f"http://127.0.0.1:{port}"
    stop_proxy(server, thread)


def test_proxy_round_trip_non_streaming(proxy, fake_azure):
    _, fake_handler = fake_azure
    resp = requests.post(f"{proxy}/v1/messages", json={
        "model": "o4-mini", "max_tokens": 100,
        "messages": [{"role": "user", "content": "hello"}],
    }, timeout=10)
    assert resp.status_code == 200
    body = resp.json()
    assert body["content"] == [{"type": "text", "text": "fake reply"}]
    assert body["stop_reason"] == "end_turn"
    # and confirm the outbound request the proxy sent to "Azure" was
    # correctly shaped for a reasoning model (max_completion_tokens, no temperature)
    sent = fake_handler.received[0]
    assert sent["max_completion_tokens"] == 100
    assert "temperature" not in sent


def test_proxy_round_trip_streaming_emits_valid_sse(proxy):
    resp = requests.post(f"{proxy}/v1/messages", json={
        "model": "o4-mini", "max_tokens": 100, "stream": True,
        "messages": [{"role": "user", "content": "hello"}],
    }, timeout=10)
    assert resp.status_code == 200
    assert resp.headers["Content-Type"] == "text/event-stream"
    assert "event: message_start" in resp.text
    assert "event: message_stop" in resp.text


def test_proxy_returns_anthropic_shaped_error_on_azure_failure():
    # Point the proxy at a port nothing is listening on.
    server, thread, port = start_proxy(endpoint="http://127.0.0.1:1", api_key="k", deployment="o4-mini")
    try:
        resp = requests.post(f"http://127.0.0.1:{port}/v1/messages", json={
            "model": "o4-mini", "max_tokens": 10, "messages": [{"role": "user", "content": "hi"}],
        }, timeout=10)
        assert resp.status_code == 502
        assert resp.json()["type"] == "error"
    finally:
        stop_proxy(server, thread)


def test_proxy_returns_400_on_invalid_json_body():
    server, thread, port = start_proxy(endpoint="http://unused", api_key="k", deployment="o4-mini")
    try:
        resp = requests.post(
            f"http://127.0.0.1:{port}/v1/messages", data=b"not json",
            headers={"Content-Type": "application/json"}, timeout=10,
        )
        assert resp.status_code == 400
        assert resp.json()["type"] == "error"
    finally:
        stop_proxy(server, thread)


def test_proxy_surfaces_azure_http_error_status_and_body(fake_azure):
    endpoint, fake_handler = fake_azure

    class _ErrorHandler(_FakeAzureHandler):
        def do_POST(self):
            length = int(self.headers.get("Content-Length", 0))
            self.rfile.read(length)  # drain the request body first, or the client's write gets aborted
            data = json.dumps({"error": {"message": "bad deployment"}}).encode("utf-8")
            self.send_response(400)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    error_server = ThreadingHTTPServer(("127.0.0.1", 0), _ErrorHandler)
    error_thread = threading.Thread(target=error_server.serve_forever, daemon=True)
    error_thread.start()
    error_endpoint = f"http://127.0.0.1:{error_server.server_address[1]}/openai/v1"

    server, thread, port = start_proxy(endpoint=error_endpoint, api_key="k", deployment="o4-mini")
    try:
        resp = requests.post(f"http://127.0.0.1:{port}/v1/messages", json={
            "model": "o4-mini", "max_tokens": 10, "messages": [{"role": "user", "content": "hi"}],
        }, timeout=10)
        assert resp.status_code == 502
        body = resp.json()
        assert body["type"] == "error"
        assert "bad deployment" in body["error"]["message"]
    finally:
        stop_proxy(server, thread)
        error_server.shutdown()
        error_server.server_close()
        error_thread.join(timeout=5)


def test_proxy_health_check_get():
    server, thread, port = start_proxy(endpoint="http://unused", api_key="k", deployment="o4-mini")
    try:
        resp = requests.get(f"http://127.0.0.1:{port}/", timeout=10)
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"
    finally:
        stop_proxy(server, thread)


# ---------------------------------------------------------------------------
# Standalone `python -m azure_openai_proxy` entry point
# ---------------------------------------------------------------------------

def test_module_is_runnable_via_dash_m_and_requires_endpoint_api_key_deployment():
    result = subprocess.run(
        [sys.executable, "-m", "azure_openai_proxy"], cwd=ROOT, capture_output=True, text=True,
    )
    assert result.returncode == 2
    assert "--endpoint" in result.stderr
    assert "--api-key" in result.stderr
    assert "--deployment" in result.stderr
