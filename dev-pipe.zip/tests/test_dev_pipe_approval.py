"""Tests for the issue-based approval gates (no network: GitHub is faked)."""
from __future__ import annotations

import json

import pytest

from dev_pipe import approval
from dev_pipe.steps import gate


def c(login, body):
    return {"user": {"login": login}, "body": body}


# ---------- parsing and decisions
def test_parse_approvers_is_case_insensitive_and_strips_at():
    assert approval.parse_approvers("alice, @Bob  carol") == {"alice", "bob", "carol"}
    assert approval.parse_approvers("") == set()


def test_approve_and_reject_by_allowed_approver():
    assert approval.decide([c("Alice", "Approve")], {"alice"}) == ("approve", "", "Alice")
    assert approval.decide([c("alice", "reject: use TaskStore")], {"alice"}) == ("reject", "use TaskStore", "alice")
    assert approval.decide([c("alice", "/rejected")], {"alice"})[1] == "(no reason given)"


def test_comments_from_others_and_bot_are_ignored():
    comments = [c("mallory", "approve"), c("github-actions[bot]", "approve"), c("alice", "looks good, checking")]
    assert approval.decide(comments, {"alice"}) is None


def test_first_decision_wins_and_words_must_lead():
    assert approval.decide([c("alice", "I don't approve yet"), c("alice", "reject: wrong file")],
                           {"alice"}) == ("reject", "wrong file", "alice")
    assert approval.decide([c("alice", "approve"), c("alice", "reject: x")], {"alice"})[0] == "approve"


class FakeGitHub:
    def __init__(self, comment_batches):
        self.batches = list(comment_batches)
        self.created, self.comments, self.closed = [], [], []

    def create_issue(self, title, body):
        self.created.append((title, body))
        return {"number": 7, "html_url": "https://github.com/o/r/issues/7"}

    def list_comments(self, number):
        return self.batches.pop(0) if len(self.batches) > 1 else self.batches[0]

    def comment(self, number, body):
        self.comments.append(body)

    def close(self, number, completed):
        self.closed.append(completed)


def test_wait_polls_until_decision():
    gh = FakeGitHub([[], [], [c("alice", "approve")]])
    sleeps = []
    assert approval.wait_for_decision(gh, 7, {"alice"}, timeout_s=999, sleep=sleeps.append,
                                      now=lambda: 0) == ("approve", "", "alice")
    assert len(sleeps) == 2


def test_wait_times_out():
    clock = iter([0, 10, 61])
    assert approval.wait_for_decision(FakeGitHub([[]]), 7, {"alice"}, timeout_s=60,
                                      sleep=lambda s: None, now=lambda: next(clock)) is None


# ---------- gate step end to end
@pytest.fixture
def out_dir(tmp_path, monkeypatch):
    out = tmp_path / "out"
    out.mkdir()
    (out / "story.json").write_text(json.dumps({"id": 101, "title": "Add /concat"}))
    (out / "plan.md").write_text("## Summary\nAdd a /concat endpoint")
    monkeypatch.setattr(gate, "OUT", out)
    monkeypatch.setenv("APPROVERS", "alice")
    monkeypatch.setenv("APPROVAL_TIMEOUT_MINUTES", "30")
    monkeypatch.delenv("GITHUB_STEP_SUMMARY", raising=False)
    return out


def test_issue_shows_what_to_review(out_dir):
    title, body = gate.build_issue("approve-plan", out_dir, "https://run", {"alice"}, 30)
    assert "Step 3" in title and "#101" in title
    assert "Add a /concat endpoint" in body and "`approve`" in body and "@alice" in body


def test_gate_approved_closes_issue_and_continues(out_dir):
    gh = FakeGitHub([[c("alice", "approve")]])
    gate.main(["approve-plan"], gh=gh, waiter=lambda *a, **k: ("approve", "", "alice"))
    assert gh.closed == [True] and "Approved by @alice" in gh.comments[0]


def test_gate_rejected_stops_pipeline(out_dir):
    gh = FakeGitHub([[]])
    with pytest.raises(SystemExit) as err:
        gate.main(["approve-plan"], gh=gh, waiter=lambda *a, **k: ("reject", "wrong approach", "alice"))
    assert err.value.code == 1 and gh.closed == [False] and "wrong approach" in gh.comments[0]


def test_gate_timeout_stops_pipeline(out_dir):
    gh = FakeGitHub([[]])
    with pytest.raises(SystemExit):
        gate.main(["approve-plan"], gh=gh, waiter=lambda *a, **k: None)
    assert gh.closed == [False] and "No decision" in gh.comments[0]


def test_unknown_gate_and_missing_approvers_fail_fast(out_dir, monkeypatch):
    with pytest.raises(SystemExit):
        gate.main(["approve-everything"], gh=FakeGitHub([[]]))
    monkeypatch.setenv("APPROVERS", "")
    with pytest.raises(SystemExit):
        gate.main(["approve-plan"], gh=FakeGitHub([[]]))


def test_every_gate_in_workflow_exists_in_gate_py():
    import pathlib
    import yaml
    wf = yaml.safe_load(pathlib.Path(".github/workflows/dev-pipe.yml").read_text())
    used = {job["with"]["gate"] for job in wf["jobs"].values() if "uses" in job}
    # The pipeline now has a single human approval (approve-ado-update); the other gates stay
    # defined in gate.py so they can be re-enabled, so only check that every gate used exists.
    assert used <= set(gate.GATES)
    assert used == {"approve-ado-update"}
