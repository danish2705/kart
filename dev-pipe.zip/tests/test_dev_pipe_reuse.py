"""Not doing the same work twice: coverage hand-over (Steps 4 -> 5 -> 7), Step 3's build reuse, Python packages
installed once per job, parallel repo search with a branch cap. No network."""
from __future__ import annotations

import os
import time

import pytest

from dev_pipe import build, coverage_handover as ch, resolver
from dev_pipe.build import BuildResult
from dev_pipe.github_api import GitHub, GitHubError
from dev_pipe.steps import s4_autonomous_development as s3
from dev_pipe.steps import s6_build_test_coverage as s4


# ---------- coverage hand-over
@pytest.fixture
def repo(tmp_path):
    root = tmp_path / "repo"
    app = root / "app"
    (app / "coverage").mkdir(parents=True)
    (app / "coverage.xml").write_text("<coverage line-rate='0.9'/>")
    (app / "coverage" / "lcov.info").write_text("SF:a.js\nLF:10\nLH:9\nend_of_record\n")
    out = tmp_path / "out"
    return root, app, out


def test_save_and_restore_same_code(repo):
    root, app, out = repo
    fp = ch.code_fingerprint("abc", b"patch")
    assert ch.save(app, root, fp, newer_than=None, out=out) == 2
    for f in (app / "coverage.xml", app / "coverage" / "lcov.info"):
        f.unlink()
    before = time.time()
    restored = ch.restore(root, fp, out=out)
    assert sorted(restored) == ["app/coverage.xml", "app/coverage/lcov.info"]
    assert (app / "coverage.xml").read_text() == "<coverage line-rate='0.9'/>"
    assert os.path.getmtime(app / "coverage.xml") >= before - 1   # counts as this run's report


def test_restore_refuses_other_code_or_missing_files(repo):
    root, app, out = repo
    ch.save(app, root, ch.code_fingerprint("abc", b"patch"), newer_than=None, out=out)
    assert ch.restore(root, ch.code_fingerprint("abc", b"other patch"), out=out) == []
    assert ch.restore(root, ch.code_fingerprint("def", b"patch"), out=out) == []
    (out / ch.FILES_DIR / "app" / "coverage.xml").unlink()
    assert ch.restore(root, ch.code_fingerprint("abc", b"patch"), out=out) == []


def test_stale_reports_are_not_handed_over(repo):
    root, app, out = repo
    old = time.time() - 3600
    for f in (app / "coverage.xml", app / "coverage" / "lcov.info"):
        os.utime(f, (old, old))
    assert ch.save(app, root, "fp", newer_than=time.time(), out=out) == 0
    assert not (out / ch.MANIFEST).exists()


def test_java_repos_never_reuse(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "A.java").write_text("class A {}")
    assert ch.has_java(tmp_path) is True
    other = tmp_path / "py"
    other.mkdir()
    (other / "a.py").write_text("x = 1")
    assert ch.has_java(other) is False


def test_step5_first_run_reuses_and_only_scans(monkeypatch, tmp_path):
    monkeypatch.setattr(s4, "target_settings", lambda: {"app_dir": "app", "test_dir": "tests", "app_package": "app"})
    monkeypatch.setattr(s4, "app_dir", lambda: tmp_path)
    monkeypatch.setattr(s4, "work_root", lambda: tmp_path)
    monkeypatch.setattr(s4.coverage_handover, "restore", lambda root, fp, out=None: ["app/coverage.xml"])
    monkeypatch.setattr(s4, "sonar_gate", lambda base, started: (None, "passed", False))

    def boom(*a, **k):
        raise AssertionError("tests must not run again")
    monkeypatch.setattr(s4, "prepare_python", boom)
    monkeypatch.setattr(s4, "check_build", boom)
    previous = {"passed": True, "coverage_pct": 91.0, "tests": {"passed": 12, "failed": 0}, "history": [1]}
    failures, data = s4.run_gates(85, "base", with_sonar=True, reuse={"fingerprint": "fp", "previous": previous})
    assert failures == [] and data["coverage_reused"] is True and data["coverage_pct"] == 91.0
    assert data["sonar_precheck"] == "passed" and "history" not in data and "passed" not in data


def test_step5_falls_back_when_files_not_reusable(monkeypatch, tmp_path):
    monkeypatch.setattr(s4, "target_settings", lambda: {"app_dir": "app", "test_dir": "tests", "app_package": "app"})
    monkeypatch.setattr(s4, "app_dir", lambda: tmp_path)
    monkeypatch.setattr(s4, "work_root", lambda: tmp_path)
    monkeypatch.setattr(s4.coverage_handover, "restore", lambda root, fp, out=None: [])
    monkeypatch.setattr(s4, "is_python_target", lambda t, a: False)
    called = []
    monkeypatch.setattr(s4, "check_build", lambda *a, **k: called.append(1) or BuildResult(False, "boom"))
    failures, data = s4.run_gates(85, "", with_sonar=True, reuse={"fingerprint": "fp", "previous": {}})
    assert called == [1] and failures and "coverage_reused" not in data


# ---------- Step 3: last build check reused
def test_build_followup_records_result_with_fingerprint(monkeypatch):
    result = BuildResult(True, "$ pytest (exit 0)")
    monkeypatch.setattr(s3, "check_build", lambda *a, **k: result)
    monkeypatch.setattr(s3, "app_dir", lambda: "app")
    monkeypatch.setattr(s3, "work_root", lambda: __import__("pathlib").Path("."))
    last: dict = {}
    check = s3.build_followup({}, lambda: ["app/x.py"], lambda: "fp1", last)
    assert check("done") is None
    assert last["result"] is result and last["fp"] == "fp1" and last["seconds"] >= 0


# ---------- Python packages once per job
def test_prepare_python_installs_once_until_deps_change(monkeypatch, tmp_path):
    (tmp_path / "requirements.txt").write_text("requests\n")
    runs = []
    monkeypatch.setattr(build, "python_env", lambda p: ("/venv/bin/python", ["pip install"]))
    monkeypatch.setattr(build, "_run_commands", lambda cwd, cmds: runs.append(1) or (True, "ok"))
    monkeypatch.setattr(build, "_PREPARED", {})
    assert build.prepare_python(tmp_path)[:2] == (True, "/venv/bin/python")
    assert build.prepare_python(tmp_path)[:2] == (True, "/venv/bin/python")
    assert len(runs) == 1
    (tmp_path / "requirements.txt").write_text("requests\nflask\n")   # the AI added a dependency
    build.prepare_python(tmp_path)
    assert len(runs) == 2


def test_failed_install_is_retried(monkeypatch, tmp_path):
    (tmp_path / "requirements.txt").write_text("x\n")
    results = iter([(False, "err"), (True, "ok")])
    monkeypatch.setattr(build, "python_env", lambda p: ("py", ["pip install"]))
    monkeypatch.setattr(build, "_run_commands", lambda cwd, cmds: next(results))
    monkeypatch.setattr(build, "_PREPARED", {})
    assert build.prepare_python(tmp_path)[0] is False
    assert build.prepare_python(tmp_path)[0] is True


# ---------- resolver: branch cap, newest first, parallel
class GH:
    def __init__(self, n=10, bulk=True):
        self.n, self.bulk_ok = n, bulk
        self.single_calls = 0

    def open_pulls(self, full):
        return []

    def branches_with_dates(self, full):
        if not self.bulk_ok:
            raise GitHubError("graphql off")
        return [{"name": f"b{i}", "sha": f"s{i}", "date": f"2026-01-{i + 1:02d}T00:00:00Z"} for i in range(self.n)] + \
               [{"name": "main", "sha": "m", "date": "2026-02-01T00:00:00Z"}]

    def list_branches(self, full, limit=100):
        return ["main"] + [f"b{i}" for i in range(self.n)]

    def get_branch(self, full, name):
        self.single_calls += 1
        return {"name": name, "sha": "s", "date": "2026-02-01T00:00:00Z" if name == "main" else
                f"2026-01-{int(name[1:]) + 1:02d}T00:00:00Z"}


BASE = {"full_name": "org/r", "default_branch": "main", "branch": "main"}


def test_branch_cap_keeps_newest_and_skips_base():
    r = resolver.Resolver(GH(10), None, {"max_branches_scanned": 3}, log=lambda *_: None)
    names = [c["branch"] for c in r.scan_branches(BASE, set())]
    assert names == ["b9", "b8", "b7"]


def test_no_cap_means_all_branches():
    r = resolver.Resolver(GH(10), None, {"max_branches_scanned": 0}, log=lambda *_: None)
    assert len(r.scan_branches(BASE, set())) == 10


def test_falls_back_to_one_call_per_branch_in_parallel():
    gh = GH(10, bulk=False)
    r = resolver.Resolver(gh, None, {"max_branches_scanned": 2, "parallel_requests": 4}, log=lambda *_: None)
    assert [c["branch"] for c in r.scan_branches(BASE, set())] == ["b9", "b8"]
    assert gh.single_calls == 11


def test_parallel_keeps_order():
    r = resolver.Resolver(GH(), None, {"parallel_requests": 5}, log=lambda *_: None)
    assert r._parallel(lambda x: x * 2, list(range(20))) == [x * 2 for x in range(20)]


# ---------- GitHub GraphQL branch listing
class Resp:
    def __init__(self, body, status=200):
        self.body, self.status_code, self.content, self.text = body, status, b"x", str(body)

    def json(self):
        return self.body


class Session:
    def __init__(self, pages):
        self.pages, self.headers, self.posts = list(pages), {}, []

    def post(self, url, json=None, timeout=None):
        self.posts.append((url, json["variables"]["after"]))
        return self.pages.pop(0)


def page(names, more, cursor=None):
    return Resp({"data": {"repository": {"refs": {
        "pageInfo": {"hasNextPage": more, "endCursor": cursor},
        "nodes": [{"name": n, "target": {"oid": f"sha-{n}", "committedDate": "2026-01-01T00:00:00Z"}} for n in names]}}}})


def test_branches_with_dates_pages_through_graphql():
    s = Session([page(["a", "b"], True, "c1"), page(["c"], False)])
    gh = GitHub("t", api="https://api.github.com", session=s)
    out = gh.branches_with_dates("org/r")
    assert [b["name"] for b in out] == ["a", "b", "c"] and out[0]["sha"] == "sha-a"
    assert s.posts == [("https://api.github.com/graphql", None), ("https://api.github.com/graphql", "c1")]


def test_branches_with_dates_errors_raise():
    gh = GitHub("t", api="https://ghe.example.com/api/v3", session=Session([Resp({"errors": [{"message": "x"}]})]))
    with pytest.raises(GitHubError):
        gh.branches_with_dates("org/r")
