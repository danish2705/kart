---
name: test-quality-review
description: Use whenever writing or modifying tests for the Dev Agent -- the checklist for what makes a test meaningful vs. coverage-gaming, and how to self-review before the automated trivial-test check runs.
---

# Test Quality Review

95% coverage is a floor, not a goal in itself, and it's trivially
gameable with tests that execute code but check nothing. A separate,
automated check (`dev_agent/checks/test_quality_review.py`) parses
every `test_*` function's AST and flags:

- Any test with **no assertion at all** (and no `pytest.raises`/`warns`
  context manager) -- it ran code but verified nothing.
- Any test where **every assertion is vacuous** (`assert True`,
  `assert 1`).

Passing that automated check is necessary but not sufficient. Before
considering a test done, self-review it against this checklist:

1. **Does the assertion check the actual behavior the test name
   claims?** `test_create_task_requires_title` should assert a 422 (or
   equivalent), not just that the endpoint didn't crash.
2. **Does it cover an edge case implied by the ADO work item's
   acceptance criteria** -- not just the happy path? If the acceptance
   criteria says "reject empty titles," there must be a test for
   exactly that, with an assertion on the rejection.
3. **Would this test actually fail if the feature were broken?** Mentally
   revert your implementation change and ask whether this test would
   now fail. If it would still pass, it isn't testing the thing you
   think it's testing.
4. **One behavior per test.** Prefer several small, clearly-named tests
   over one large test asserting many unrelated things -- a failure is
   easier to diagnose (this also helps the QE Agent's self-healing
   step later, which relies on test names/failures being specific).

## Example: gaming vs. real

```python
# BAD -- executes the endpoint, asserts nothing about the result
def test_create_task():
    client.post("/tasks", json={"title": "x"})

# GOOD -- asserts the actual contract
def test_create_task_returns_201_with_done_false():
    resp = client.post("/tasks", json={"title": "x"})
    assert resp.status_code == 201
    assert resp.json()["done"] is False
```
