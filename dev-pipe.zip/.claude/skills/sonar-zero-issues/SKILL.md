---
name: sonar-zero-issues
description: Use before pushing any Dev Agent code change -- how to run the local SonarQube/SonarCloud pre-check, read its findings, and iterate to zero Blocker/Critical/Major issues before the code leaves the machine.
---

# Sonar Zero-Issues Pre-Check

The pipeline requires a **clean** local Sonar scan (zero issues at
Blocker/Critical/Major severity) before a branch can be pushed --
catching problems before they ever reach GitHub/CI, not after.

## Procedure

1. Make sure the build and tests pass first: the pre-check only runs on code that builds (Java needs
   compiled classes, .NET is built by the scanner itself).
2. The pipeline (`dev_pipe/sonar_precheck.py`) scans your change on SonarQube Cloud as a temporary
   branch analysis, for any language (JS/TS, Python, Java, Go, C#), and reports only the
   Blocker/Critical/Major issues **on the lines you added or changed**. Existing issues elsewhere in
   the repo are not your task. You'll be shown that report as feedback if it fails. It looks like:
   ```
   Sonar pre-check FAILED: 2 blocking issue(s) in the code you changed (web (sonar-scanner)). Fix each one at its location:
     [CRITICAL] src/app/pay.service.ts:34 -- Refactor this function to reduce its Cognitive Complexity (typescript:S3776)
     [MAJOR] app/storage.py:12 -- Remove this unused import (python:S1128)
   ```
3. Fix each listed issue **at its exact location** -- don't
   broadly refactor unrelated code while you're in there (that risks
   the coverage/quality gates you already passed).
4. Common categories and the right fix:
   - **Unused imports/variables** -- remove them.
   - **Cognitive complexity** -- extract a well-named helper function
     rather than adding comments to explain a tangled one.
   - **Duplicated code blocks** -- extract a shared function.
   - **Missing error handling on an external call** -- add it; don't
     silently `except: pass`.
   - **Hardcoded secret-shaped strings** -- these must never appear in
     code; use environment variables (see `dev_agent/mcp_config.py` for
     the existing pattern).
5. Re-run the coverage gate if your fix touched test files, then let
   the Sonar pre-check run again. Repeat until it reports PASS.

## What NOT to do

- Don't suppress an issue with an inline `// NOSONAR` or equivalent
  comment to make the count reach zero -- that defeats the entire
  point of the gate. Fix the underlying issue.
- Don't lower the severity thresholds being checked.
