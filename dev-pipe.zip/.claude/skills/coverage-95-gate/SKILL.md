---
name: coverage-95-gate
description: Use when implementing or fixing code for the Dev Agent -- run and interpret the pytest coverage gate that requires >=95% line coverage on the touched package before code can be pushed.
---

# Coverage Gate (>=95%)

The pipeline enforces >=95% line coverage on the application package
before a PR can open. Coverage alone is not the goal -- see the
`test-quality-review` skill, which runs alongside this one and rejects
tests that only exist to inflate this number.

## Procedure

1. From the app directory (e.g. `sample_app/`), run:
   ```
   python -m pytest tests/ --cov=app --cov-report=term-missing --cov-report=xml -q
   ```
2. Read the `Missing` column in the terminal report -- it lists exact
   line numbers not exercised by any test.
3. For each missing line, ask *why* it's untested:
   - An error branch (e.g. a 404/validation path) -> add a test that
     triggers that branch and asserts the resulting behavior.
   - An edge case (empty input, boundary value) -> add a test for it.
   - Dead/unreachable code -> this is a real finding; remove it or
     explain in your summary why it must stay.
4. Re-run the command above after adding tests. Repeat until the
   `TOTAL` line reads `>=95%`.
5. Never delete or weaken an existing assertion to raise the number --
   that's a Sonar/quality-review issue waiting to happen, and it will
   be caught.

## What NOT to do

- Don't add a test that calls a function and asserts nothing (or
  `assert True`) just to touch a line -- `test-quality-review` flags
  this explicitly, and it doesn't validate anything anyway.
- Don't lower the threshold or add `# pragma: no cover` to dodge the
  gate -- if a line genuinely can't be tested, that's a signal it
  shouldn't exist.
