Step 3: Autonomous Development. The developer APPROVED this plan:

{{plan}}

## Reviewer feedback (empty if none)
{{feedback}}

## What to do
1. Implement the plan in `{{app_dir}}`. Stay within the files the plan lists; if you must touch another file, say why in your final message.
2. When modifying or removing existing code, keep the change minimal and explain each one in your final message (a reviewer checks these at the next gate).
3. Do NOT write new unit tests yet; that is Step 4 (Build + Test + Coverage), after Developer Verification of your change. Keep existing tests passing.
4. Build check: {{build_check}} Fix any failure you caused.
5. If `{{architecture_file}}` does not exist at the REPOSITORY ROOT (the folder you start in, not inside `{{app_dir}}`, `backend/` or any other sub-folder), create it exactly at that root-relative path: a short overview of the app's structure, modules, entry points, and how to build and test. Keep it under 150 lines. Future runs read this instead of scanning the repo.

## Final message
List: files changed (with one line each on what changed), any changes to existing code and why, build and test results, and anything the developer should check manually.
