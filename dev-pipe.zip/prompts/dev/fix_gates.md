The quality gates FAILED (attempt {{attempt}} of {{max_attempts}}). Fix exactly these problems, then stop:

{{failures}}

Do not lower thresholds, skip tests, add `# pragma: no cover`, or add `# NOSONAR`. Before you finish, build and test again: {{build_check}}
