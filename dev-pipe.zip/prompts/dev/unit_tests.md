Step 4: Build + Test + Coverage (unit tests). The developer VERIFIED the code change for this story:

{{plan}}

## Reviewer feedback (empty if none)
{{feedback}}

## What to do
1. Write unit tests in `{{app_dir}}/{{test_dir}}` for the code changed in this story, following the existing test style.
2. Target at least {{threshold}}% line coverage on package `{{app_package}}`. Use the coverage-95-gate skill's procedure (the threshold here is {{threshold}}%).
3. Every test must assert real behaviour (test-quality-review skill). Never write a test only to execute a line.
4. Write code that passes the Sonar rules (sonar-zero-issues skill).
5. Build and test: {{build_check}} Make sure everything passes.

Do not change application behaviour in this step unless a test reveals a real bug; if so, explain it in your final message.
